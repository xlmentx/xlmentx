package Engine;
import java.awt.Image;
public class Physics 
{	
		///////////////////// PROXIMITY SCAN //////////////////////
	//////////////////////
	public double[] scanProximity(double[] centerYX, double[] velocityYX)
	{	double[] proximityValues = {180, 180, 0, 0}; //{Yo, Xo, Y, X}

		////////////////////// PLATFORM SCAN //////////////////////
		for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	double	xStart = Emulator.getPlatform()[i].getPlatformXlocation(), 
					xEnd = xStart + Emulator.getPlatform()[i].getWidth(),
					yStart = Emulator.getPlatform()[i].getPlatformYlocation(),
					yEnd = yStart - Emulator.getPlatform()[i].getHight(),
					slope = -Emulator.getPlatform()[i].getHight()/Emulator.getPlatform()[i].getWidth(),
					ground = slope*(centerYX[1]-xStart)+yStart;
			////////////////////// TOP X //////////////////////
			if(centerYX[1] > xStart && centerYX[1] < xEnd)
			{	////////////////////// TOP Y //////////////////////
				if(centerYX[0] + velocityYX[0] >= ground)
				{	////////////////////// TOP THETA //////////////////////
					proximityValues[0] = Math.atan(slope);
					////////////////////// TOP CONTACT //////////////////////
					proximityValues[2] = ground;
System.out.println(i+" y collision = "+ground);
				}
			}
			////////////////////// RIGHT Y //////////////////////
			if(centerYX[0] > yStart && velocityYX[1] > 0)
			{	////////////////////// RIGHT X //////////////////////
				if(centerYX[1] + velocityYX[1] >= xStart && centerYX[1] <= xStart)
				{	////////////////////// RIGHT THETA //////////////////////
					proximityValues[1] = -90;
					////////////////////// RIGHT CONTACT //////////////////////
					proximityValues[3] = xStart;
System.out.println(i+" x collision = "+xStart);
				}
			}
			////////////////////// LEFT Y //////////////////////
			if(centerYX[0] < yEnd && velocityYX[1] < 0)
			{	////////////////////// LEFT X //////////////////////
				if(centerYX[1] + velocityYX[1] <= xEnd && centerYX[1] >= xEnd)
				{	////////////////////// LEFT THETA //////////////////////
					proximityValues[1] = 90;
					////////////////////// LEFT CONTACT //////////////////////
					proximityValues[3] = xEnd;
System.out.println(i+" x collision = "+xEnd);
				}
			}
				
		}
		return proximityValues;
	}

	
		///////////////////// FORCES //////////////////////
	//////////////////////
	public void applyForces(int playerNum, double[] centerYX, double[] velocityYX)
	{	Physics physics = new Physics();				
		
		//////////////////////GRAVITY //////////////////////
		double gravity = 0.5;
		velocityYX[0] += gravity;
		
		////////////////////// NORMAL FORCE //////////////////////
		double[]proximityValues = physics.scanProximity(centerYX, velocityYX);
		///////////////////// GROUND NORMAL //////////////////////
		if(proximityValues[0] != 180)
		{	////////////////////// VELOCITY MAGNITUDE AND RADIAN //////////////////////
			double	Vm = Math.sqrt(Math.pow(velocityYX[0],2)+Math.pow(velocityYX[1],2)), 
					Vo = -Math.atan2(velocityYX[0],velocityYX[1]),
			////////////////////// NORMAL RADIAN AND FORCE //////////////////////
					No = Math.toRadians(proximityValues[0]+90),
					NF = Math.abs(Vm*Math.cos(No-Vo));
				
			velocityYX[0] += -NF*Math.sin(No);
			velocityYX[1] += NF*Math.cos(No);
			centerYX[0] = proximityValues[2];
System.out.println("Ground="+proximityValues[2]);
		}
		////////////////////// WALL NORMAL //////////////////////
		if(proximityValues[1] != 180)
		{	////////////////////// VELOCITY MAGNITUDE AND RADIAN //////////////////////
			double	Vm = Math.sqrt(Math.pow(velocityYX[0],2)+Math.pow(velocityYX[1],2)), 
					Vo = -Math.atan2(velocityYX[0],velocityYX[1]),
			////////////////////// NORMAL RADIAN AND FORCE //////////////////////
					No = Math.toRadians(proximityValues[1]+90),
					NF = Math.abs(Vm*Math.cos(No-Vo));
		
			velocityYX[0] += -NF*Math.sin(No);
			velocityYX[1] += NF*Math.cos(No);	
			centerYX[1] = proximityValues[3];
System.out.println("Wall="+proximityValues[3]);
		}
			
		////////////////////// APPLY SUM OF FORCES //////////////////////
		Emulator.getPlayer()[playerNum].setCenterYX(centerYX);
System.out.println("Cy="+centerYX[0]+" Cx="+centerYX[1]);
		Emulator.getPlayer()[playerNum].setVelocityYX(velocityYX);
System.out.println("Vy="+velocityYX[0]+" Vx="+velocityYX[1]);
	}
	
}