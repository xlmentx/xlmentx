package Engine;
import java.awt.Image;
public class Player 	
{	////////////////////// ATRIBUTES //////////////////////
	private int			playerNum;		
	private double[]	velocityYX = new double[2],		centerYX = new double[2],
						collisionYX = new double[2];
	private double		acceleration,	torque,			topSpeed,	
						jump,			doubleJump,		climbStrength;
	
	////////////////////// USER INPUT //////////////////////
	private int 		xDirection=1,	doubleJumpAllow=1,		yKeyPressed=0;
	
	//////////////////////PHYSICS//////////////////////
	////////////////////// GAME PLAY//////////////////////
	private int			script=0;				
	private double		respawnDistance;
						  			
	////////////////////// SPRITES //////////////////////
	private int			sprite=1;	
		
	//////////////////////CONSTRUCTOR//////////////////////
//////////////////////
public Player (double[] centerYX, int playerNum)
{	this.centerYX = centerYX;
	this.playerNum = playerNum;
}

	////////////////////// PLAYER UPDATE //////////////////////
//////////////////////
public void update( int xInput, int yInput) 
{	Physics physics = new Physics();				
System.out.println(" ");
	
	///////////////////// COLLISION CHECK //////////////////////
	collisionYX = physics.scanProximity(centerYX, velocityYX);

	////////////////////// X INPUT //////////////////////
	if(Math.abs(xInput) == 1 && collisionYX[1] == 180 && script == 0)
	{	sprite = 2;
		////////////////////// ACCELERATION //////////////////////
		if(Math.abs(velocityYX[1] + acceleration*xInput) < topSpeed)
		{	////////////////////// GROUND : AIR //////////////////////
			velocityYX[1] += (collisionYX[0] != 180)?
				acceleration*xInput: acceleration*xInput/2; 	 
System.out.println("xI.1 xa="+acceleration*xInput+" xv="+velocityYX[1]+" ya="+acceleration*xInput+" yv="+velocityYX[0]);
		}	
	}
	
	////////////////////// Y INPUT //////////////////////
	if(yInput == 1 && yKeyPressed == 0 && script == 0) 
	{	////////////////////// KEY PRESSED //////////////////////
		yKeyPressed = 1;
		////////////////////// GROUND JUMP //////////////////////
		if(collisionYX[0] != 180)
		{	velocityYX[0] = jump;	
			doubleJumpAllow = 1;
System.out.println("y.1  ys="+velocityYX[0]+" cy="+centerYX[0]+" yI="+jump);						
		}
		////////////////////// AIR //////////////////////
		else
		{	////////////////////// COLLISION FREE //////////////////////
			if(collisionYX[0] == 180)
			{	////////////////////// DOUBLE JUMP //////////////////////
				if(doubleJumpAllow == 1)
				{	velocityYX[0] = (velocityYX[0]+doubleJump>=jump && velocityYX[0]<0)? velocityYX[0] + doubleJump: doubleJump;
					doubleJumpAllow = 0;					
System.out.println("y.2  ys="+velocityYX[0]+" cy="+centerYX[0]+" yI="+yInput);						
				}
			}
			//////////////////////COLLISION FREE //////////////////////
			else
			{	////////////////////// WALL JUMP //////////////////////
				velocityYX[0] = jump*0.5+climbStrength*2;
				velocityYX[1] = -xDirection*Math.abs(jump*0.5);	
				doubleJumpAllow = 1;
System.out.println("y.4  ys="+velocityYX[0]+" cy="+centerYX[0]+" wt="+(jump*0.5+climbStrength*2));						
			}	
		}
	}
	
	////////////////////// Y NONE //////////////////////
	if(yInput == 0)
	{	yKeyPressed = 0;
	}
	
			
	////////////////////// PHYSICS //////////////////////
//////////////////////
	physics.applyForces(playerNum, centerYX, velocityYX);
	
		
	
	//////////////////////RESPAWN//////////////////////
	if(centerYX[0]+velocityYX[0]>=Emulator.getResolutionY())
	{	respawnDistance=Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue();
		script=1;
	}	
	//////////////////////SCRIPT 1 RESPAWN//////////////////////
	if(script==1)
	{	double	restartScrollSpeed=100;
		sprite= 0;
		centerYX[0]=Emulator.getTopScrollingValue();
		velocityYX[0]=0;
//System.out.println("y..36  ys="+velocityYX[0]+" cy="+centerYX[0]);
		velocityYX[1]=0;
//System.out.println("x.32 xs="+velocityYX[1]+" cx="+centerXlocation+" RD="+respawnDistance);
		if(respawnDistance+restartScrollSpeed <= 0)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+restartScrollSpeed);
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()+restartScrollSpeed/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()+restartScrollSpeed/1.6));
			respawnDistance+=restartScrollSpeed;
		}
		else
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation()-respawnDistance));
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()-respawnDistance/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()-respawnDistance/1.6));
			script=0;
		}	
	}

	////////////////////// X LOCATION UPDATE//////////////////////
	if(centerYX[1] + velocityYX[1] < Emulator.getRightScrollingValue() && centerYX[1] + velocityYX[1] > Emulator.getLeftScrollingValue())
	{	centerYX[1] += velocityYX[1];
//System.out.println("	uX.1 v="+velocityYX[1]+" x="+centerYX[1]);	
	}
	else
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation() - velocityYX[1]));			
		}
//System.out.println("	uX.2 v="+velocityYX[1]+" x="+centerYX[1]);	
	}	
	
	////////////////////// Y LOCATION UPDATE//////////////////////
	if(centerYX[0] + velocityYX[0] < Emulator.getBottomScrollingValue() && centerYX[0] + velocityYX[0] > Emulator.getTopScrollingValue())
	{	centerYX[0] += velocityYX[0];
//System.out.println("	uY.1 v="+velocityYX[0]+" y="+centerYX[0]);	
	}
	else
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation() - velocityYX[0]));	
		}
//System.out.println("	uY.2 v="+velocityYX[0]+" y="+centerYX[0]);	
	}

		
	Emulator.getSprites().upDate(playerNum, sprite, velocityYX[1], velocityYX[0]);
		
}
//////////////////////SETTERS AND GETTERS//////////////////////
	
	public double[] getCenterYX() 
	{	return centerYX;
	}
	public void setCenterYX(double[] centerYX) 
	{	this.centerYX = centerYX;
	}
	public void setVelocityYX(double[] velocityYX) 
	{	this.velocityYX = velocityYX;
	}
	public void setPlayerNum(int playerNum) 
	{	this.playerNum = playerNum;
	}
	public double getClimbStrength() {
		return climbStrength;
	}
	public void setClimbStrength(double climbStrength) {
		this.climbStrength = climbStrength;
	}
	public int getScript() 
	{	return script;
	}
	
	public double getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}
	public double getTorque() {
		return torque;
	}
	public void setTorque(double torque) {
		this.torque = torque;
	}
	public double getTopSpeed() {
		return topSpeed;
	}
	public void setTopSpeed(double topSpeed) {
		this.topSpeed = topSpeed;
	}
	public double getJump() {
		return jump;
	}
	public void setJump(double jump) {
		this.jump = jump;
	}
	public double getDoubleJump() {
		return doubleJump;
	}
	public void setDoubleJump(double doubleJump) {
		this.doubleJump = doubleJump;
	}
	
}