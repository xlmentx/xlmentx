package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	Gravity = 0.5,
					Inactive = Emulator.ResolutionXY[0];
					
		///////////////////// PROXIMITY SCAN //////////////////////
	//////////////////////
	public static double[] scanProximity(double[] centerXY, double[] velocityXY)
	{	////////////////////// DEFAULT PROXIMITY RETURN VALUES //////////////////////
						  ////////{ CONTACT X, CONTACT Y,  XTHETA  ,  YTHETA  , FRICTION }////////
		double[] proximityValues ={ Inactive , Inactive , Inactive , Inactive , Inactive };
				 
		////////////////////// PLATFORM SCANS //////////////////////
		for(int i = 0; i < Emulator.Platform.length; i++)
		{	if(Emulator.Platform[i].OnScreen() == true)
			{	////////////////////// PLATFORM VALUES //////////////////////
				double[] platformLocationXY = Emulator.Platform[i].PlatformXY(),
					 	 platformDimensionXY ={ Emulator.Platform[i].Width(), Emulator.Platform[i].Hight()};
				 
				////////////////////// RIGHTWARD COLLISION //////////////////////
				if(centerXY[1] > platformLocationXY[1])
				{	double contact = platformLocationXY[0];
					if(centerXY[0] + velocityXY[0] >= contact && centerXY[0] <= contact)
					{	////////////////////// X CONTACT //////////////////////
						proximityValues[0] = contact;
						////////////////////// THETA //////////////////////
						proximityValues[2] = Math.toRadians(90);
						////////////////////// FRICTION //////////////////////
						proximityValues[4] = Emulator.Platform[i].Friction();
System.out.println("RCollision @ x="+contact+" theta="+Math.toDegrees(proximityValues[2]));
					}
				}	
			
				////////////////////// LEFTWARD COLLISION //////////////////////
				if(centerXY[1] > platformLocationXY[1]+platformDimensionXY[1])
				{	double contact = platformLocationXY[0] + platformDimensionXY[0];
					if(centerXY[0] + velocityXY[0] <= contact && centerXY[0] >= contact)
					{	////////////////////// X CONTACT //////////////////////
						proximityValues[0] = contact;
						////////////////////// CONTACT THETA //////////////////////
						proximityValues[2] = -Math.toRadians(90);
						////////////////////// FRICTION //////////////////////
						proximityValues[4] = Emulator.Platform[i].Friction();
System.out.println("LCollision @ x="+contact+" theta="+Math.toDegrees(proximityValues[2]));
					}
				}

				////////////////////// DOWNWARD COLLISION //////////////////////
				if(centerXY[0] > platformLocationXY[0] && centerXY[0] < platformLocationXY[0]+platformDimensionXY[0])
				{	double 	contact = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]+velocityXY[0]-platformLocationXY[0])+platformLocationXY[1];
System.out.println(" cy="+(centerXY[1]+velocityXY[1])+" py="+contact+" dif="+(centerXY[1]+velocityXY[1]-contact));	
					if(centerXY[1]+velocityXY[1] >= (int)(contact))
					{	////////////////////// Y CONTACT //////////////////////
						proximityValues[1] = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]-platformLocationXY[0])+platformLocationXY[1];
						////////////////////// CONTACT THETA //////////////////////
						proximityValues[3] = Math.atan2(-platformDimensionXY[1], platformDimensionXY[0]);
System.out.println("DCollision @ y="+contact+" theta="+Math.toDegrees(proximityValues[3]));	
						////////////////////// FRICTION //////////////////////
						proximityValues[4] = Emulator.Platform[i].Friction();
					}
				}
			}
		}
		
		////////////////////// RETURN PROXIMITY VALUES //////////////////////
		return proximityValues;
	}
	
		///////////////////// FORCES //////////////////////
	//////////////////////
	public static double[] applyForces(double[] centerXY, double[] velocityXY)
	{
		////////////////////// GRAVITY //////////////////////
		velocityXY[1] += Gravity;
//System.out.println("  Gravity  Vx="+velocityXY[0]+"	Vy="+velocityXY[1]+"	Vm="+Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)));

		////////////////////// PROXIMITY CHECK //////////////////////
		double[] proximityValues = Physics.scanProximity(centerXY, velocityXY),
				 contactXY 		 = {proximityValues[0], proximityValues[1]},
				 contactThetaXY  = {proximityValues[2], proximityValues[3]};
		double	 friction 	  	 =  proximityValues[3];

		//////////////////////SNAP TO CONTACT //////////////////////
		for(int i = 0; i < contactXY.length; i++ )
		{	if( contactXY[i] != Inactive )
			{	centerXY[i] = contactXY[i];
System.out.println("  Snap  XY["+i+"] to "+contactXY[i]);
			}	
		}
	
		////////////////////// CONTACT FORCES //////////////////////
		for(int i = 0; i < contactThetaXY.length; i++ )
		{	if(Math.abs(contactThetaXY[i]) != Inactive)
			{	////////////////////// NORMAL FORCE //////////////////////
				double	velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)), 
						velocityTheta = Math.atan2(-velocityXY[1],velocityXY[0]),
						normalTheta = contactThetaXY[i] + Math.toRadians(90),
						NormalForce = Math.abs(velocityMagnitude*Math.cos(normalTheta-velocityTheta));
					////////////////////// APPLY NORMAL FORCE //////////////////////
					velocityXY[0] = round(velocityXY[0]+NormalForce*Math.cos(normalTheta));
					velocityXY[1] = round(velocityXY[1]-NormalForce*Math.sin(normalTheta));
System.out.println("  vM="+velocityMagnitude+"	vT="+Math.toDegrees(velocityTheta));
System.out.println("  pT="+Math.toDegrees(contactThetaXY[i])+"	nT="+Math.toDegrees(normalTheta));
System.out.println("  NF="+NormalForce+"  xNF="+NormalForce*Math.cos(normalTheta)+"	yNF="+(-NormalForce*Math.sin(normalTheta)));
System.out.println("  Normal   Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
			
				///////////////////// FRICTION //////////////////////
				velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)); 
				velocityTheta = -Math.atan2(velocityXY[1],velocityXY[0]);
				double	frictionForce = Math.abs(friction*Math.cos(contactThetaXY[i]-velocityTheta));
				////////////////////// APPLY FRICTION //////////////////////
//System.out.println("  vM="+round(velocityMagnitude)+"	vT="+round(Math.toDegrees(velocityTheta)));
//System.out.println("  FF="+frictionForce+"  pT="+round(Math.toDegrees(platformTheta)));
					if(velocityXY[0]-frictionForce*Math.cos(velocityTheta) >= 0)
					{	//velocityXY[0] -= frictionForce*Math.cos(velocityTheta);			
					}
					else
					{	//velocityXY[0] = 0;
					}	
				//velocityXY[1] -= frictionForce*Math.sin(velocityTheta);
//System.out.println("  xFF="+-round(frictionForce*Math.cos(velocityTheta))+"	yFF="+round(frictionForce*Math.sin(platformTheta)));
//System.out.println("  Friction Vx="+round(velocityXY[0])+"	Vy="+velocityXY[1]);
			}
		}
			
		////////////////////// RETURN SUM OF FORCES AND LOCATION //////////////////////
System.out.println("  Final    Vx="+round(velocityXY[0])+"	Vy="+round(velocityXY[1])+" Cx="+centerXY[0]+"	Cy="+centerXY[1]);
System.out.println("  Final    Vm="+round(Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)))+"	Vt="+round(Math.toDegrees(-Math.atan2(velocityXY[1],velocityXY[0]))));
		Physics.scanProximity(centerXY, velocityXY);
		return new double[] {round(velocityXY[0]), round(velocityXY[1]), centerXY[0], centerXY[1]};
	}
	
		///////////////////// ROUND VALUE //////////////////////
	//////////////////////
	public static double round(double value)
	{	double percision = 100;

		value = (int)(value*percision)/percision;
		return value;
	}	
	
}