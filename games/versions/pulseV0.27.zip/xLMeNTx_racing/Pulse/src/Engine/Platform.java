package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int 		none=0, 	low=1, 		medium=2, 	high=3, 	max=4;
	static int[]	////////////{ SMALL,   MEDIUM,  LARGE,   XLARGE }///////////////
					GapRates    ={  none,    none,    none,	  none  },
					WallRates   ={  none,    max,    none,   none  },
					DropRates   ={  none,    none,    none,   none  },
					WidthRates  ={  none,    none,    none,   max  },
					InclineRates={  none,    none,    none,   none  },
					DeclineRates={  none,    none,   max,    none  }; 
	
		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double	oFriction = Physics.Gravity*0.5;
	static double[]	ScrollSpeedXY = {0, 0};
	static Random 	Rand = new Random();
	
		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		index,			width, 			hight;
	private double	slope, 			friction;
	private boolean onScreen =  true;
	private double[]platformXY = new double[2];	
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] platformXY)
	{	this.index = index;
		this.platformXY = platformXY;
		width = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax;
		slope = 0;
		friction = oFriction;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	
		///////////////// PLATFORM JUMP /////////////////
		if (platformXY[0]+width <= -Emulator.ResolutionXY[0])
		{
			///////////////// PREVIOUS PLATFORM /////////////////
			int	previous = index - 1;
			if(previous < 0)
			{	previous = Emulator.Platform.length-1;
			}
			double previousXEnd = Emulator.Platform[previous].PlatformXY()[0]+Emulator.Platform[previous].Width(),
				   previousYEnd = Emulator.Platform[previous].PlatformXY()[1]+Emulator.Platform[previous].Width()*(Emulator.Platform[previous].Hight()/Emulator.Platform[previous].Width());
//System.out.println("	"+index+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
				
			///////////////// GAPS /////////////////
			int gapMax = Emulator.ResolutionXY[0],
				gapMin = Emulator.Stand[0].getWidth();
			
			platformXY[0] = previousXEnd;
			if(index == 0)
			{	platformXY[0] = previousXEnd-(Character.BaseStats[2]+Character.StatLimits[2]);
			}
			double ratioSum = 0;
			for(int i = 0; i < GapRates.length; i++)
			{	ratioSum += GapRates[i];
				if(Rand.nextInt(max) + 1 <= Math.pow(GapRates[i],2)/ratioSum)
				{	double range = gapMax/GapRates.length,
						   variance = Rand.nextInt((int)range-gapMin/(i+1))+gapMin/(i+1);
					platformXY[0] = previousXEnd + range*i + variance;
//System.out.println(index+" i="+i+" R="+range+" V="+variance);   		
//System.out.println(index+" Gap="+(platformXY[0]-previousXEnd));   		
				}
			}
			
			///////////////// WALLS /////////////////
			int yShiftMax = Emulator.ResolutionXY[1],
				yShiftMin = Emulator.Stand[0].getHeight()/2;
			
			platformXY[1] = previousYEnd;
			ratioSum = 0;
			for(int i = 0; i < WallRates.length; i++)
			{	ratioSum += WallRates[i];
				if(Rand.nextInt(max) + 1 <= Math.pow(WallRates[i],2)/ratioSum)
				{	double range = yShiftMax/WallRates.length,
						   variance = Rand.nextInt((int)range-yShiftMin/(i+1))+yShiftMin/(i+1);
					platformXY[1] = previousYEnd - (range*i + variance);
//System.out.println(index+" i="+i+" R="+range+" V="+variance);   		
//System.out.println(index+" Wall="+(platformXY[1]-previousYEnd));   		
				}
			}
			
			///////////////// DROPS /////////////////
			for(int i = 0; i < DropRates.length; i++)
			{	ratioSum += DropRates[i];
				if(Rand.nextInt(max) + 1 <= Math.pow(DropRates[i],2)/ratioSum)
				{	double range = yShiftMax/DropRates.length,
				   		   variance = Rand.nextInt((int)range-yShiftMin/(i+1))+yShiftMin/(i+1);
					platformXY[1] = previousYEnd + range*i + variance;
//System.out.println(index+" i="+i+" R="+range+" V="+variance);   		
//System.out.println(index+" Drop="+(platformXY[1]-previousYEnd));   		
				}
			}
	
			///////////////// WIDTH /////////////////
			int widthMax = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax, 
				widthMin = Emulator.Stand[0].getWidth();		
			width = widthMax;    		
			
			ratioSum = 0;
			for(int i = 0; i < WidthRates.length; i++)
			{	ratioSum += WidthRates[i];
				if(Rand.nextInt(max) + 1 <= Math.pow(WidthRates[i],2)/ratioSum)
				{	double 	range = widthMax/WidthRates.length,
						   	variance = Rand.nextInt((int)range-widthMin/(i+1))+widthMin/(i+1);
					width = (int)(range*i + variance);
//System.out.println(index+" wMax="+WidthMax+" i="+i+" iR="+range+" wMin="+WidthMin+" rV="+variance);   		
//System.out.println("   width="+width+" worldWidth="+worldWidth);   		
				}
			}
			
			///////////////// DECLINES /////////////////
			int hightMax = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax; 
			
			hight = 0;
			ratioSum = 0;
			for(int i = 0; i < DeclineRates.length; i++)
			{	ratioSum += DeclineRates[i];
				if(Rand.nextInt(max) + 1 <= Math.pow(DeclineRates[i],2)/ratioSum)
				{	double range = hightMax/DeclineRates.length,
						   variance = Rand.nextInt((int)range);
				hight = (int)(range*i + variance);
//System.out.println(index+" hMax="+HightMax+" i="+i+" iR="+range+" rV="+variance);   		
//System.out.println(index+" hight="+hight);   		
				}
			}							
		}
		
		///////////////// LOCATION UPDATE /////////////////
		platformXY[0] += ScrollSpeedXY[0];
		platformXY[1] += ScrollSpeedXY[1];
		
		///////////////// ON SCREEN UPDATE /////////////////
		onScreen = false;
		///////////////// X CHECK /////////////////
		if(platformXY[0]+width > 0 && platformXY[0] < Emulator.ResolutionXY[0])
		{	///////////////// Y CHECK /////////////////
			if(platformXY[1]+slope*width < Emulator.ResolutionXY[1] || platformXY[1] < Emulator.ResolutionXY[1])
			{	onScreen = true;
			}
		}	
	}		
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] PlatformXY() 
	{	return platformXY;
	}
	public int Width() 
	{	return width;
	}
	public int Hight() 
	{	return hight;
	}
	public double Friction() 
	{	return friction;
	}
	public boolean OnScreen() 
	{	return onScreen;
	}
}