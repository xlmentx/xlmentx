package Engine;
import java.awt.Image;
public class Character 
{		////////////////////// STATIC VARIABLES //////////////////////
	////////////////////// 		
	static double oAccel = Platform.oFriction+0.1;
	
	////////////////////// DEFAULT STATS AND LIMITS //////////////////////
	static double[]	////////////{groundAccel,	airAccel,	 	topSpeed,	 	jump,	  	 	doubleJump} 		
					BaseStats = {oAccel,		oAccel*0.5, 	20,		 		-15,		 	-6		  },
					StatLimits= {0.2,		  	0.2,		  	3,		  		-3,		  		-3		  },
					
					////////////////////// CLASS PERKS //////////////////////
					BaseClass = {0,			  	0,		  		0,		  		0,		  		0		  },
					EarthClass= {0,	 	      	0,		  		0,		  		0,		  		0		  },
					FireClass = {0,			  	0,		  		0,		  		0,		  		0		  },
					WaterClass= {0,			  	0,		  		0,		  		0,		  		0		  },
					AirClass  = {0,			  	0,		  		0,		  		0,		  		0		  };
		
		////////////////////// STAT UPDATES //////////////////////
	////////////////////// 		
	public static double[] updateStats(int playerNum, int classType, int xpFile)
	{	double[]stats = BaseStats,
	
		////////////////////// CURRENT VALUES //////////////////////
				currentXP = {0,0,0,0,0},
				currentClass = BaseClass;
				switch(classType)
				{	case 1:	currentClass = EarthClass;	break;
					case 2:	currentClass = FireClass;	break;
					case 3:	currentClass = WaterClass;	break;
					case 4:	currentClass = AirClass;  	break;
					
				}
	
		////////////////////// SUMATION AND STATS RETURN //////////////////////
		for(int i = 0; i < stats.length; i++)	
		{	stats[i] += (currentXP[i]/10)*StatLimits[i]+currentClass[i];			
		}
		return stats;
	}
	
		////////////////////// SPRITE UPDATE //////////////////////
	////////////////////// 		
	public static Image getSprite(int index)
	{	Image 	 currentSprite = Emulator.none;
		
		////////////////////// PLAYER VALUES //////////////////////
		int 	playerDirection = Emulator.Player[index].getInputXxYy()[1], 
				spriteIndex = (playerDirection+1)/2;
		double[]velocityXY = Emulator.Player[index].getVelocityXY();
				
		////////////////////// RUN //////////////////////
		if(velocityXY[0] != 0)
		{	if(velocityXY[0]*playerDirection > 0)
			{	currentSprite = Emulator.Run[spriteIndex];
			}
			////////////////////// SLIDE //////////////////////
			else
			{	currentSprite = Emulator.Slide[spriteIndex];
			}	
		}
		
		//////////////////////STAND //////////////////////
		else
		{	if(velocityXY[1] == 0)
			{	currentSprite = Emulator.Stand[spriteIndex];
			}
		}
		
		////////////////////// JUMP //////////////////////
		if(velocityXY[1] <= 0)
		{	currentSprite = Emulator.Jump[spriteIndex];
		}
		
		////////////////////// FALL //////////////////////
		else
		{	currentSprite = Emulator.Fall[spriteIndex];
		}
		
		////////////////////// RETURN SPRITE //////////////////////
		return currentSprite;
	}	
}