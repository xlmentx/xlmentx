package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;

public class Platform
{	
			////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int 		None=0, 	Low=2,		Med=20, 	High=60, 	Max=200;
	static int[]	////////////{ SMALL,   MEDIUM,  LARGE}///////////////
					Gaps =		{  None,    None,    None},
					Walls =		{  Low,    High,    Low},
					Drops =		{  Low,   High,    Low},
					Widths =	{  High,    Med,   Low},
					Inclines =	{  High,    Med,    Low},
					Declines =	{  High,    Med,    Low}, 
					uFrictionX=	{  None,    Max,    None}, 
					uFrictionY=	{  None,    Max,    None}; 
		
	static int 		xShiftMax = (int)(Engine.ResolutionXY[0]*0.75),
					xShiftMin = Engine.Stand[0].getWidth(),
					yShiftMax = (int)(Engine.ResolutionXY[1]*0.75),
					yShiftMin = Engine.Stand[0].getHeight()/2,
					WidthMax = (int)(Engine.ResolutionXY[0]*0.75), 
					WidthMin = Engine.Stand[0].getWidth(),		
					AngleMax = 40,
					AngleMin = 0,
					uFrictionMax = 200,
					uFrictionMin = 10;

	static double	RatioSum = 0; 
	static Random 	Rand = new Random();

		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double[]	 ScrollSpeedXY = {0, 0};
			////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		 pIndex;
	private double[] pLocationXY = new double[2],
					 pDimensionXY = new double[2],
					 pFrictionXY = new double[2];
	private double 	 pTheta = 0;
	private boolean  onScreen =  false;
	
			////////////////////// CONSTRUCTORS //////////////////////
	//////////////////////
	public Platform (int pIndex, double[] pLocationXY, double[] pDimensionXY, double pTheta, double[] pFrictionXY)
	{	this.pIndex = pIndex;
		this.pLocationXY = pLocationXY;
		this.pDimensionXY = pDimensionXY;
		this.pFrictionXY = pFrictionXY;
	}
	public Platform (int pIndex)
	{	this.pIndex = pIndex;
		randomize();
	}
	
			////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	///////////////// LOCATION UPDATE /////////////////
		pLocationXY[0] += ScrollSpeedXY[0];
		pLocationXY[1] += ScrollSpeedXY[1];
		
		///////////////// ON SCREEN CHECK /////////////////
		onScreen = false;
		if(pLocationXY[0]+pDimensionXY[0] >= 0 && pLocationXY[0] <= Engine.ResolutionXY[0])
		{	onScreen = true;
//System.out.println("p"+pIndex+" pX="+pLocationXY[0]+" sS="+ScrollSpeedXY[0]);   		
//System.out.println("p"+pIndex+" pY="+pLocationXY[1]+" sS="+ScrollSpeedXY[1]);   		
		}	
	}	
	
			///////////////////// WORLD GENERATOR //////////////////////
	//////////////////////
	public void randomize()
	{	///////////////// PREVIOUS PLATFORM XY /////////////////
		double 	previousXEnd = Engine.Platform[pIndex-1].pLocationXY()[0]+Engine.Platform[pIndex-1].pDimensionXY[0]-1,
	   			previousYEnd = Engine.Platform[pIndex-1].pLocationXY()[1]+Engine.Platform[pIndex-1].pDimensionXY[1];		
//System.out.println("p"+pIndex+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
		///////////////// X SHIFT /////////////////
		RatioSum = 0;
		pLocationXY[0] = previousXEnd+getOffSet(Gaps, xShiftMax, xShiftMin, 0, "Gap");
		///////////////// Y SHIFT /////////////////
		RatioSum = 0;
		pLocationXY[1] = -getOffSet(Walls, yShiftMax, yShiftMin, 0, "Wall");
		pLocationXY[1] = previousYEnd+getOffSet(Drops, yShiftMax, yShiftMin, pLocationXY[1], "Drop");
		///////////////// WIDTH /////////////////
		RatioSum = 0;
		pDimensionXY[0] = getOffSet(Widths, WidthMax, WidthMin, WidthMax, "Width");
		///////////////// TOP THETA /////////////////
		RatioSum = 0;
		pTheta = -getOffSet(Inclines, AngleMax, AngleMin, 0, "Incline");
		pTheta = Math.toRadians(getOffSet(Declines, AngleMax, AngleMin, pTheta, "Decline"));
		pDimensionXY[1] = pDimensionXY()[0]*Math.tan(pTheta);
		///////////////// uFRICTION /////////////////
		RatioSum = 0;
		pFrictionXY[0] = getOffSet(uFrictionX, uFrictionMax, uFrictionMin, 100, "uFrictionX")/100.00;
		RatioSum = 0;
		pFrictionXY[1] = getOffSet(uFrictionY, uFrictionMax, uFrictionMin, 100, "uFrictionY")/100.00;
	}
	
			///////////////////// OFFSETS //////////////////////
	//////////////////////
	public double getOffSet(int[] array, int valueMax, int valueMin, double oValue, String type)
	{	double 	value = oValue,
				ratioScaling = 1;
		for(int i = 0; i < array.length; i++)
		{	RatioSum += array[i];
			if(RatioSum > Max)
			{ 	ratioScaling = Max/RatioSum;
			}
			double rand = Rand.nextInt(Max)+1;
			if(rand <= array[i]*ratioScaling)
			{	int rangeStart = valueMax/array.length*i,
					offset = Rand.nextInt(valueMax/array.length-valueMin/(i+1))+valueMin/(i+1);
				value = rangeStart+offset;
//System.out.println("p"+pIndex+" "+type+"="+offset+" rangeStart="+rangeStart);   		
			}
		}
		return value;
	}	

			////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] pLocationXY() 
	{	return pLocationXY;
	}
	public double[] pDimensionXY() 
	{	return pDimensionXY;
	}
	public double pTheta() 
	{	return pTheta;
	}
	public double[] pFrictionXY() 
	{	return pFrictionXY;
	}
	public boolean OnScreen() 
	{	return onScreen;
	}
}