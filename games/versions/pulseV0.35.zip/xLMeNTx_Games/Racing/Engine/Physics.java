package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{			////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	Gravity = 0.5,
					None = 100,
					theta;
	static double[] velocityXY,
					centerXY;
	
			///////////////////// PROXIMITY CHECK //////////////////////
	//////////////////////
	public static double[] proximityScan(int xInput, double[] oCenterXY, double[] dimensionXY, double[] oVelocityXY)
	{	theta = None;
 		velocityXY = new double[]{oVelocityXY[0], oVelocityXY[1]+Gravity};
		centerXY = oCenterXY;
System.out.println("\nPhysics	Cx="+round(centerXY[0])+"  Cy="+round(centerXY[1])+"	Vx="+round(velocityXY[0])+"  Vy="+round(velocityXY[1]));
		////////////////////// VISIBLE PLATFORMS //////////////////////
		for(int i = 0; i < Engine.Platform.length; i++)
		{	if(Engine.Platform[i].OnScreen() == true)
			{	double	 vTheta = Math.atan2(velocityXY[1],velocityXY[0]);
				double[] pLocationXY = {Engine.Platform[i].pLocationXY()[0], Engine.Platform[i].pLocationXY()[1]};
				double[] pDimensionXY = {Engine.Platform[i].pDimensionXY()[0], Engine.Platform[i].pDimensionXY()[1]};
				
				////////////////////// TOP CONTACT //////////////////////
				double	pTheta = Engine.Platform[i].pTheta(),
						xContact = (Math.tan(vTheta)*centerXY[0]-Math.tan(pTheta)*pLocationXY[0]+pLocationXY[1]-centerXY[1])/(Math.tan(vTheta)-Math.tan(pTheta)),
						yContact = Math.tan(pTheta)*(xContact-pLocationXY[0])+pLocationXY[1];
System.out.println("   p"+i+" gStart="+pLocationXY[0]+" xContact="+xContact+" gEnd="+(pLocationXY[0]+pDimensionXY[0])+" width="+pDimensionXY[0]);
System.out.println("        gStart="+(int)pLocationXY[0]+" xContact="+(int)xContact+" gEnd="+((int)pLocationXY[0]+pDimensionXY[0])+" width="+pDimensionXY[0]);
				if(xContact >= pLocationXY[0] && xContact <= pLocationXY[0]+pDimensionXY[0] && Math.cos(pTheta-Math.toRadians(90)-vTheta) <= 0)
				{	collisionCheck(xInput, new double[]{xContact,yContact}, pTheta, Engine.Platform[i].pFrictionXY()[0]);
				}
				else
				{	////////////////////// LEFT CONTACT //////////////////////
					pTheta = -Math.toRadians(90);
					xContact = pLocationXY[0];
					yContact = Math.tan(vTheta)*(xContact-centerXY[0])+centerXY[1];
System.out.println("     lWall="+round(pLocationXY[1])+" yContact="+round(yContact));
					if( yContact > pLocationXY[1] && Math.cos(pTheta-Math.toRadians(90)-vTheta) <= 0)
					{	collisionCheck(xInput, new double[]{xContact,yContact}, -Math.toRadians(90), Engine.Platform[i].pFrictionXY()[1]);
					}
					else
					{	////////////////////// RIGHT CONTACT //////////////////////
						pTheta = Math.toRadians(90);
						xContact = pLocationXY[0]+pDimensionXY[0];
						yContact = Math.tan(vTheta)*(xContact-centerXY[0])+centerXY[1];
System.out.println("     rWall="+round(pLocationXY[1]+pDimensionXY[1])+" yContact="+round(yContact));
						if( yContact > pLocationXY[1]+pDimensionXY[1] && Math.cos(pTheta-Math.toRadians(90)-vTheta) <= 0)
						{	collisionCheck(xInput, new double[]{xContact,yContact}, Math.toRadians(90), Engine.Platform[i].pFrictionXY()[1]);
						}
					}	
				}
			}
		}
//System.out.println("   finalSum  Vx="+round(velocityXY[0])+"  Vy="+round(velocityXY[1])+"  Cx="+round(centerXY[0])+"  Cy="+round(centerXY[1]));
		return new double[] {centerXY[0],centerXY[1],velocityXY[0],velocityXY[1], theta};
	}

			///////////////////// COLLISION CHECK //////////////////////
	//////////////////////
	private static void collisionCheck(int xInput, double[] contactXY, double pTheta, double pFriction)
	{	////////////////////// PROXIMITY RANGE //////////////////////
//System.out.println("        xContact="+round(contactXY[0])+" xCenter="+round(centerXY[0])+" xVelocity="+round(velocityXY[0])+" xDistace"+(int)Math.abs(centerXY[0]-contactXY[0]));						
//System.out.println("        yContact="+round(contactXY[1])+" yCenter="+round(centerXY[1])+" yVelocity="+round(velocityXY[1])+" yDistace"+(int)Math.abs(centerXY[1]-contactXY[1]));						
		if(Math.abs(velocityXY[0]) >= (int)Math.abs(centerXY[0]-contactXY[0]) && Math.abs(velocityXY[1]) >= (int)Math.abs(centerXY[1]-contactXY[1]))
		{	centerXY = contactXY;
			theta = Math.abs(pTheta) < Math.abs(theta)? pTheta: theta;
System.out.println("          collision Cx="+round(centerXY[0])+" Cy="+round(centerXY[1])+" pT="+round(Math.toDegrees(pTheta)));						
			////////////////////// NORMAL FORCE //////////////////////
			double	vTheta = Math.atan2(velocityXY[1],velocityXY[0]),
					nTheta = pTheta-Math.toRadians(90),
					nForce = Math.abs(Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2))*Math.cos(nTheta-vTheta));
			velocityXY[0] += nForce*Math.cos(nTheta);
			velocityXY[1] += nForce*Math.sin(nTheta);
//System.out.println("          nF="+round(nForce)+" nFX="+round(nForce*Math.cos(nTheta))+" nFY="+round(nForce*Math.sin(nTheta)));	
			////////////////////// FRICTION FORCE //////////////////////
			if(xInput*velocityXY[0] <= 0)
			{	double	frictionTheta = Math.atan2(-velocityXY[1],velocityXY[0])+Math.toRadians(180),
						frictionForce = nForce*pFriction;
				if(frictionForce > Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)))
				{	frictionForce = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2));
				}
				//velocityXY[0] += frictionForce*Math.cos(frictionTheta);
				//velocityXY[1] -= frictionForce*Math.sin(frictionTheta);
//System.out.println("  frictionForce Fx="+round(frictionForce*Math.cos(frictionTheta))+"  Fy="+round(-frictionForce*Math.sin(frictionTheta)));
			}
		}
	}		
		
			///////////////////// ROUND VALUES //////////////////////
	//////////////////////
	static double round(double num)
	{	double percision = 100;
		num = ((int)(num*percision))/percision;
		return num;
	}
}