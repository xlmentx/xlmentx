package Engine;
import java.awt.Image;
public class Player 	
{	////////////////////// ATRIBUTES //////////////////////
	private int			xCenter,		yCenter,	playerNum;		
	private double		acceleration,	torque,			topSpeed,	
						jump,			doubleJump,		climbStrength;
	
	////////////////////// USER INPUT //////////////////////
	private int 		xDirection=1,				yDirection,	
						doubleJumpAllow=1,		yKeyPressed=0;
	
						
	//////////////////////PHYSICS//////////////////////
	private int 		xCollision, yCollision, 
						currentPlatform,	previousPlatform,	nextPlatform;		
	private double		ground,theta,		platformContact,	gradient,				
						friction,
						wall,				wallTop,
						wallJumpCap,				
						xVelocity,	yVelocity, gravity=0.5;		
	
	////////////////////// GAME PLAY//////////////////////
	private int			script=0;			
						
	private double		yScrollLimit,
	
						respawnDistance;
						  			
	////////////////////// SPRITES //////////////////////
	private int			sprite=1;	
		
//////////////////////CONSTRUCTOR//////////////////////
public Player (int xCenter, int yCenter, int playerNum)
{	this.xCenter = xCenter;
	this.yCenter = yCenter;
	this.playerNum = playerNum;
}

////////////////////// PLAYER CLASS UPDATE //////////////////////
public void update( int xInput, int yInput) 
{	System.out.println(" ");
	///////////////////// DIRECTION CHECK //////////////////////
//////////////////////
	xDirection = (xVelocity != 0)? 
		(int)(xVelocity/Math.abs(xVelocity)): xDirection;	
	yDirection = (yVelocity != 0)? 
		(int)(yVelocity/Math.abs(yVelocity)): yDirection;	
					
	///////////////////// COLLISION CHECK //////////////////////
//////////////////////
	xCollision = 0;			wall = xDirection*Emulator.getResolutionX();
	xCollision = 0;			ground = Emulator.getResolutionX();			friction = 0;
	////////////////////// CHECK ALL PLATFORMS //////////////////////
	for(int i = 0; i < Emulator.getPlatform().length; i++)
	{	double	xStart = Emulator.getPlatform()[i].getPlatformXlocation(), 
				xEnd = xStart + Emulator.getPlatform()[i].getWidth(),
				yStart = Emulator.getPlatform()[i].getPlatformYlocation(),
				yEnd = yStart - Emulator.getPlatform()[i].getHight(),
				slope = -Emulator.getPlatform()[i].getHight()/Emulator.getPlatform()[i].getWidth();
		////////////////////// WALL Y RANGE //////////////////////
		if(yCenter > yStart && xDirection == 1 || yCenter < yEnd && xDirection == -1)
		{	////////////////////// WALL X RANGE //////////////////////
			if(xCenter + xVelocity >= xStart && xCenter <= xStart || xCenter + xVelocity <= xEnd && xCenter >= xEnd)
			{	////////////////////// WALL //////////////////////
				wall = (xDirection == 1)? 
						xStart: xEnd;						
				xCollision = 1;
//System.out.println("pl"+i+" W="+wall+" xd="+xDirection+"xc="+xCollision+" w="+wall);
			}
		}
		////////////////////// GROUND X RANGE //////////////////////
		if(xCenter > xStart && xCenter < xEnd)
		{	////////////////////// GROUND Y RANGE //////////////////////
			if(yCenter + yVelocity >= slope*(xCenter-xStart)+yStart)
			{	////////////////////// GROUND //////////////////////
				ground = slope*(xCenter-xStart)+yStart;
				yCollision = 1;
				////////////////////// SLOPE //////////////////////
				theta = Math.atan(slope);
				////////////////////// FRICTION //////////////////////
				friction = (xDirection == 1)? 
						Emulator.getPlatform()[i].getFriction(): -Emulator.getPlatform()[i].getFriction();
//System.out.println("pl"+i+" G="+ground+" xD="+ xDirection+" xc="+xCollision+" g="+ground);
			}			
		}
	}	
	
	////////////////////// X INPUT //////////////////////
//////////////////////
	if(Math.abs(xInput) == 1 && script == 0)
	{	////////////////////// WALL FREE //////////////////////
		if(xCollision == 0)
		{	sprite = 2;
			////////////////////// ACCELERATION //////////////////////
			if(Math.abs(xVelocity + acceleration*xInput*Math.cos(theta)) < topSpeed*Math.cos(theta))
			{	////////////////////// X DIRECTION ////////////////////// 	
				xVelocity += (yCollision != 0)?
					////////////////////// GROUND : AIR //////////////////////
					acceleration*xInput*Math.cos(theta): acceleration/2.0*xInput;
				////////////////////// Y DIRECTION ////////////////////// 	
				yVelocity += acceleration*xInput*Math.sin(theta); 	 
System.out.println("xI.1 xa="+acceleration*xInput*Math.cos(theta)+" xv="+xVelocity+" ya="+acceleration*xInput*Math.sin(theta)+" yv="+yVelocity);
			}
		}	
		////////////////////// WALL //////////////////////
		else
		{	////////////////////// AIR //////////////////////
			if(yCollision != 0)
				////////////////////// CLIMB //////////////////////
				yVelocity = climbStrength;
System.out.println("xI.4  cd="+xDirection+" ys="+yVelocity+" xs="+xVelocity+" g="+gradient);
		}
	}
	
	
	////////////////////// NO X INPUT //////////////////////
//////////////////////
	if(xInput == 0 && script == 0)
	{		
	}	
	
	
	////////////////////// Y INPUT //////////////////////
//////////////////////
	if(yInput == 1 && yKeyPressed == 0 && script == 0) 
	{	////////////////////// KEY PRESSED //////////////////////
		yKeyPressed = 1;
		////////////////////// GROUND JUMP //////////////////////
		if(yCollision != 0)
		{	yVelocity = jump;	
			doubleJumpAllow = 1;
System.out.println("y.1  ys="+yVelocity+" cy="+yCenter+" yI="+jump);						
		}
		////////////////////// AIR //////////////////////
		else
		{	////////////////////// COLLISION FREE //////////////////////
			if(xCollision == 0)
			{	////////////////////// DOUBLE JUMP //////////////////////
				if(doubleJumpAllow == 1)
				{	yVelocity = (yVelocity+doubleJump>=jump && yVelocity<0)? yVelocity + doubleJump: doubleJump;
					doubleJumpAllow = 0;					
System.out.println("y.2  ys="+yVelocity+" cy="+yCenter+" yI="+yInput);						
				}
			}
			//////////////////////COLLISION FREE //////////////////////
			else
			{	////////////////////// WALL JUMP //////////////////////
				yVelocity = jump*0.5+climbStrength*2;
				xVelocity = -xDirection*Math.abs(jump*0.5);	
				doubleJumpAllow = 1;
System.out.println("y.4  ys="+yVelocity+" cy="+yCenter+" wt="+(jump*0.5+climbStrength*2));						
			}	
		}
	}
	
	
	////////////////////// Y NONE //////////////////////
//////////////////////
	if(yInput == 0)
	{	yKeyPressed = 0;
	}
	
		////////////////////// PHYSICS //////////////////////
//////////////////////
	////////////////////// FORCES //////////////////////
	yVelocity += gravity;
System.out.println("     vY.1 g="+gravity+" yV="+yVelocity+" cy="+yCenter);	
	
	////////////////////// WALL //////////////////////
	if(xCenter + xVelocity >= wall && xDirection == 1 || xCenter + xVelocity <= wall && xDirection == -1)
	{	////////////////////// xALLIGNMENT //////////////////////
		xCenter = (int)wall;
		xVelocity = 0;
System.out.println("   vX.1 w="+wall+" xV="+xVelocity+" cx="+xCenter);
		////////////////////// FRICTION //////////////////////
		yVelocity += -friction*yDirection;
System.out.println("     vY.2 f="+(-friction*yDirection)+" yV="+yVelocity+" cy="+yCenter);
	}
	
	/////////////////////// GROUND //////////////////////
	if(yCenter + yVelocity >= ground)
	{	////////////////////// xALLIGNMENT //////////////////////
		yCenter = (int)ground;
		yVelocity = 0;
System.out.println("     vY.3 g="+ground+" yV="+yVelocity+" cy="+yCenter);
		////////////////////// FRICTION //////////////////////
		if(xDirection != xInput && (int)xVelocity != 0)
		{	xVelocity -= friction;
System.out.println("   vX.2 f="+friction+" xV="+xVelocity+" cx="+xCenter);
		}
	}
	
	
	//////////////////////LEDGE TAKE OFF //////////////////////
	
	//////////////////////RESPAWN//////////////////////
	if(yCenter+yVelocity>=Emulator.getResolutionY())
	{	respawnDistance=Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue();
		script=1;
	}	
	//////////////////////SCRIPT 1 RESPAWN//////////////////////
	if(script==1)
	{	double	restartScrollSpeed=100;
		sprite= 0;
		yCenter=Emulator.getTopScrollingValue();
		yVelocity=0;
System.out.println("y..36  ys="+yVelocity+" cy="+yCenter);
		xVelocity=0;
//System.out.println("x.32 xs="+xVelocity+" cx="+centerXlocation+" RD="+respawnDistance);
		if(respawnDistance+restartScrollSpeed <= 0)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+restartScrollSpeed);
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()+restartScrollSpeed/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()+restartScrollSpeed/1.6));
			respawnDistance+=restartScrollSpeed;
		}
		else
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation()-respawnDistance));
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()-respawnDistance/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()-respawnDistance/1.6));
			script=0;
		}	
	}

	////////////////////// X LOCATION UPDATE//////////////////////
	if(xCenter + (int)xVelocity < Emulator.getRightScrollingValue() && xCenter + (int)xVelocity > Emulator.getLeftScrollingValue())
	{	xCenter += xVelocity;
System.out.println("	uX.1 v="+xVelocity+" x="+xCenter);	
	}
	else
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation() - (int)xVelocity));			
		}
System.out.println("	uX.2 v="+xVelocity+" x="+xCenter);	
	}	
	
	////////////////////// Y LOCATION UPDATE//////////////////////
	if(yCenter + (int)yVelocity < Emulator.getBottomScrollingValue() && yCenter + (int)yVelocity > Emulator.getTopScrollingValue())
	{	yCenter += yVelocity;
System.out.println("	uY.1 v="+yVelocity+" y="+yCenter);	
	}
	else
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation() - (int)yVelocity));	
		}
System.out.println("	uY.2 v="+yVelocity+" y="+yCenter);	
	}

		
	Emulator.getSprites().upDate(playerNum, sprite, xVelocity, yVelocity);
		
}
//////////////////////SETTERS AND GETTERS//////////////////////
	
	public int getXCenter() 
	{	return xCenter;
	}
	public void setXCenter(int xCenter) 
	{	this.xCenter = xCenter;
	}
	public int getYCenter() 
	{	return yCenter;
	}
	public void setYCenter(int yCenter) 
	{	this.yCenter = yCenter;
	}
	public void setYVelocity(double yVelocity) 
	{	this.yVelocity = yVelocity;
	}
	public double getGradient() 
	{	return gradient;
	}
	public void setGradient(double gradient) 
	{	this.gradient = gradient;	
	}
	public void setPlayerNum(int playerNum) 
	{	this.playerNum = playerNum;
	}
	public double getClimbStrength() {
		return climbStrength;
	}
	public void setClimbStrength(double climbStrength) {
		this.climbStrength = climbStrength;
	}public void setPlatformContact(double platformContact) 
	{	this.platformContact = platformContact;
	}
	public double getWall() 
	{	return wall;
	}
	public double getPlatformContact() 
	{	return platformContact;
	}
	public double getWallTop() 
	{	return wallTop;
	}
	public int getScript() 
	{	return script;
	}
	
	public double getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}
	public double getTorque() {
		return torque;
	}
	public void setTorque(double torque) {
		this.torque = torque;
	}
	public double getTopSpeed() {
		return topSpeed;
	}
	public void setTopSpeed(double topSpeed) {
		this.topSpeed = topSpeed;
	}
	public double getJump() {
		return jump;
	}
	public void setJump(double jump) {
		this.jump = jump;
	}
	public double getDoubleJump() {
		return doubleJump;
	}
	public void setDoubleJump(double doubleJump) {
		this.doubleJump = doubleJump;
	}
	public double getWallJumpCap() 
	{	return wallJumpCap;
	}
}