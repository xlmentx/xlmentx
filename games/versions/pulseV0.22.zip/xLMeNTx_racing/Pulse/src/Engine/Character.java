package Engine;
import java.awt.Image;
public class Character 
{		////////////////////// STAT UPDATES //////////////////////
	////////////////////// 		
	public double[] updateStats(int playerNum, int classType, int xpFile)
	{	double friction = Platform.defaultFriction;
	
		////////////////////// DEFAULT STATS //////////////////////
				///////{grndAccel,		airAccel,		topSpeed,		jump,	  		doubleJump} 		
		double[]baseStats = {friction+0.2,	0.2,		   	20,			 	-15,			-5	},
				earthClass= {0,				0,				0,				0,				0	},
				fireClass = {0,				0,				0,				0,				0	},
				waterClass= {0,				0,				0,				0,				0	},
				airClass  = {0,				0,				0,				0,				0	},
		
		////////////////////// STAT LIMITS //////////////////////					
				statLimits= {0.3,			0.3,			5,				-5,				-10	},
				
		////////////////////// CURRENT XP //////////////////////
				currentXP = {0,	 			0,				0,		 		0,				0	},
			
		////////////////////// CURRENT CLASS //////////////////////
				currentClass = {0,0,0,0,0};
				switch(classType)
				{	case 1:	currentClass = earthClass;	break;
					case 2:	currentClass = fireClass;	break;
					case 3:	currentClass = waterClass;	break;
					case 4:	currentClass = airClass;  	break;
				}
	
		////////////////////// FINAL STATS AND RETURN //////////////////////
		for(int i = 0; i < baseStats.length; i++)	
		{	baseStats[i] += (currentXP[i]/100)*statLimits[i]+currentClass[i];			
		}
		return baseStats;
	}
	
		////////////////////// SPRITE UPDATE //////////////////////
	////////////////////// 		
	public Image getSprite(int index)
	{	int [] 	 inputXxYy = Emulator.Player()[index].getInputXxYy(); 
		double[] velocityXY = Emulator.Player()[index].getVelocityXY(),
				 proximityXYF = Emulator.Player()[index].getProximityXYF();
		
		Image 	 currentSprite = Emulator.None();
		
		////////////////////// RIGHTWARD MOVEMENT //////////////////////
		if(velocityXY[0] > 0)
		{	if(inputXxYy[0] >= 0)
			{	currentSprite = Emulator.getRunRight();
			}
			else
			{	currentSprite = Emulator.getSlideRight();
			}
		}
		
		////////////////////// LEFTWARD MOVEMENT //////////////////////
		if(velocityXY[0] < 0)
		{	if(inputXxYy[0] <= 0)
			{	currentSprite = Emulator.getRunLeft();
			}
			else
			{	currentSprite = Emulator.getSlideLeft();
			}
		}

		////////////////////// UPWARD MOVEMENT //////////////////////
		if(velocityXY[1] <= 0)
		{	if(inputXxYy[1] >= 0)
			{	currentSprite = Emulator.getJumpRight();
			}
			else
			{	currentSprite = Emulator.getJumpLeft();
			}
		}
		
		////////////////////// DOWNWARD MOVEMENT //////////////////////
		else
		{	if(inputXxYy[1] > 0)
			{	currentSprite = Emulator.getFallRight();
			}
			else
			{	currentSprite = Emulator.getFallLeft();
			}
		}
		
		////////////////////// NO MOVEMENT //////////////////////
		if(velocityXY[0] == 0)
		{	if(proximityXYF[1] != 180)
			{	if(inputXxYy[1] >= 0)
				{	currentSprite = Emulator.getStandRight();
				}
				else
				{	currentSprite = Emulator.getStandLeft();
				}
			}
		}
		
		return currentSprite;
	}	
}