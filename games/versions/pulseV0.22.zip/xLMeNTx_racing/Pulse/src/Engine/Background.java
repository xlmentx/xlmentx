package Engine;

import java.awt.Image;

public class Background 
{	//////////////////////DECLARATIONS//////////////////////		
	private int				backgroundNum,				backgroundType;
	private double     		relativeMidStart=0.2,		relativeForeStart=.4,		midYSpeed=.10,	
							foreYSpeed=.194,			backgroundXvalue,	
	 						backgroundYvalue,				
							backgroundWidth=1920;
	private Image			currentBackGround,			currentMidGround,			currentForeGround;
	
	//////////////////////CONSTRUCTOR//////////////////////
	public Background (int x, int y)
	{	backgroundXvalue = x;
		backgroundYvalue = y;
	}
	//////////////////////BACKGROUND UPDATE//////////////////////
	public void update() 
	{	//////////////////////BACKGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.CurrentLevel())
		{	case  1: currentBackGround = Emulator.getLevel1_BackGround();   break;
		}
		//////////////////////MIDGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.CurrentLevel())
		{	case  1: currentMidGround = Emulator.getLevel1_MidGround();   break;
		}
		//////////////////////FOREGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.CurrentLevel())
		{	case  1: currentForeGround = Emulator.getLevel1_ForeGround();   break;
		}

		//////////////////////Y POSITION//////////////////////
		switch(backgroundType)
		{	case 2:	backgroundYvalue =(int)(Emulator.getResolutionY()*relativeMidStart);
					break;
			case 3:	backgroundYvalue =(int)(Emulator.getResolutionY()*relativeForeStart);
					break;		
		}
		
		if ( backgroundXvalue <= -backgroundWidth)
		{	switch(backgroundNum)
			{	case 1: backgroundXvalue = Emulator.MidGround2().getBackgroundXvalue()+backgroundWidth;break;
				case 2: backgroundXvalue = Emulator.MidGround1().getBackgroundXvalue()+backgroundWidth;break;
				case 3: backgroundXvalue = Emulator.ForeGround2().getBackgroundXvalue()+backgroundWidth;break;
				case 4: backgroundXvalue = Emulator.ForeGround1().getBackgroundXvalue()+backgroundWidth;break;
			}
		}
		if ( backgroundXvalue >= backgroundWidth)
		{	switch(backgroundNum)
			{	case 1: backgroundXvalue = Emulator.MidGround2().getBackgroundXvalue()-backgroundWidth;break;
				case 2: backgroundXvalue = Emulator.MidGround1().getBackgroundXvalue()-backgroundWidth;break;
				case 3: backgroundXvalue = Emulator.ForeGround2().getBackgroundXvalue()-backgroundWidth;break;
				case 4: backgroundXvalue = Emulator.ForeGround1().getBackgroundXvalue()-backgroundWidth;break;
			}
		}  
	}
	//////////////////////GETTERS AND SETTERS//////////////////////
	public Image getCurrentBackGround() 
	{	return currentBackGround;
	}
	public Image getCurrentMidGround() 
	{	return currentMidGround;
	}
	public Image getCurrentForeGround() 
	{	return currentForeGround;
	}
	public	double getBackgroundXvalue() 
	{	return backgroundXvalue;
	}
	public void setBackgroundXvalue(double backgroundXvalue) 
	{	this.backgroundXvalue = backgroundXvalue;
	}
	public double getBackgroundYvalue() 
	{	return backgroundYvalue;
	}
	public void setBackgroundYvalue(double backgroundYvalue) 
	{	this.backgroundYvalue = backgroundYvalue;
	}
	public void setBackgroundType(int backgroundType) 
	{	this.backgroundType = backgroundType;	
	}
	public void setBackgroundNum(int backgroundNum) 
	{	this.backgroundNum = backgroundNum;	
	}
}