package Engine;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.ImageObserver;
import java.awt.Graphics;
import java.net.URL;
import java.util.Random;

import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Emulator 
extends Applet 
implements Runnable, KeyListener
{	//////////////////////STATIC DECLARATIONS//////////////////////
	private static int 			ResolutionY=540,							ResolutionX= ResolutionY*16/9, 	// 1080p=16/9
								BottomScrollingValue=(ResolutionY/3*2),	TopScrollingValue = (ResolutionY/3),
								RightScrollingValue = (ResolutionX/10)*3,	LeftScrollingValue = (ResolutionX/10),
								PlatfromOffset=BottomScrollingValue-490,	LoadingNum, firstPlatform,leftPlatformLimit,
								CurrentTime, 								
								MatchEndTime=1000;
	private static int[]        inputXxYy = {0,0,0,0};
	private static double 		ResolutionOffset=(ResolutionY-720.0)*0.267,	i, gameSpeed=100, StartTime;
	//////////////////////DYNAMIC DECLARATIONS//////////////////////
	private static 	Player[]	Player = new Player[1];
	private static	Character 	Character = new Character();
	private static	Sprites 	Sprite = new Sprites();
	private static 	Platform[]	Platform = new Platform[5];
	private static 	Background 	BackGround,						MidGround1,        				MidGround2,	
								ForeGround1,        			ForeGround2;
	private static wallMarker[]	Marker = new wallMarker[6];
	
	private boolean 			keyHeld;
	static Random 				Generator = new Random();
	private static int			CurrentLevel= 1,   landScape= 8,
								MatchOver;
	
	//////////////////////SPRITE DECLARATIONS//////////////////////
	private static Image 		image,  					none,
								
								//////////////////////CHARACTER SPRITES//////////////////////
								standRight,					standLeft, 					runRight,		
								runLeft, 			 		pushRight,					pushLeft,
								jumpRight, 					jumpLeft, 
								climbJumpRight,				climbJumpLeft,				slideRight, 	
								slideLeft, 					climbRight,					climbLeft,
								fallLeft,					fallRight,					wallLeapLeft,
								wallLeapRight,				wallSlideRight,				wallSlideLeft,			
								
								//////////////////////PLATFORM SPRITES//////////////////////
								level1_base,	level1_slope,
								
								//////////////////////BACKGROUND SPRITES//////////////////////
								level1_ForeGround,			level1_MidGround,			level1_BackGround,								
								
								//////////////////////EDITORIAL SPRITES//////////////////////
								wall,		wallJumpCap,	virticalScroll,	horrizontalScroll;
						
	//////////////////////RENDERING DECLARATIONS//////////////////////
	private URL base;
	private Graphics second;
	
	//////////////////////INITIALIZE//////////////////////
	@Override 
	public void init()
	{	//////////////////////ROOM PROPERTIES//////////////////////
		setSize(ResolutionX,ResolutionY);
		setBackground(Color.BLACK);
		setFocusable(true);
		Frame myframe = (Frame) this.getParent().getParent();
		myframe.setTitle("pulse");
		addKeyListener(this);
		try 
	   	{	base = getDocumentBase();
	   	} 
		catch (Exception e) 
		{
		}

		//////////////////////SPRITE TO DIRECTORY ASSIGNMENT//////////////////////	

		//////////////////////PLATFORM SPRITES//////////////////////					
		level1_base  = getImage(base, "data/platforms/base.png");
		level1_slope  = getImage(base, "data/platforms/slope.png"); 	
		
		//////////////////////BACKGROUND SPRITES//////////////////////			
	   	level1_ForeGround = getImage(base, "data/level12/Backgrounds/level12foreground.png");
	   	level1_MidGround = getImage(base, "data/level12/Backgrounds/level12midground.PNG");
	   	level1_BackGround= getImage(base, "data/level12/Backgrounds/level12background.png");

	   	//////////////////////CHARACTER SPRITES//////////////////////			
		standRight = getImage(base, "data/players/standright.png");
		standLeft = getImage(base, "data/players/standleft.png");
		runLeft = getImage(base, "data/players/runleft.png");
		runRight = getImage(base, "data/players/runright.png");
		pushLeft = getImage(base, "data/players/pushLeft.png");
		pushRight = getImage(base, "data/players/pushRight.png");
		jumpRight = getImage(base, "data/players/jumpright.png");
		jumpLeft = getImage(base, "data/players/jumpleft.png");
		slideRight = getImage(base, "data/players/slideright.png");
		slideLeft = getImage(base, "data/players/slideleft.png"); 
		climbRight = getImage(base, "data/players/climbright.png");
		climbLeft = getImage(base, "data/players/climbleft.png"); 
		fallRight = getImage(base, "data/players/fallRight.png");
		fallLeft = getImage(base, "data/players/fallLeft.png");
		wallLeapRight = getImage(base, "data/players/wallLeapRight.png");
		wallLeapLeft = getImage(base, "data/players/wallLeapleft.png");
		wallSlideRight = getImage(base, "data/players/wallslideright.png");
		wallSlideLeft = getImage(base, "data/players/wallslideleft.png");
		climbJumpRight = getImage(base, "data/players/climbJumpRight.png");
		climbJumpLeft = getImage(base, "data/players/climbJumpleft.png");

		//////////////////////EDITORIAL SPRITES//////////////////////
		horrizontalScroll = getImage(base, "data/markers/HorrizontalScroll.png");
		virticalScroll = getImage(base, "data/markers/VirticalScroll.png");
		wall = getImage(base, "data/markers/Wall.png");
		wallJumpCap = getImage(base, "data/markers/WallJumpCap.png");
	}
	//////////////////////OBJECT ROOM LOCATION//////////////////////
   	@Override
   	public void start() 
 	{	//////////////////////BACKGROUNDS//////////////////////
   		BackGround = new Background(0,0);		BackGround.setBackgroundType(1);
   		MidGround1 = new Background(0,175);		MidGround1.setBackgroundType(2);	MidGround1.setBackgroundNum(1);
   		MidGround2 = new Background(-1920,175);	MidGround2.setBackgroundType(2);	MidGround2.setBackgroundNum(2);
   		ForeGround1 = new Background(0,350);	ForeGround1.setBackgroundType(3);	ForeGround1.setBackgroundNum(3);
   		ForeGround2 = new Background(-1920,350);ForeGround2.setBackgroundType(3);	ForeGround2.setBackgroundNum(4);
   		
  		//////////////////////PLATFORMS//////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	Platform[i] = new Platform(new double[]{-960+720*i, BottomScrollingValue}, 720, i); 
   		}
   		
   		//////////////////////PLAYERS//////////////////////
   		for(int i=0; i < Player.length; i++)
   		{	Player[i] = new Player(new double[]{LeftScrollingValue+50*i, TopScrollingValue}, i, Character.updateStats(i, 0, 0));	
   		}

   		//////////////////////EDITORIAL//////////////////////
   		for(int i=0; i < Marker.length; i++)
   		{	Marker[i] = new wallMarker(0,0);
   			Marker[i].setMarkerNumber(i);
   		}

   		//////////////////////GAMETHREAD//////////////////////
   	   	Thread nonamethread = new Thread(this);	
   		nonamethread.start();
}   		

   	//////////////////////GAME LOOP//////////////////////
   	@Override
   	public void run()
   	{	while (true) 
   		{	//////////////////////GAME LOOP SPEED//////////////////////
   			try 
   			{	Thread.sleep((int)(10*(100/gameSpeed)));
   			} 
   			catch (InterruptedException e) 
   			{	e.printStackTrace();
   			}
   			
   			//////////////////////GAME TIME//////////////////////
   			if(StartTime!=0)
   			{	CurrentTime=(int)(System.currentTimeMillis()-StartTime)/1000;
   			}
   			if(CurrentTime>=MatchEndTime)
   			{	landScape=0;
   			}	
   			if(MatchOver>=4)
   			{	System.out.println("match over");
   			}
   			
   			//////////////////////CHARACTER UPDATE//////////////////////
   			for(int i=0; i < Player.length; i++)
   			{	Player[i].update(inputXxYy);
   			}
   			//////////////////////PLATFORM UPDATE//////////////////////
   			for(int i=0; i < Platform.length; i++)
   			{	Platform[i].update();
   			}
   			//////////////////BACKGROUND UPDATE//////////////////////
   			BackGround.update();
   			MidGround1.update();		MidGround2.update();
   			ForeGround1.update();		ForeGround2.update();
   				
   			//////////////////////EDITORIAL UPDATE//////////////////////
   			for(int i=0; i < Marker.length; i++)
   			{	Marker[i].update();
   			}
   			
   			//////////////////////GRAPHICS UPDATE//////////////////////
   			repaint();
   		}
   	}
   	
				
   	//////////////////////OBJECT'S SPRITE ASSIGNMENT//////////////////////
   	@Override
   	public void paint(Graphics g) 
   	{	//////////////////////BACKGROUNDS//////////////////////
   		g.drawImage(BackGround.getCurrentBackGround(), (int)BackGround.getBackgroundXvalue(), (int)BackGround.getBackgroundYvalue(), this);
   		g.drawImage(MidGround1.getCurrentMidGround(), (int)MidGround1.getBackgroundXvalue(), (int)MidGround1.getBackgroundYvalue(), this);
   		g.drawImage(MidGround2.getCurrentMidGround(), (int)MidGround2.getBackgroundXvalue(), (int)MidGround2.getBackgroundYvalue(), this);
   		g.drawImage(ForeGround1.getCurrentForeGround(), (int)ForeGround1.getBackgroundXvalue(), (int)ForeGround1.getBackgroundYvalue(), this);
   		g.drawImage(ForeGround2.getCurrentForeGround(), (int)ForeGround2.getBackgroundXvalue(), (int)ForeGround2.getBackgroundYvalue(), this);
   		
   		//////////////////////PLATFORMS//////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	g.drawImage(Platform[i].getSlopeSprite(), (int)Platform[i].getPlatformXY()[0], (int)Platform[i].getPlatformXY()[1], (int)Platform[i].getWidth(), (int)(Platform[i].getWidth()*Platform[i].getSlope()), this);
   			g.drawImage(Platform[i].getBaseSprite(), (int)Platform[i].getPlatformXY()[0], (int)Platform[i].getPlatformXY()[1], (int)Platform[i].getWidth(), 720, this);
  //System.out.println(i+"x="+(int)Platform[i].getPointA()[0]+" y="+(int)Platform[i].getPointA()[1]);   		
   		}
   		
   		//////////////////////PLAYERS//////////////////////   	   	
   		for(int i=0; i < Player.length; i++)
   		{	g.drawImage(Character.getSprite(i), (int)Player[i].getCenterXY()[0]-50, (int)Player[i].getCenterXY()[1]-50, this);
   		}
   		
   		//////////////////////EDITORIALS//////////////////////
   		for(int i=0; i < Marker.length; i++)
   		{	g.drawImage(Marker[i].getCurrentSprite(), Marker[i].getXLocation()+Marker[i].getXSpriteShift(), Marker[i].getYLocation(), this);
   		}		
   	}
   	
   	//////////////////////GRAPHIC RENDERING UPDATE//////////////////////
   	@Override
   	public void update(Graphics g) 
   	{	if (image == null) 
		{	image = createImage(this.getWidth(), this.getHeight());
			second = image.getGraphics();
		}
		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);
		g.drawImage(image, 0, 0, this);
		
   	}
   	
   	//////////////////////USER KEY INPUT//////////////////////
   	@Override
   	public void keyPressed(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT:	inputXxYy[0] = -1;
   									inputXxYy[1] = -1;	break;
	   		case KeyEvent.VK_RIGHT:	inputXxYy[0] = 1;		
	   								inputXxYy[1] = 1;	break;
	   		case KeyEvent.VK_SPACE:	inputXxYy[2] = 1;	break;
	   	}
   	}
   	@Override
   	public void keyReleased(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT: 	inputXxYy[0] = 0; 	break;
	   		case KeyEvent.VK_RIGHT:	inputXxYy[0] = 0;	break;
	   		case KeyEvent.VK_SPACE:	inputXxYy[2] = 0;
	   								inputXxYy[3] = 0;	break;
	   	}
   	}
   	////////////////////// GETERS AND SETTERS //////////////////////
   	public static Background BackGround() 
    {	return BackGround;
    }
    public static Background MidGround1() 
    {	return MidGround1;
    }
    public static Background MidGround2() 
    {	return MidGround2;
    }
    public static Background ForeGround1() 
    {	return ForeGround1;
    }
    public static Background ForeGround2() 
    {	return ForeGround2;
    }
    public static Platform[] Platform() 
    {	return Platform;
    }
    public static Player[] Player() 	
    {	return Player;
    }
    public static Image None() 
	{return none;
	}
    public void setPlatform(Platform[] Platform) 
    {	Emulator.Platform = Platform;
    }
    
 	public void setPlayer(Player[] Player) 
 	{	Emulator.Player = Player;
 	}
 	public static int CurrentLevel() 
 	{return CurrentLevel;	
 	}
 	public static Image Level1_Slope() 
	{	return level1_slope;
	}
	public static Image Level1_Base() 
	{	return level1_base;
	}
	public static int getMatchEndTime() 
	{	return MatchEndTime;
	}
	public static double getI() 
	{	return i;
	}
	public static double getStartTime() 
	{	return StartTime;
	}
	public boolean isKeyHeld() 
	{	return keyHeld;
	}
	public static Random getGenerator() 
	{	return Generator;
	}
	public static Image getImage() 
	{	return image;
	}
	public static Image getLevel1_ForeGround() 
	{	return level1_ForeGround;
	}
	public static Image getLevel1_MidGround() 
	{	return level1_MidGround;
	}
	public static Image getLevel1_BackGround() 
	{	return level1_BackGround;
	}
	public static Image getWall() 
	{	return wall;
	}
	public static Image getWallJumpCap() 
	{	return wallJumpCap;
	}
	public static Image getHorrizontalScroll() 
	{	return horrizontalScroll;
	}
	public static Image getVirticalScroll() 
	{	return virticalScroll;
	}
	public URL getBase() 
	{	return base;
	}
	public Graphics getSecond() 
	{	return second;
	}
	public static double getResolutionOffset() 
	{	return ResolutionOffset;
	}
	public static Image getStandRight() 
	{	return standRight;
	}
	public static Image getStandLeft() 
	{	return standLeft;
	}
	public static Image getRunRight() 
	{	return runRight;
	}
	public static Image getRunLeft() 
	{	return runLeft;
	}
	public static Image getPushRight() 
	{	return pushRight;
	}
	public static Image getPushLeft() 
	{	return pushLeft;
	}
	public static Image getJumpRight() 
	{	return jumpRight;
	}
	public static Image getJumpLeft() 
	{	return jumpLeft;
	}
	public static Image getClimbJumpRight() 
	{	return climbJumpRight;
	}
	public static Image getClimbJumpLeft() 
	{	return climbJumpLeft;
	}
	public static Image getSlideRight() 
	{	return slideRight;
	}
	public static Image getSlideLeft() 
	{	return slideLeft;
	}
	public static Image getClimbRight() 
	{	return climbRight;
	}
	public static Image getClimbLeft() 
	{	return climbLeft;
	}
	public static Image getFallLeft() 
	{	return fallLeft;
	}
	public static Image getFallRight() 
	{	return fallRight;
	}
	public static Image getWallLeapLeft() 
	{	return wallLeapLeft;
	}
	public static Image getWallLeapRight() 
	{	return wallLeapRight;
	}
	public static int getResolutionY() 
 	{	return ResolutionY;	
 	}
	public static int getResolutionX() 
	{	return ResolutionX;
	}
	public static int getBottomScrollingValue() 
	{	return BottomScrollingValue;
	}
	public static int getTopScrollingValue() 
	{	return TopScrollingValue;
	}
	public static int getLeftScrollingValue() 
	{	return LeftScrollingValue;
	}
	public static int getRightScrollingValue() 
	{	return RightScrollingValue;
	}
	public static int getPlatfromOffset() 
	{	return PlatfromOffset;
	}
	public static int getLoadingNum() {
		return LoadingNum;
	}

	public static Image getWallSlideRight() {
		return wallSlideRight ;
	}
	public static Image getWallSlideLeft() {
		return wallSlideLeft ;
	}

	public static int getLandScape() 
	{	return landScape;
	}
	public static double getCurrentTime() 
	{	return CurrentTime;
	}
	public static int MatchEndTime() 
	{	return MatchEndTime;
	}
	public static wallMarker[] getMarker() {
		return Marker;
	}
	public static void setMatchOver(int MatchOver) 
	{	Emulator.MatchOver = MatchOver;
	}
	public static int getMatchOver() 
	{	return MatchOver;
	}
	public static int getLeftPlatformLimit() {
		return leftPlatformLimit;
	}
	
	public static Character getCharacter() 
	{	return Character;
	}
	public static Sprites getSprites() 
	{	return Sprite;
	}
//////////////////////NOT USED YET//////////////////////
   	@Override
   	public void stop(){}
   	@Override
   	public void destroy(){}
   	@Override
   	public void keyTyped(KeyEvent e){}
	
	
}