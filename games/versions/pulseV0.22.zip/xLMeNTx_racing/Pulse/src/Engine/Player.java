package Engine;
import java.awt.Image;
public class Player 	
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int			index,				
						yKeyPressed=0,		airAllow=1;		
	
	private double		groundAccel,		airAccel,			topSpeed,		
						jump,				doubleJump;
	
	private int[]		inputXxYy = new int [4];	
	
	private double[]	centerXY = new double[2],
						velocityXY = new double[2],
						proximityXYF = new double[3];
		//////////////////////CONSTRUCTOR//////////////////////
	//////////////////////
	public Player (double[] centerXY, int index, double[] stats)
	{	this.centerXY = centerXY;
		this.index = index;
		this.groundAccel = stats[0];
		this.airAccel = stats[1];	
		this.topSpeed = stats[2];		
		this.jump = stats[3];
		this.doubleJump = stats[4];
		proximityXYF = Physics.scanProximity(centerXY, velocityXY);
	}

		////////////////////// PLAYER UPDATE //////////////////////
	//////////////////////
	public void update( int[] inputXxYy) 
	{	this.inputXxYy = inputXxYy;
	
		///////////////////// COLLISION CHECK //////////////////////
System.out.println(" ");

		////////////////////// X INPUT //////////////////////
		if(Math.abs(inputXxYy[0]) == 1)
		{	////////////////////// ACCELERATION //////////////////////
			if(Math.abs(velocityXY[0]) < topSpeed)
			{	////////////////////// SURFACE CONTACT //////////////////////
				if(proximityXYF[0] != 180 || proximityXYF[1] != 180)
				{	velocityXY[0] += groundAccel*inputXxYy[0]*Math.cos(Math.toRadians(proximityXYF[1])); 	 
					velocityXY[1] -= groundAccel*inputXxYy[0]*Math.sin(Math.toRadians(proximityXYF[1])); 	 
//System.out.println("xI.1 a="+groundAccel*inputXxYy[0]+" xa="+groundAccel*inputXxYy[0]*Math.cos(Math.toRadians(thetaXY[1]))+" ya="+-groundAccel*inputXxYy[0]*Math.sin(Math.toRadians(thetaXY[1])));
					airAllow = 0;
				}
				////////////////////// IN AIR //////////////////////
				else
				{	////////////////////// ACCELERATION //////////////////////
					if( airAllow > 0 || inputXxYy[0]*velocityXY[0] <= 0)
					{	velocityXY[0] += airAccel*inputXxYy[0]; 	 
//System.out.println("xI.2 xa="+airAccel*inputXxYy[0]+" xv="+velocityXY[0]+" yv="+velocityXY[1]);
					}
				}	
			}	
		}
	
		////////////////////// Y INPUT //////////////////////
		if(inputXxYy[2] == 1 && inputXxYy[3] == 0) 
		{	////////////////////// KEY PRESSED //////////////////////
			inputXxYy[3] = 1;
			////////////////////// SURFACE CONTACT //////////////////////
			if(proximityXYF[0] != 180 || proximityXYF[1] != 180)
			{	velocityXY[0] += jump*Math.sin(Math.toRadians(proximityXYF[1]))/2;	
				velocityXY[1] += jump;	
				airAllow = 1;
//System.out.println("y.1  ys="+velocityXY[1]+" cy="+centerXY[1]+" yI="+jump);						
			}
			////////////////////// IN AIR //////////////////////
			else
			{	if(airAllow == 1)
				{	velocityXY[1] = (velocityXY[1]+doubleJump>=jump && velocityXY[1]<0)? 
						velocityXY[1] + doubleJump: doubleJump;
					airAllow = 2;					
//System.out.println("y.2  ys="+velocityXY[1]+" cy="+centerXY[1]+" yI="+inputXxYy[2]);						
				}	
			}
		}
	
		////////////////////// PHYSICS //////////////////////
		velocityXY = Physics.applyForces(centerXY, velocityXY);	
		proximityXYF = Physics.scanProximity(centerXY, velocityXY);
System.out.println("X="+velocityXY[0]+" Y="+velocityXY[1]);	
		
		////////////////////// X LOCATION UPDATE//////////////////////
		if(centerXY[0] + velocityXY[0] < Emulator.getRightScrollingValue() && centerXY[0] + velocityXY[0] > Emulator.getLeftScrollingValue())
		{	centerXY[0] += velocityXY[0];
//System.out.println("	uX.1 v="+velocityXY[0]+" x="+centerXY[0]);	
		}
		else
		{	for(int i = 0; i < Emulator.Platform().length; i++)
			{	Emulator.Platform()[i].setPlatformXY(new double[] {(Emulator.Platform()[i].getPlatformXY()[0] - velocityXY[0]), Emulator.Platform()[i].getPlatformXY()[1]});			
			}
//System.out.println("	uX.2 v="+velocityXY[0]+" x="+centerXY[0]);	
		}	
	
		////////////////////// Y LOCATION UPDATE//////////////////////
		if(centerXY[1] + velocityXY[1] < Emulator.getBottomScrollingValue() && centerXY[1] + velocityXY[1] > Emulator.getTopScrollingValue())
		{	centerXY[1] += velocityXY[1];
//System.out.println("	uY.1 v="+velocityXY[1]+" y="+centerXY[1]);	
		}
		else
		{	for(int i = 0; i < Emulator.Platform().length; i++)
			{	Emulator.Platform()[i].setPlatformXY(new double[] {Emulator.Platform()[i].getPlatformXY()[0], (Emulator.Platform()[i].getPlatformXY()[1] - velocityXY[1])});	
			}
//System.out.println("	uY.2 v="+velocityXY[1]+" y="+centerXY[1]);	
		}	
	}
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public int[] getInputXxYy() 
	{	return inputXxYy;
	}
	public double[] getCenterXY() 
	{	return centerXY;
	}
	public double[] getVelocityXY() 
	{	return velocityXY;
	}
	public double[] getProximityXYF() 
	{	return proximityXYF;
	}
	
}	