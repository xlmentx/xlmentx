package Engine;
import java.awt.Image;
public class Sprites 
{			
	public Image getSprite(String action)
	{	Image currentSprite = Emulator.None();
		
				
		return currentSprite;
	}
}