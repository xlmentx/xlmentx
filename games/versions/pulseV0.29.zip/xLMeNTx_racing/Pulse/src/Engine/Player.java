package Engine;
import java.awt.Image;
import java.math.BigDecimal;
public class Player 	
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int			index, 			xKeyLast, 		yKeyHeld,		jumpCounter;
	private double		groundAccel,	traction,		airAccel,		topSpeed,
						jump,			doubleJump;
	private double[]	centerXY = new double[2],
						dimensionXY = new double[2],
						velocityXY = new double[2],
						contactThetaXY = new double[2];
	private Image		currentSprite = Emulator.none;
		//////////////////////CONSTRUCTOR//////////////////////
	//////////////////////
	public Player (int index, double[] centerXY)
	{	this.index = index;
		this.centerXY = centerXY;
		double[] stats = Character.updateStats(index, 0, 0);
		groundAccel = stats[0];		airAccel = stats[1];	topSpeed = stats[2];		
		jump = stats[3];	doubleJump = stats[4];
		dimensionXY = new double[]{100,100};
		xKeyLast = 1;
	}

		////////////////////// PLAYER UPDATE //////////////////////
	//////////////////////
	public void update(int xInput, int yInput) 
	{	////////////////////// X INPUT //////////////////////
//System.out.println("   ");
		if(Math.abs(xInput) == 1 && Math.abs(velocityXY[0]+groundAccel*xInput) < topSpeed)
		{	////////////////////// GROUND ACCELERATION //////////////////////
			if(contactThetaXY[1] != Physics.Inactive && xInput*velocityXY[0] >= 0)
			{	////////////////////// TRACTION //////////////////////
				if(groundAccel <= traction)
				{	velocityXY[0] += groundAccel*xInput*Math.cos(contactThetaXY[1]); 	 
					velocityXY[1] -= groundAccel*xInput*Math.sin(contactThetaXY[1]); 	 
//System.out.println("x.1 vX="+velocityXY[0]+" aX="+groundAccel*xInput*Math.cos(contactThetaXY[1]));						
//System.out.println("y.1 vY="+velocityXY[1]+" aY="+(-groundAccel*xInput*Math.sin(contactThetaXY[1])));						
				}		
				////////////////////// TRACTION SLIP //////////////////////
				else
				{	velocityXY[0] += traction*xInput*Math.cos(contactThetaXY[1]); 	 
					velocityXY[1] -= traction*xInput*Math.sin(contactThetaXY[1]); 	 
//System.out.println("x.2 vX="+velocityXY[0]+" aX="+traction*xInput*Math.cos(contactThetaXY[1]));						
//System.out.println("y.2 vY="+velocityXY[1]+" aY="+-(traction*xInput*Math.sin(contactThetaXY[1])));						
				}
			}
			////////////////////// AERIAL ACCELERATION //////////////////////
			if(contactThetaXY[1] == Physics.Inactive)
			{	velocityXY[0] += airAccel*xInput; 	 
//System.out.println("x.3 xa="+airAccel*xInput+" xv="+velocityXY[0]+" yv="+velocityXY[1]);
			}
			xKeyLast = xInput;
		}
		
		////////////////////// Y INPUT //////////////////////
		if(yInput == 1) 
		{	if(yKeyHeld == 0) 
			{	////////////////////// GROUND JUMP//////////////////////
				if(contactThetaXY[1] != Physics.Inactive)
				{	velocityXY[0] += jump*Math.sin(contactThetaXY[1])*0.3;
		    		velocityXY[1] = jump*(1-Math.sin(contactThetaXY[1])*0.3);
//System.out.println("x.4 vX="+velocityXY[0]+" aX="+jump*Math.sin(contactThetaXY[1])*0.3);						
//System.out.println("y.3 vY="+velocityXY[1]+" aY="+jump*(1-Math.sin(contactThetaXY[1])*0.3));						
		    		jumpCounter = 1;					
				}
				////////////////////// WALL JUMP //////////////////////
				if(contactThetaXY[0] != Physics.Inactive && contactThetaXY[1] == Physics.Inactive)
				{	velocityXY[0] = jump*Math.sin(contactThetaXY[0])*0.3;
					velocityXY[1] = jump*(1-Math.sin(contactThetaXY[0])*0.3);
//System.out.println("x.5 vX="+velocityXY[0]+" aX="+jump*Math.sin(contactThetaXY[1])*0.3);						
//System.out.println("y.4 vY="+velocityXY[1]+" aY="+jump*(1-Math.sin(contactThetaXY[1])*0.3));						
					jumpCounter = 1;					
				}
				////////////////////// AERIAL JUMP //////////////////////
				if(contactThetaXY[0] == Physics.Inactive && contactThetaXY[1] == Physics.Inactive && jumpCounter == 1)
				{	 velocityXY[1] = doubleJump;
//System.out.println("y.5  vY="+velocityXY[1]);							
					jumpCounter = 0;					
				}	
				yKeyHeld = 1;
			}
		}
		////////////////////// Y RELEASE //////////////////////
		else
		{	yKeyHeld = 0;
		}
		
		////////////////////// PHYSICS //////////////////////
		double[] vectorUpdate = Physics.applyForces(centerXY, velocityXY, xInput);
		centerXY = new double[] {vectorUpdate[0], vectorUpdate[1]};	
		velocityXY = new double[] {vectorUpdate[2], vectorUpdate[3]};	
		contactThetaXY = new double[] {vectorUpdate[4], vectorUpdate[5]};	
		traction = vectorUpdate[6];
		
		////////////////////// X LOCATION UPDATE//////////////////////
		if(centerXY[0]+velocityXY[0] < Emulator.XLimitLR[1] && centerXY[0]+velocityXY[0] > Emulator.XLimitLR[0])
		{	centerXY[0] += velocityXY[0];
			Platform.ScrollSpeedXY[0] = 0;
//System.out.println("uX.1 cX="+centerXY[0]+" vX="+velocityXY[0]+" sS="+Platform.ScrollSpeedXY[0]);	
		}
		////////////////////// HORRIZONTAL SCROLLING //////////////////////
		else
		{	Platform.ScrollSpeedXY[0] = -velocityXY[0];
//System.out.println("uX.2 cX="+centerXY[0]+" vX="+velocityXY[0]+" sS="+Platform.ScrollSpeedXY[0]);	
		}
		
		////////////////////// Y LOCATION UPDATE//////////////////////
		if(centerXY[1]+velocityXY[1] < Emulator.YLimitUD[1] && centerXY[1]+velocityXY[1] > Emulator.YLimitUD[0])
		{	centerXY[1] += velocityXY[1];
			Platform.ScrollSpeedXY[1] = 0;
//System.out.println("uY.1 cX="+centerXY[1]+" vX="+velocityXY[1]+" sS="+Platform.ScrollSpeedXY[1]);	
		}
		////////////////////// VERTICAL SCROLLING //////////////////////
		else
		{	Platform.ScrollSpeedXY[1] = -velocityXY[1];
//System.out.println("uY.2 cX="+centerXY[1]+" vX="+velocityXY[1]+" sS="+Platform.ScrollSpeedXY[1]);	
		}	
		
		////////////////////// SPRITE UPDATE //////////////////////
		currentSprite = Character.getSprite(xKeyLast, jumpCounter, velocityXY, contactThetaXY);
	}
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] CenterXY() 
	{	return centerXY;
	}
	public double[] DimensionXY() 
	{	return dimensionXY;
	}
	public Image CurrentSprite() 
	{	return currentSprite;
	}
	
}	