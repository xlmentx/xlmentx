package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int 		None=0, 	Min=1, 		Low=5,		Med=10, 	High=20, 	Max=100;
	static int[]	////////////{ SMALL,   MEDIUM,  LARGE}///////////////
					Gaps =		{  Min,    Min,    Min},
					Walls =		{  Min,    Min,    Min},
					Drops =		{  Min,    Min,    Min},
					Widths =	{  Min,    Min,    Min},
					Inclines =	{  Min,    Min,    Min},
					Declines =	{  Min,    Min,    Min}, 
					uFrictionX=	{  None,    None,    Max}, 
					uFrictionY=	{  None,    None,    Max}; 
					
	static int 		xShiftMax = (int)(Emulator.ResolutionXY[0]*0.75),
					xShiftMin = Emulator.Stand[0].getWidth(),
					yShiftMax = Emulator.ResolutionXY[1],
					yShiftMin = Emulator.Stand[0].getHeight()/2,
					WidthMax = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax, 
					WidthMin = Emulator.Stand[0].getWidth(),		
					HeightMax = Emulator.BaseSprite[0].getHeight()*Emulator.ScalingMax,
					HeightMin = 0,
					uFrictionMax = 150,
					uFrictionMin = 10;
	static double	RatioSum = 0; 

		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double[]	ScrollSpeedXY = {0, 0};
	static Random 	Rand = new Random();
	
		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		index;
	private double[]locationXY = new double[2],
					dimensionXY = new double[2],
					uFrictionXY = new double[2];
	private boolean onScreen =  true;
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] locationXY, double[] dimensionXY, double[] uFrictionXY)
	{	this.index = index;
		this.locationXY = locationXY;
		this.dimensionXY = dimensionXY;
		this.uFrictionXY = uFrictionXY;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	///////////////// LOCATION UPDATE /////////////////
		locationXY[0] = locationXY[0]+ScrollSpeedXY[0];
//System.out.println("p"+index+" pX="+locationXY[0]+" sS="+ScrollSpeedXY[0]);   		
		locationXY[1] = locationXY[1]+ScrollSpeedXY[1];
//System.out.println("p"+index+" pY="+locationXY[1]+" sS="+ScrollSpeedXY[1]);   		
		
		///////////////// PLATFORM JUMP /////////////////
		if (locationXY[0]+dimensionXY[0] <= -Emulator.ResolutionXY[0])
		{	///////////////// PREVIOUS PLATFORM /////////////////
			double previousXEnd, previousYEnd;
			if(index-1 < 0)
			{	previousXEnd = Emulator.Platform[Emulator.Platform.length-1].LocationXY()[0]+Emulator.Platform[Emulator.Platform.length-1].dimensionXY[0]+ScrollSpeedXY[0];
			   	previousYEnd = Emulator.Platform[Emulator.Platform.length-1].LocationXY()[1]+Emulator.Platform[Emulator.Platform.length-1].dimensionXY[1]+ScrollSpeedXY[1];
			}
			else
			{	previousXEnd = Emulator.Platform[index-1].LocationXY()[0]+Emulator.Platform[index-1].dimensionXY[0];
		   		previousYEnd = Emulator.Platform[index-1].LocationXY()[1]+Emulator.Platform[index-1].dimensionXY[1];		
			}
//System.out.println("p"+index+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
				
			///////////////// GAPS /////////////////
			locationXY[0] = (int)(previousXEnd);
			RatioSum = 0;
			double offset = getOffSet(Widths, WidthMax, WidthMin);
			if(offset != 0)
			{	locationXY[0] += (int)(offset);
System.out.println("p"+index+" Gap="+(int)(offset));   		
			}	
			
			///////////////// WALLS /////////////////
			locationXY[1] = previousYEnd;
			RatioSum = 0;
			offset = getOffSet(Walls, yShiftMax, yShiftMin);
			if(offset != 0)
			{	locationXY[1] = previousYEnd-offset;
System.out.println("p"+index+" Wall="+offset);   		
			}	
			
			///////////////// DROPS /////////////////
			offset = getOffSet(Drops, yShiftMax, yShiftMin);
			if(offset != 0)
			{	locationXY[1] = previousYEnd+offset;
System.out.println("p"+index+" Drop="+offset);   		
			}	
			
			///////////////// WIDTHS /////////////////
			dimensionXY[0] = WidthMax;
			RatioSum = 0;
			offset = getOffSet(Widths, WidthMax, WidthMin);
			if(offset != 0)
			{	dimensionXY[0] = offset;
System.out.println("p"+index+" Width="+offset);   		
			}	
			
			///////////////// INCLINES /////////////////
			RatioSum = 0;
			offset = getOffSet(Inclines, HeightMax, HeightMin);
			if(offset != 0)
			{	dimensionXY[1] = -offset;
System.out.println("p"+index+" Incline="+offset);   		
			}
			///////////////// DECLINES /////////////////
			offset = getOffSet(Declines, HeightMax, HeightMin);
			if(offset != 0)
			{	dimensionXY[1] = offset;
System.out.println("p"+index+" Decline="+offset);   		
			}
			
			///////////////// uFRICTION X /////////////////
			RatioSum = 0;
			offset = getOffSet(uFrictionX, uFrictionMax, uFrictionMin)/100.00;
			if(offset != 0)
			{	uFrictionXY[0] = offset;
//System.out.println("p"+index+" xFriction="+offset);   		
			}
		
			///////////////// uFRICTION Y /////////////////
			RatioSum = 0;
			offset = getOffSet(uFrictionY, uFrictionMax, uFrictionMin)/100.00;
			if(offset != 0)
			{	uFrictionXY[1] = offset;
//System.out.println("p"+index+" yFriction="+offset);   		
			}		
		}
		
		///////////////// ON SCREEN CHECK /////////////////
		onScreen = false;
		if(locationXY[0]+dimensionXY[0] > 0 && locationXY[0] < Emulator.ResolutionXY[0])
		{	///////////////// Y CHECK /////////////////
			if(locationXY[1]+dimensionXY[1] < Emulator.ResolutionXY[1] || locationXY[1] < Emulator.ResolutionXY[1])
			{	onScreen = true;
			}
		}	
	}	
	
		///////////////////// OFFSETS //////////////////////
	//////////////////////
	public static double getOffSet(int[] array, int valueMax, int valueMin)
	{	double 	offSet = 0, 	ratioScaling = 1;
	
		for(int i = 0; i < array.length; i++)
		{	RatioSum += array[i];
			if(RatioSum > Max)
			{ 	ratioScaling = Max/RatioSum;
			}
			double rand = Rand.nextInt(Max)+1;
			if(rand <= array[i]*ratioScaling)
			{	int rangeStart = valueMax/array.length*i,
					variant = Rand.nextInt(valueMax/array.length-valueMin/(i+1))+valueMin/(i+1);
				offSet = rangeStart+variant;
System.out.println(" type[S,M,L]="+i+" val="+array[i]*ratioScaling+" ran="+rand);   		
			}
		}
		return offSet;
	}	


		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] LocationXY() 
	{	return locationXY;
	}
	public double[] DimensionXY() 
	{	return dimensionXY;
	}
	public double[] uFrictionXY() 
	{	return uFrictionXY;
	}
	public boolean OnScreen() 
	{	return onScreen;
	}
}