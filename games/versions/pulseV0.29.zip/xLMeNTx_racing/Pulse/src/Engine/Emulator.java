package Engine;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Random;

import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Emulator 
extends Applet 
implements Runnable, KeyListener
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static int 			Fps=60,					CurrentLevel= 0,
						ScalingMax = 2;
						
	static int[]        ResolutionXY = { 720*16/9, 720}, 	// 1080p=16/9
						XLimitLR = {(int)(ResolutionXY[0]*0.3), (int)(ResolutionXY[0]*0.4)},
						YLimitUD = {(int)(ResolutionXY[1]*0.3), (int)(ResolutionXY[1]*0.6)},
						XInput = {0,0,0,0},
						YInput = {0,0,0,0};
	
		////////////////////// OBJECT DECLARATIONS //////////////////////
	//////////////////////
	static 	Scenery[]	Scenery= new Scenery[5];
	static 	Scenery[]	BackGround= new Scenery[1];
	static 	Scenery[]	MidGround= new Scenery[3];
	static 	Scenery[]	ForeGround= new Scenery[3];
	static 	Platform[]	Platform = new Platform[8];
	static 	Player[]	Player = new Player[1];
	
		////////////////////// SPRITE DECLARATIONS //////////////////////
	//////////////////////
	private Graphics second;
	static Image 		image,  				none;
	
	////////////////////// SCENERY SPRITES //////////////////////
	static BufferedImage[]	Background = new BufferedImage[1],	
							Midground = new BufferedImage[1],
							Foreground = new BufferedImage[1],
	
	////////////////////// PLATFORM SPRITES //////////////////////
							BaseSprite = new BufferedImage[1],
							SlopeSprite = new BufferedImage[1],					
	
	////////////////////// CHARACTER SPRITES //////////////////////
							Stand = new BufferedImage[2], 				
							Run = new BufferedImage[2], 	
							Slide = new BufferedImage[2], 
							Push = new BufferedImage[2],
							Jump = new BufferedImage[2], 
							Fall = new BufferedImage[2];
					
		////////////////////// INITIALIZATION //////////////////////
	//////////////////////
	@Override 
	public void init()
	{	////////////////////// ROOM PROPERTIES //////////////////////
		setSize(ResolutionXY[0], ResolutionXY[1]);
		setBackground(Color.BLACK);
		setFocusable(true);
		Frame myframe = (Frame) this.getParent().getParent();
		myframe.setTitle("pulse");
		addKeyListener(this);
		try 
	   	{	////////////////////// BACKGROUND SPRITE DIRECTORY //////////////////////			
		   	Background[0]= ImageIO.read(new File("data/Scenery/background.png"));
		   	Midground[0] = ImageIO.read(new File("data/Scenery/midground.png"));
		   	Foreground[0]= ImageIO.read(new File("data/Scenery/foreground.png"));
		   	
			//////////////////////PLATFORM SPRITE DIRECTIORY //////////////////////					
			BaseSprite[0] = ImageIO.read(new File("data/Platforms/base.png"));
			SlopeSprite[0]= ImageIO.read(new File("data/Platforms/slope.png")); 	
				
		   	//////////////////////CHARACTER SPRITE DIRECTORY //////////////////////			
			Stand[0]= ImageIO.read(new File("data/Characters/standleft.png"));
			Stand[1]= ImageIO.read(new File("data/Characters/standright.png"));
			Run[0]	= ImageIO.read(new File("data/Characters/runleft.png"));
			Run[1] 	= ImageIO.read(new File("data/Characters/runright.png"));
			Slide[0]= ImageIO.read(new File("data/Characters/slideleft.png")); 
			Slide[1]= ImageIO.read(new File("data/Characters/slideright.png"));
			Jump[0] = ImageIO.read(new File("data/Characters/jumpleft.png"));
			Jump[1] = ImageIO.read(new File("data/Characters/jumpright.png"));
			Fall[0] = ImageIO.read(new File("data/Characters/fallLeft.png"));
			Fall[1] = ImageIO.read(new File("data/Characters/fallRight.png"));
		} 
		catch (Exception e) 
		{
		}
	}
	
		////////////////////// OBJECT START //////////////////////
	//////////////////////
	@SuppressWarnings("static-access")
	@Override
   	public void start() 
 	{	////////////////////// BACKGROUND START //////////////////////
		for(int i=0; i < BackGround.length; i++)
   		{	double[] backgroundXY = {Background[0].getWidth()*i, 0};
   			BackGround[i] = new Scenery(i, backgroundXY); 
   		}
		
		////////////////////// MIDGROUND START //////////////////////
		for(int i=0; i < MidGround.length; i++)
		{	double[] midgroundXY = {Midground[0].getWidth()*i, ResolutionXY[1]*0.2};
			MidGround[i] = new Scenery(i, midgroundXY); 
		}
		
		////////////////////// FOREGROUND START //////////////////////
		for(int i=0; i < ForeGround.length; i++)
		{	double[] foregroundXY = {Foreground[0].getWidth()*i, ResolutionXY[1]*0.4};
			ForeGround[i] = new Scenery(i, foregroundXY); 
		}

  		////////////////////// PLATFORM START //////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	double[] LocationXY = {-ResolutionXY[0]+BaseSprite[0].getWidth()*1.9*i, YLimitUD[1]},
   					 dimensionXY= {BaseSprite[0].getWidth()*ScalingMax, 0},
   					 uFrictionXY = {1, 1};
			Platform[i] = new Platform(i, LocationXY, dimensionXY, uFrictionXY); 
   		}
   		
   		////////////////////// PLAYER START //////////////////////
   		for(int i=0; i < Player.length; i++)
   		{	double[] centerXY = {XLimitLR[0]+50*i, YLimitUD[0]};
   			Player[i] = new Player(i, centerXY);	
   		}

   		////////////////////// GAMETHREAD START //////////////////////
   	   	Thread nonamethread = new Thread(this);	
   		nonamethread.start();
 	}   		

   		////////////////////// RUN LOOP //////////////////////
	//////////////////////
	@Override
   	public void run()
   	{	while (true) 
   		{	////////////////////// GAME LOOP SPEED //////////////////////
   			try 
   			{	Thread.sleep(1000/(long)Fps);
   			} 
   			catch (InterruptedException e) 
   			{	e.printStackTrace();
   			}
   			
   			//////////////////////BACKGROUND //////////////////////
   			for(int i=0; i < BackGround.length; i++)
   			{	BackGround[i].update();
   			}

   			////////////////////// MIDGROUND //////////////////////
   			for(int i=0; i < MidGround.length; i++)
   			{	MidGround[i].update();
   			}

   			////////////////////// FOREGROUND //////////////////////
   			for(int i=0; i < ForeGround.length; i++)
   			{	ForeGround[i].update();
   			}

   			////////////////////// PLATFORM UPDATE //////////////////////
   			for(int i=0; i < Platform.length; i++)
   			{	Platform[i].update();
   			}
   		
   			////////////////////// CHARACTER UPDATE //////////////////////
   			for(int i=0; i < Player.length; i++)
   			{	Player[i].update(XInput[i],YInput[i]);
   			}
   				
   			////////////////////// GRAPHICS UPDATE //////////////////////
   			repaint();
   		}
   	}
				
   		////////////////////// PAINT //////////////////////
	//////////////////////
	@SuppressWarnings("static-access")
	@Override
   	public void paint(Graphics g) 
   	{	////////////////////// BACKGROUND //////////////////////
		for(int i=0; i < BackGround.length; i++)
   		{	g.drawImage(Background[CurrentLevel], (int)BackGround[i].getSceneryXY()[0], (int)BackGround[i].getSceneryXY()[1], Background[0].getWidth()*2, Background[0].getHeight()*2, this);
   		}
		
		////////////////////// MIDGROUND //////////////////////
		for(int i=0; i < MidGround.length; i++)
		{	g.drawImage(Midground[CurrentLevel], (int)MidGround[i].getSceneryXY()[0], (int)MidGround[i].getSceneryXY()[1], Midground[0].getWidth()*2, Midground[0].getHeight()*2, this);
   		}
		
		////////////////////// FOREGROUND //////////////////////
		for(int i=0; i < ForeGround.length; i++)
		{	g.drawImage(Foreground[CurrentLevel], (int)ForeGround[i].getSceneryXY()[0], (int)ForeGround[i].getSceneryXY()[1], Foreground[0].getWidth()*2, Foreground[0].getHeight()*2, this);
   		}

		////////////////////// PLATFORMS //////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	////////////////////// IF VISIBLE //////////////////////
   	   		if(Platform[i].OnScreen() == true)
   			{	////////////////////// SPRITE OFFSETS //////////////////////
   	    		double 	baseYOffset = 0,
   	    				slopeYOffset = Platform[i].DimensionXY()[1],
   	    				slopeXOffset = Platform[i].DimensionXY()[0];
   	    		if(Platform[i].DimensionXY()[1] > 0)
				{	baseYOffset = Platform[i].DimensionXY()[1];
					slopeYOffset = 0;
					slopeXOffset = 0;
				}	
	   			
				////////////////////// DRAW SLOPE //////////////////////
   	   			g.drawImage(SlopeSprite[CurrentLevel], (int)(Platform[i].LocationXY()[0]+slopeXOffset), (int)(Platform[i].LocationXY()[1]+slopeYOffset), (int)(Platform[i].DimensionXY()[0]*Math.signum(Platform[i].DimensionXY()[1])), Math.abs((int)Platform[i].DimensionXY()[1]), this);
//System.out.println(i+"'s Slope is on screen s="+Platform[i].Slope()+" w="+Platform[i].Width()+" h="+Platform[i].Hight());
   	   			
   	   			////////////////////// DRAW BASE //////////////////////
   	    		boolean drawBase = true;
				int J = 0;
	   			while(drawBase == true)
				{	drawBase = false;
	   				if(Platform[i].LocationXY()[1]+baseYOffset+BaseSprite[0].getHeight()*ScalingMax*J < ResolutionXY[1])
   					{	g.drawImage(BaseSprite[CurrentLevel], (int)Platform[i].LocationXY()[0], (int)(Platform[i].LocationXY()[1]+baseYOffset+BaseSprite[0].getHeight()*ScalingMax*J), (int)Platform[i].DimensionXY()[0], BaseSprite[0].getHeight()*ScalingMax, this);
   						J++;
   						drawBase = true;
//System.out.println(i+"'s Base is on screen");
   					}	
				}
   			}
   		}
   		
   		////////////////////// PLAYERS //////////////////////   	   	
   		for(int i=0; i < Player.length; i++)
   		{	g.drawImage(Player[i].CurrentSprite(), (int)Player[i].CenterXY()[0]-50, (int)Player[i].CenterXY()[1]-50, (int)Player[i].DimensionXY()[0], (int)Player[i].DimensionXY()[1], this);
   		}
   	}
   	
   		////////////////////// GRAPHICS UPDATE //////////////////////
	//////////////////////
	@Override
   	public void update(Graphics g) 
   	{	if (image == null) 
		{	image = createImage(this.getWidth(), this.getHeight());
			second = image.getGraphics();
		}
		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);
		g.drawImage(image, 0, 0, this);
   	}
   	
   		////////////////////// KEY PRESS //////////////////////
	//////////////////////
	@Override
   	public void keyPressed(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT:	XInput[0] = -1;		break;
	   		case KeyEvent.VK_RIGHT:	XInput[0] = 1;		break;
	   		case KeyEvent.VK_SPACE:	YInput[0] = 1;		break;
	   	}
   	}
	
		////////////////////// KEY RELEASE //////////////////////
	//////////////////////
	@Override
   	public void keyReleased(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT: 	if(XInput[0] == -1)
   									{	XInput[0] = 0;
   									} 					break;				
	   		case KeyEvent.VK_RIGHT:	if(XInput[0] == 1)
									{	XInput[0] = 0;
									}					break;
	   		case KeyEvent.VK_SPACE:	YInput[0] = 0;		break;
	   	}
   	}
	
////////////////////// NOT USED //////////////////////
   	@Override
   	public void stop(){}
   	@Override
   	public void destroy(){}
   	@Override
   	public void keyTyped(KeyEvent e){}
	
	
}