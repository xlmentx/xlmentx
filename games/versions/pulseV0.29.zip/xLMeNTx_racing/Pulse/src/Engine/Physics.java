package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	Gravity = 0.5,
					Inactive = Emulator.ResolutionXY[0];
					
		///////////////////// FORCE VECTORS SUMMATION //////////////////////
	//////////////////////
	public static double[] applyForces(double[] centerXY, double[] velocityXY, int xInput)
	{	//////////////////////GRAVITY //////////////////////
		velocityXY[1] += Gravity;
//System.out.println("  Gravity  Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
 		
		////////////////////// PROXIMITY SCANS //////////////////////
		double[] 	contactXY	={Inactive, Inactive},
			 		thetaXY 	={Inactive, Inactive},
	 				uFrictionXY ={Inactive, Inactive};
		for(int i = 0; i < Emulator.Platform.length; i++)
		{	if(Emulator.Platform[i].OnScreen() == true)
			{	double[] platformLocationXY = Emulator.Platform[i].LocationXY(),
					 	 platformDimensionXY = Emulator.Platform[i].DimensionXY();
				////////////////////// RIGHTWARD CONTACT //////////////////////
				if(centerXY[1] > platformLocationXY[1])
				{	double contact = platformLocationXY[0];
					if(centerXY[0]+velocityXY[0] >= contact && centerXY[0] <= contact)
					{	contactXY[0] = contact;
						thetaXY[0] = Math.toRadians(90);
						uFrictionXY[0] = Emulator.Platform[i].uFrictionXY()[0];						
//System.out.println("RCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+contactThetaXY[1]);
					}	
				}
				////////////////////// LEFTWARD CONTACT //////////////////////
				if(centerXY[1] > platformLocationXY[1]+platformDimensionXY[1])
				{	double contact = platformLocationXY[0] + platformDimensionXY[0];
					if(centerXY[0]+velocityXY[0] <= contact && centerXY[0] >= contact)
					{	contactXY[0] = contact;
						thetaXY[0] = -Math.toRadians(90);
						uFrictionXY[0] = Emulator.Platform[i].uFrictionXY()[0];						
//System.out.println("LCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+contactThetaXY[1]);
					}
				}
				////////////////////// DOWNWARD CONTACT //////////////////////
				if(centerXY[0] > platformLocationXY[0] && centerXY[0] < platformLocationXY[0]+platformDimensionXY[0])
				{	double 	futureContact = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]+velocityXY[0]-platformLocationXY[0])+platformLocationXY[1],
							currentContact = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]-platformLocationXY[0])+platformLocationXY[1];
					if(centerXY[1]+velocityXY[1] >= futureContact)
					{	contactXY[1] = currentContact;
						thetaXY[1] =  Math.atan2(-platformDimensionXY[1], platformDimensionXY[0]);
						uFrictionXY[1] = Emulator.Platform[i].uFrictionXY()[1];						
//System.out.println("DCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+contactThetaXY[1]);
					}
				}
			}
		}
			///////////////////// APPLY CONTACT FORCES //////////////////////
		//////////////////////
		double frictionForce = 0;
		for(int i = 0; i < thetaXY.length; i++)
		{	if(thetaXY[i] != Inactive)
			{	////////////////////// NORMAL FORCE //////////////////////
				double	velocityTheta = Math.atan2(-velocityXY[1],velocityXY[0]),
						velocity = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)), 
						normalTheta = thetaXY[i] + Math.toRadians(90),
						normalForce = Math.abs(velocity*Math.cos(normalTheta-velocityTheta));
				if(Math.abs(velocityTheta-normalTheta) >= Math.toRadians(90))
				{	centerXY[i] = contactXY[i];
					velocityXY[0] += normalForce*Math.cos(normalTheta);
					velocityXY[1] -= normalForce*Math.sin(normalTheta);
//System.out.println("  normalForce Fx="+normalForce*Math.cos(normalTheta)+" Fy="+(-normalForce*Math.sin(normalTheta)));
				}
				////////////////////// FRICTION FORCE //////////////////////
				double	frictionTheta = Math.atan2(-velocityXY[1],velocityXY[0])+Math.toRadians(180);
				frictionForce = normalForce*uFrictionXY[i];
				if(xInput*velocityXY[0] <= 0)
				{	velocityXY[0] += frictionForce*Math.cos(frictionTheta);
					velocityXY[1] -= frictionForce*Math.sin(frictionTheta);
					if(frictionForce > velocity-normalForce)
					{	velocityXY[0] = 0;
						velocityXY[1] = 0;
					}
//System.out.println("  frictionForce  Fx="+frictionForce*Math.cos(frictionTheta)+"  Fy="+(-frictionForce*Math.sin(frictionTheta)));
				}
			}	
//System.out.println("  finalSum  Vx="+velocityXY[0]+"  Vy="+velocityXY[1]);
		}	
	
		////////////////////// VECTOR CLEAN UP AND RETURN //////////////////////
		return new double[] {centerXY[0], centerXY[1], velocityXY[0], velocityXY[1], thetaXY[0], thetaXY[1], frictionForce};
	}	
}