package Engine;
import java.awt.Image;
public class Player 
{	//////////////////////ATRIBUTES//////////////////////
	private int			width = 50, 		hight = 100;
							//	acceleration, 	torque, 	topSpeed, 	verticalLeap, 	climbStrength
	private int []      level = {	100, 		  100, 		100, 			100, 	  	  	100   };
	//////////////////////PLAYER//////////////////////
	static double		acceleration,		torque,			topSpeed,	verticalLeap,	climbStrength,
						xMovement=1;
	//////////////////////PHYSICS//////////////////////
	
	//////////////////////DYNAMIC DECLARATIONS//////////////////////
	private int 		centerXlocation,		 centerYlocation,		playerNumber,			
						keyPress=0, wallReleaseMin=30, platformContact,
						wall,			wallTop,	currentPlatform,
						nextPlatform,		previousPlatform,		wallBottom,wallHight,		
						respawnDistance,
						gap, 		yScrollLimit, wallJumpCap, script=0;
	private double 		 gravity=.5,							xSpeed,				
						wallSlip=1,									speedGradient,			activeSlope,							
						ySpeed,			airJump,stoppingFriction;					
	private boolean 								
						climbingLeft,climbingRight,						airJumpAllow,
						keyHeld,				jump;				
	private Image 		currentSprite;
	//////////////////////CONSTRUCTOR//////////////////////
	public Player (int x, int y)
	{	centerXlocation = x;
		centerYlocation = y;
	}
//////////////////////PLAYER CLASS UPDATE//////////////////////
public void update() 
{	////////////////////// PLAYER ORIENTATION //////////////////////
	if(script == 0)
	{	if(Emulator.getXKey() == -1)
		{	if(climbingRight == false)
			{	if(xSpeed > 0 && centerYlocation+ySpeed >= platformContact )
				{	xMovement=3;
				}
				else
				{	xMovement=-2;
				}	
				keyPress=-1;
			}
			else
			{	--keyPress;
				if(keyPress==-wallReleaseMin)
				{	xMovement=-2;
				}
			}
		}
		if(Emulator.getXKey() == 1)
		{	if(climbingLeft == false)
			{	if(xSpeed < 0 && centerYlocation+ySpeed >= platformContact )
				{	xMovement=-3;
				}
				else
				{	xMovement=2;
				}
				keyPress=1;
			}
			else
			{	++keyPress;
				if(keyPress==wallReleaseMin)
				{	xMovement=2;
				}
			}	
		}
		if(Emulator.getXKey() == 0)
		{	if(xMovement < 0)
			{	xMovement= -1; 
			}
			if(xMovement > 0)
			{	xMovement = 1; 
			}
			keyPress=0;
		}	
	}
	//////////////////////XP VALUES//////////////////////
				// acceleration, torque, topSpeed, verticalLeap, climbStrength
	double [] defaults={0.1,	   0,		15,			-8,	    	-1		},
			  maxExtra={0.5,	   1,		5,			-4,	     	-3		};
	
	for(int i = 0; i < level.length; i++)	
	{	double lvlPercent=0;
		if(level[i]>100)	
		{	lvlPercent = maxExtra[i]+defaults[i];
		}	
		if(level[i]<=100 && level[i]>0)	
		{	lvlPercent = maxExtra[i]*(level[i]/100.00)+defaults[i];
		}
		if(level[i]<=0)	
		{	lvlPercent = defaults[i];
		}
		switch(i)
		{	case 0:	acceleration 	= lvlPercent*(xMovement/Math.abs(xMovement));	break;
			case 1:	torque 	  		= lvlPercent;									break;
			case 2: topSpeed 		= lvlPercent;									break;
			case 3: verticalLeap	= lvlPercent; 
					airJump			= lvlPercent-(defaults[i]/4);					break;
			case 4: climbStrength	= lvlPercent;									break;
		}
	}
	
	//////////////////////DEFAULT VALUES//////////////////////
	platformContact=Emulator.getResolutionY();
	boolean pitFall = true;
	wall=Emulator.getResoultionX();
	wallTop=Emulator.getResolutionY()+(hight/2);
	wallBottom=Emulator.getResolutionY()+(hight/2);
	wallHight=0;
	wallJumpCap=Emulator.getResolutionY()+(hight/2);
	speedGradient=1;
	stoppingFriction=0;
		
	
	//////////////////////PLATFORM VARIABLES//////////////////////
	for(int i = 0; i < Emulator.getPlatform().length; i++)
	{	nextPlatform = i+1;
		if(nextPlatform > Emulator.getPlatform().length-1)
		{	nextPlatform = 0;
		}
		previousPlatform = i-1;
		if(previousPlatform < 0)
		{	previousPlatform = Emulator.getPlatform().length-1;
		}
		int platformXStart = Emulator.getPlatform()[i].getPlatformXlocation();
		int platformXEnd = platformXStart+Emulator.getPlatform()[i].getWidth();
		int platformYStart = Emulator.getPlatform()[i].getPlatformYlocation()-(hight/4);
		int platformYEnd = (int)(Emulator.getPlatform()[i].getPlatformSlope()*Emulator.getPlatform()[i].getWidth()+platformYStart);
		int currentContact = (int)(Emulator.getPlatform()[i].getPlatformSlope()*(centerXlocation-platformXStart)+platformYStart);
		int previousYStart = Emulator.getPlatform()[previousPlatform].getPlatformYlocation()-(hight/4);
		int previousYEnd = (int)(Emulator.getPlatform()[previousPlatform].getPlatformSlope()*Emulator.getPlatform()[previousPlatform].getWidth()+previousYStart);
		int nextYStart = Emulator.getPlatform()[nextPlatform].getPlatformYlocation()-(hight/4);
		//////////////////////RIGHT WALL DETECTION//////////////////////
		if(xMovement > 0 && xSpeed>=0 || xSpeed>0)
		{	//////////////////////Y PERAMETER RANGE//////////////////////
			if(	centerXlocation < platformXEnd/2 && centerYlocation+(hight/4) >= platformYStart || centerXlocation > platformXEnd/2 && centerYlocation+(hight/4) >= platformYEnd)
			{	//////////////////////X PERAMETER PERCISION//////////////////////
				if(centerXlocation+width/2+xSpeed >= platformXStart && centerXlocation <= platformXStart)
				{	//////////////////////WALL HIGHT//////////////////////
					if(Emulator.getPlatform()[i].getXShift()<=0)
					{	wallHight=(int)((Emulator.getPlatform()[previousPlatform].getPlatformSlope()*(Emulator.getPlatform()[previousPlatform].getWidth()+Emulator.getPlatform()[i].getXShift()))+previousYStart)-(platformYStart);						 
					}
					else
					{	wallHight= (Emulator.getPlatform()[i].getPlatformYlocation()+1080)-(platformYStart);						
					}
					//////////////////////NEXT PLATFORM'S XSHIFT AND YSHIFT//////////////////////
					if(	Emulator.getPlatform()[i].getYShift()<0 || Emulator.getPlatform()[i].getXShift()!=0 && wallHight > (hight/2))
					{	wall= platformXStart;
						wallJumpCap =previousYEnd;								
						wallTop=platformYStart;
						wallBottom = Emulator.getPlatform()[i].getPlatformYlocation()+1080; 
					}	
				}
			}	
		}
		//////////////////////LEFT WALLS//////////////////////
		if(xMovement < 0  && xSpeed<=0 || xSpeed<0)
		{	//////////////////////Y PERAMETER RANGE//////////////////////
			if(	centerXlocation < platformXEnd/2 && centerYlocation+(hight/4) >= platformYStart || centerXlocation > platformXEnd/2 && centerYlocation+(hight/4) >= platformYEnd)
			{	//////////////////////X PERAMETER PERCISION//////////////////////
				if(centerXlocation-width/2+xSpeed <= platformXEnd && centerXlocation >= platformXEnd)
				{	//////////////////////WALL HIGHT//////////////////////
					if(Emulator.getPlatform()[nextPlatform].getXShift()<=0)
					{	wallHight=(int)((Emulator.getPlatform()[nextPlatform].getPlatformSlope()*-Emulator.getPlatform()[nextPlatform].getXShift())+Emulator.getPlatform()[nextPlatform].getPlatformYlocation())-platformYEnd;						
						
					}
					else
					{	wallHight= (Emulator.getPlatform()[i].getPlatformYlocation()+1080)-platformYEnd;						
					}
					//////////////////////PLATFORM'S XSHIFT AND YSHIFT//////////////////////
					if(	Emulator.getPlatform()[nextPlatform].getYShift()>0 || Emulator.getPlatform()[nextPlatform].getXShift()!=0 && wallHight > (hight/2))
					{	wall = platformXEnd;
						wallJumpCap = nextYStart;
						wallTop = platformYEnd;
						wallBottom = Emulator.getPlatform()[i].getPlatformYlocation()+1080; 
					}	
				}
			}	
		}
		
		//////////////////////GROUND DETECTION//////////////////////
		//////////////////////X PERAMETER RANGE//////////////////////
		if(centerXlocation >= platformXStart && centerXlocation < platformXEnd)
		{	pitFall=false;
		    script = 0;
			currentPlatform=i;
			//////////////////////Y PERAMETER PERCISION//////////////////////
			if(centerYlocation+(hight/4)+ySpeed >= currentContact)
			{	activeSlope = Emulator.getPlatform()[i].getPlatformSlope();
				platformContact= currentContact;
				if(xMovement > 0 && xSpeed>=0 || xSpeed>0)
				{	stoppingFriction=Emulator.getPlatform()[i].getRightFriction();
					speedGradient=Emulator.getPlatform()[i].getRightGradient();
				}
				if(xMovement < 0 && xSpeed<=0 || xSpeed<0)
				{	stoppingFriction=Emulator.getPlatform()[i].getLeftFriction();	
					speedGradient=Emulator.getPlatform()[i].getLeftGradient();
				}
				if(speedGradient<1)
				{	speedGradient+=(1-speedGradient)*torque;
				}
			}
		}
	}
	
	nextPlatform = currentPlatform+1;
	if(nextPlatform > Emulator.getPlatform().length-1)
	{	nextPlatform = 0;
	}
	
	if(centerXlocation < Emulator.getPlatform()[currentPlatform].getPlatformXlocation()+Emulator.getPlatform()[currentPlatform].getWidth()/2)
	{	gap = Emulator.getPlatform()[currentPlatform].getXShift();
		if(Emulator.getPlatform()[currentPlatform].getYShift() < 0 )
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformYlocation()-Emulator.getPlatform()[currentPlatform].getYShift();
		}
		else
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformYlocation();
		}	
	}
	else
	{	gap = Emulator.getPlatform()[nextPlatform].getXShift();
		if(Emulator.getPlatform()[nextPlatform].getYShift() > 0 )
		{	yScrollLimit = (int)(Emulator.getPlatform()[currentPlatform].getPlatformSlope()*Emulator.getPlatform()[currentPlatform].getWidth()+Emulator.getPlatform()[currentPlatform].getPlatformYlocation())+Emulator.getPlatform()[nextPlatform].getYShift();
		}
		else
		{	yScrollLimit = (int)(Emulator.getPlatform()[currentPlatform].getPlatformSlope()*Emulator.getPlatform()[currentPlatform].getWidth()+Emulator.getPlatform()[currentPlatform].getPlatformYlocation());
		}
	}
	
	
	
	
	
	//////////////////////MOVEMENT//////////////////////
	if(script==0)
	{	//////////////////////RIGHT MOVEMENT//////////////////////
		if(xMovement==2)
		{		
				//////////////////////CLIMBING//////////////////////
				if(centerXlocation+width/2==wall )
				{	if(centerYlocation >= wallTop && centerYlocation+ySpeed < platformContact )
					{	if(ySpeed >= climbStrength && ySpeed < 1 )
						{	ySpeed=climbStrength;
							currentSprite = Emulator.getClimbRight();
//System.out.println("i.ClimbRight^ ");
System.out.println("y..1  ys="+ySpeed+" cy="+centerYlocation);	
						}
					}
				}	
				else
				{	//////////////////////GROUND SPEED//////////////////////
					if(centerYlocation+ySpeed >= platformContact )
					{	if(xSpeed >= 0)
						{	if(acceleration >= 0)
							{	//////////////////////ACCELERATION//////////////////////
								if(xSpeed+acceleration <= topSpeed*speedGradient)
								{	if(activeSlope <= 0)
									{	xSpeed += acceleration;	 	
System.out.println("x.1  xs="+xSpeed+" cx="+centerXlocation);
									}					
									else
									{	xSpeed += acceleration*speedGradient;
System.out.println("x.2  xs="+xSpeed+" cx="+centerXlocation);
									}					
								}
								else
								{	//////////////////////HILL//////////////////////
									if(activeSlope < 0 && xSpeed-stoppingFriction>=topSpeed*speedGradient)
									{	xSpeed-=stoppingFriction/2;	 	
System.out.println("x.3 xs="+xSpeed+" cx="+centerXlocation);
									}					
									else
									{	xSpeed=topSpeed*speedGradient;
System.out.println("x.4  xs="+xSpeed+" cx="+centerXlocation);		
									}
								}	
							}
						}	
						//////////////////////INCLINE SPEED MINIMUM//////////////////////
						if((int)xSpeed == 0 && activeSlope <= 0 && xMovement!=-3)
						{	xSpeed=1;
System.out.println("x.6  xs="+xSpeed+" cx="+centerXlocation);
						}		
					}	
					else
					{	//////////////////////AIR//////////////////////
						if(xSpeed+acceleration <= topSpeed*speedGradient)
						{	if(xSpeed>=0)
							{	if(centerXlocation-width/2 != wall && climbingRight==false)
								{	xSpeed += acceleration;
System.out.println("x.7  xs="+xSpeed+" cx="+centerXlocation);
								}

							}
							else
							{	xSpeed = 1;
System.out.println("x.9  xs="+xSpeed+" cx="+centerXlocation);
							}
						}
					}
				}	
				
		}
		//////////////////////LEFT MOVEMENT//////////////////////
		if(xMovement==-2)
		{		
				//////////////////////CLIMBING//////////////////////
				if(centerXlocation-width/2==wall )
				{	if(centerYlocation >= wallTop && centerYlocation+ySpeed < platformContact )
					{	
System.out.println("y..2 ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop);	
						if(ySpeed > climbStrength && ySpeed<1 )
						{	ySpeed=climbStrength;
							currentSprite = Emulator.getClimbLeft();
//System.out.println("i.ClimbLeft^ ");
						}
					}
				}	
				else
				{	//////////////////////GROUND SPEED//////////////////////
					if(centerYlocation+ySpeed >= platformContact)
					{	if(xSpeed <= 0)  
						{	if(acceleration <= 0)
							{	//////////////////////ACCELERATION//////////////////////
								if(xSpeed+acceleration >= -topSpeed*speedGradient)
								{	if(activeSlope >= 0)
									{	xSpeed += acceleration;	 	
System.out.println("x.10  xs="+xSpeed+" cx="+centerXlocation);		
									}					
									else
									{	xSpeed += acceleration*speedGradient;
System.out.println("x.11  xs="+xSpeed+" cx="+centerXlocation);
									}							
								}
								else
								{	//////////////////////HILL//////////////////////
									if(activeSlope > 0 && xSpeed+stoppingFriction<=-topSpeed*speedGradient)
									{	xSpeed += stoppingFriction/2;
System.out.println("x.12  xs="+xSpeed+" cx="+centerXlocation);		
									}
									else
									{	xSpeed = -topSpeed*speedGradient;
System.out.println("x.13  xs="+xSpeed+" cx="+centerXlocation);
									}
								}	
							}
						}
						//////////////////////INCLINE SPEED MINIMUM//////////////////////
						if((int)xSpeed == 0 && activeSlope>=0 && xMovement!=-3)
						{	xSpeed=-1;
System.out.println("x.15  xs="+xSpeed+" cx="+centerXlocation);							
						}
					}
					else
					{	//////////////////////AIR//////////////////////
						if(xSpeed+acceleration >= -topSpeed*speedGradient)
						{	if(xSpeed <= 0)
							{	if(centerXlocation+width/2 != wall && climbingLeft==false)
								{	xSpeed += acceleration;
System.out.println("x.16 xs="+xSpeed+" cx="+centerXlocation);	
								}
									
							}
							else
							{	xSpeed = -1;
System.out.println("x.18 "+xSpeed+" "+speedGradient);
							}
						}
					}
				}
			
		}
		
		//////////////////////STOPPING AND SLIDING//////////////////////
		if( centerYlocation+ySpeed >= platformContact)
		{	//////////////////////GOING RIGHT//////////////////////
			if(xMovement == 1 || xMovement == 3)
			{	if(xSpeed-stoppingFriction >= 0)
				{	xSpeed -= stoppingFriction;
System.out.println("x.19 xs="+xSpeed+" cx="+centerXlocation+" sf= -"+stoppingFriction);
					if(xMovement == 3 && xSpeed-acceleration >= 0)
					{	xSpeed -= acceleration;
						currentSprite = Emulator.getSlideRight();
//System.out.println("i.SlideRight");
System.out.println("x.20  xs="+xSpeed+" cx="+centerXlocation+" a= -"+ acceleration);			
					}
				}
				else
				{	xSpeed = 0;
					if(xMovement == 3)
					{	xMovement = -2;
					}
System.out.println("x.21 xs="+xSpeed+" cx="+centerXlocation);
				}
			}
			//////////////////////GOING LEFT//////////////////////
			if(xMovement == -1 || xMovement == -3)
			{	if(xSpeed+stoppingFriction <= 0)
				{	xSpeed += stoppingFriction;
System.out.println("x.22 xs="+xSpeed+" cx="+centerXlocation+" sf= "+stoppingFriction);
					if(xMovement == -3 && xSpeed-acceleration <= 0)
					{	xSpeed -= acceleration;
						currentSprite = Emulator.getSlideLeft();
//System.out.println("i.SlideLeft");
System.out.println("x.23  xs="+xSpeed+" cx="+centerXlocation+" a= "+acceleration);
					}
				}
				else
				{	xSpeed = 0;
					if(xMovement == -3)
					{	xMovement = 2;
					}
System.out.println("x.24 xs="+xSpeed+" cx="+centerXlocation);
				}
			}	
		}
	}	

	//////////////////////RIGHT INTERACTIONS//////////////////////
	if(xMovement > 0)
	{	climbingLeft=false;
		//////////////////////WALL DETECTION//////////////////////
		if(centerXlocation+width/2+xSpeed >= wall )
		{	if(centerYlocation > wallTop)
			{	centerXlocation = wall-width/2;
				xSpeed=0;
				airJumpAllow=false;
System.out.println("x.23 xs="+xSpeed+" cx="+centerXlocation+" "+xMovement+" ");
				if(centerYlocation < platformContact && wallHight > verticalLeap*(verticalLeap/2/gravity+0.5))
				{	if(script==2)
					{	ySpeed=-1;
						script=0;
						if(Emulator.getKeyCounter()<=0)
						{	xMovement=1;
						}
System.out.println("y..3  ys="+ySpeed+" cy="+centerYlocation);			
					}
					//////////////////////WALL GRIP DELAY//////////////////////
					if(ySpeed>=0)
					{	if(ySpeed>=1)
						{	ySpeed+=climbStrength/3;	
System.out.println("y..4  ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop);
						}
						if(centerYlocation-(hight/2) <= wallTop && climbingRight == false)
						{	ySpeed=8;
System.out.println("y..5  ys="+ySpeed+" cy="+centerYlocation);	
						}	
					}
					if(ySpeed<=1)
					{	
						//////////////////////WALL SLIP//////////////////////
						if(xMovement==1 && ySpeed>=climbStrength)
						{	ySpeed=wallSlip;
System.out.println("y..6  ys="+ySpeed+" cy="+centerYlocation);			
						}
					}
					
					climbingRight=true;
				}	
			} 
			else
			{	//////////////////////LEDGE TAKE OFF //////////////////////
				if(climbingRight==true && wallHight > verticalLeap*(verticalLeap/2/gravity+0.5))
				{	airJumpAllow=true;
					centerYlocation=wallTop;
					ySpeed=verticalLeap;
					xSpeed=topSpeed/2;
System.out.println("x.24 xs="+xSpeed+" cx="+centerXlocation);
System.out.println("y..7  ys="+ySpeed+" cy="+centerYlocation);
				}
			}
		}
		if(centerYlocation <= wallTop)
		{	climbingRight=false;
		}	
		//////////////////////SLOPE Y SPEEDS//////////////////////
		if(centerYlocation+ySpeed >= platformContact)
		{	if(xSpeed>=0)
			{	if(activeSlope>0 && ySpeed > 0 && pitFall==false)
				{	ySpeed=hight/2;
					if(ySpeed>=Emulator.getResolutionY())
					{	ySpeed=Emulator.getResolutionY()-(centerYlocation+(hight/2));
					}
System.out.println("y..8  ys="+ySpeed+" cy="+centerYlocation+" as="+activeSlope);
				}		
				else
				{	centerYlocation=platformContact;
					ySpeed=0;
System.out.println("y..9  ys="+ySpeed+" cy="+centerYlocation);				
				}
			}
			if (xSpeed == 0)
			{	currentSprite = Emulator.getStandRight();
//System.out.println("i.StandRight");
			}
			if (xSpeed > 0 && xMovement!=3)
			{	currentSprite = Emulator.getRunRight();
//System.out.println("i.RunRight");
			}
			
		}
		else
		{	//////////////////////WALL GRAVITY//////////////////////
			if (centerXlocation+width/2 == wall && centerYlocation > wallTop)
			{	if (ySpeed >= gravity)
				{	currentSprite = Emulator.getWallSlideRight();
//System.out.println("i.WallSlideRight");
				}
				if (ySpeed < climbStrength)
				{	ySpeed += gravity;
System.out.println("y..10  ys="+ySpeed+" cy="+centerYlocation);
					currentSprite = Emulator.getWallJumpRight();
//System.out.println("i.WallJumpRight");
				}
			}
			else
			{	//////////////////////AIR//////////////////////
				if(ySpeed==hight/2)
				{	ySpeed=activeSlope*xSpeed/2;
System.out.println("y..11  ys="+ySpeed+" cy="+centerYlocation);
				}
				ySpeed += gravity;
System.out.println("y..12  ys="+ySpeed+" cy="+centerYlocation);
				if (ySpeed < 0)
				{	if (script == 2)
					{	currentSprite = Emulator.getWallLeapRight();
//System.out.println("i.WallLeapRight");
					}
					else
					{	currentSprite = Emulator.getJumpRight();
//System.out.println("i.JumpRight");
					}
				}
				else
				{	currentSprite = Emulator.getFallRight();
//System.out.println("i.FallRight");
				}
			}
			
		}
		
	}		
	
	//////////////////////LEFT OBJECT INTERACTIONS//////////////////////	
	if(xMovement < 0 )
	{	climbingRight=false;
		//////////////////////WALL DETECTION//////////////////////
		if(centerXlocation-width/2+xSpeed<= wall)
		{	if(centerYlocation > wallTop)
			{	centerXlocation = wall+width/2;
				xSpeed=0;
				airJumpAllow=false;
System.out.println("x.25 xs="+xSpeed+" cx="+(centerXlocation)+" wt="+wallTop);
				if(centerYlocation < platformContact && wallHight > verticalLeap*(verticalLeap/2/gravity+0.5))
				{	if(script==2)
					{	ySpeed=-1;
						script=0;
						if(Emulator.getKeyCounter()>=0)
						{	xMovement=-1;
						}
System.out.println("y..13  ys="+ySpeed+" cy="+(centerYlocation-(hight/2))+" wt="+wallTop);			
					}
					//////////////////////WALL GRIP DELAY//////////////////////
					if(ySpeed>=0)
					{	if(ySpeed>=1)
						{	ySpeed+=climbStrength/3;	
System.out.println("y..14  ys="+ySpeed+" cy="+centerYlocation);
						}
						if(centerYlocation-(hight/2) <= wallTop && climbingLeft == false)
						{	ySpeed=8;
System.out.println("y..15  ys="+ySpeed+" cy="+centerYlocation);		
						}	
					}
					if(ySpeed<=1)
					{	//////////////////////WALL SLIP//////////////////////
						if(xMovement==-1 && ySpeed>=climbStrength)
						{	ySpeed=wallSlip;
System.out.println("y..16  ys="+ySpeed+" cy="+centerYlocation);			
						}
					}
					climbingLeft=true;		
				}	
			} 
			else
			{	//////////////////////LEDGE TAKE OFF //////////////////////
				if(climbingLeft==true && wallHight > verticalLeap*(verticalLeap/2/gravity+0.5))
				{	airJumpAllow=true;
					centerYlocation=wallTop;
					ySpeed=verticalLeap;
					xSpeed=-topSpeed/2;
System.out.println("x.26 xs="+xSpeed+" cx="+centerXlocation);
System.out.println("y..17  ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop+" PC="+platformContact);
				}
			}
		}
		if(centerYlocation<=wallTop)
		{	climbingLeft=false;
		}
		//////////////////////SLOPE Y SPEEDS//////////////////////
		if(centerYlocation+ySpeed >= platformContact)
		{	if (xSpeed<=0)
			{	if(activeSlope<0 && ySpeed>0 && pitFall==false)
				{	ySpeed=hight/2;
					if(ySpeed>=Emulator.getResolutionY())
					{	ySpeed=Emulator.getResolutionY()-(centerYlocation+(hight/2));
					}
System.out.println("y..18  ys="+ySpeed+" cy="+centerYlocation+" PC="+platformContact);
				}
				else
				{	centerYlocation=platformContact;
					ySpeed=0;
System.out.println("y..19  ys="+ySpeed+" cy="+centerYlocation+" PC="+platformContact);
				}	
			}
			if (xSpeed == 0 )
			{	currentSprite = Emulator.getStandLeft();
//System.out.println("i.StandLeft");
			}
			if (xMovement==-2)
			{	currentSprite = Emulator.getRunLeft();
//System.out.println("i.RunLeft");
			}
		}
		else
		{	//////////////////////WALL GRAVITY//////////////////////
			if (centerXlocation-width/2 == wall && centerYlocation > wallTop)
			{	if (ySpeed >= gravity)
				{	currentSprite = Emulator.getWallSlideLeft();
//System.out.println("i.WallSlideLeft");
				}
				if (ySpeed < climbStrength)
				{	ySpeed += gravity;
System.out.println("y..20  ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop);
					currentSprite = Emulator.getWallJumpLeft();
//System.out.println("i.WallJumpLeft");
				}
			}
			else
			{	//////////////////////AIR//////////////////////
				if(ySpeed==hight/2)
				{	ySpeed=activeSlope*xSpeed/2;
System.out.println("y..21  ys="+ySpeed+" cy="+centerYlocation);
				}
				ySpeed += gravity;
System.out.println("y..22  ys="+ySpeed+" cy="+centerYlocation);
				if (ySpeed < 0)
				{	if(script == 2)
					{	currentSprite = Emulator.getWallLeapLeft();
//System.out.println("i.WallLeapLeft");
					}
					else
					{	currentSprite = Emulator.getJumpLeft();
//System.out.println("i.JumpLeft");
					}
				}
				else
				{	currentSprite = Emulator.getFallLeft();
//System.out.println("i.FallLeft");
				}
			}	
		}	
	}

	//////////////////////JUMPING//////////////////////
	if(jump==true && keyHeld==false) 
	{	keyHeld=true;
		//////////////////////ON GROUND//////////////////////
		if (centerYlocation+ySpeed >= platformContact) 
		{	ySpeed = verticalLeap;
			airJumpAllow=true;
System.out.println("y..23  ys="+ySpeed+" cy="+centerYlocation);
		}
		else
		//////////////////////IN AIR//////////////////////
		{	//////////////////////DOUBLE JUMP//////////////////////
			if(airJumpAllow==true)
			{	airJumpAllow=false;
				ySpeed=airJump;
System.out.println("y..34  ys="+ySpeed+" cy="+centerYlocation);	
			}
			if(ySpeed <= 1)
			{	//////////////////////ON RIGHT WALL //////////////////////
				if(centerXlocation+width/2==wall)
				{	//////////////////////UNDER WALL-JUMP CAP//////////////////////
					if(centerYlocation > wallJumpCap && gap <= verticalLeap*((defaults[3]/2+climbStrength*2)/gravity))
					{	script=2;
						xMovement=-2;
						xSpeed=verticalLeap;
System.out.println("x.28 xs="+xSpeed+" cx="+centerXlocation+" ?="+gap);						
						//////////////////////LEFT OVERSHOOT PREVENTION//////////////////////
						if(Emulator.getXKey() > 0 && centerYlocation-(hight/4)+((gap-width)/xSpeed*verticalLeap+(gap-width)/xSpeed*gravity) < wallJumpCap)
						{	ySpeed=-((centerYlocation-wallJumpCap)+(gap-width)/xSpeed*gravity)/(gap-width)/xSpeed;
System.out.println("y..25  ys="+ySpeed+" cy="+centerYlocation+" WJC="+wallJumpCap);
						}
						else
						{	ySpeed=defaults[3]/2+climbStrength*2; 
System.out.println("y..26  ys="+ySpeed+" cy="+centerYlocation);
						}
					}
					else
					//////////////////////OVER WALL-JUMP CAP//////////////////////
					{	airJumpAllow=true;
						climbingRight=true;
						ySpeed=climbStrength*1.5;
						if(keyPress<0)
						{	xMovement=-2;
							xSpeed=verticalLeap;
							ySpeed=defaults[3]/2+climbStrength*2;
						}	
System.out.println("y..27  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
					}
				}
				//////////////////////ON LEFT WALL//////////////////////
				if(centerXlocation-width/2==wall)
				{	//////////////////////UNDER WALL-JUMP CAP//////////////////////
					if(centerYlocation > wallJumpCap && gap <= -verticalLeap*((defaults[3]/2+climbStrength*2)/gravity))
					{	script=2;
						xMovement=2;
						xSpeed=-verticalLeap;
System.out.println("x.30 xs="+xSpeed+" cx="+centerXlocation+" estimate="+(centerYlocation+((gap-width)/(topSpeed*speedGradient*2)*verticalLeap+(gap-width)/(topSpeed*speedGradient*2)*gravity)));
						//////////////////////RIGHT OVERSHOOT PREVENTION//////////////////////
						if(Emulator.getXKey() < 0 && centerYlocation-(hight/4)+((gap-width)/xSpeed*verticalLeap+(gap-width)/xSpeed*gravity) < wallJumpCap)
						{	ySpeed=-((centerYlocation-wallJumpCap)+(gap-width)/(topSpeed*speedGradient*2)*gravity)/(gap-width)/(topSpeed*speedGradient*2); 
System.out.println("y..30  ys="+ySpeed+" cy="+centerYlocation+" WJC="+wallJumpCap+" estimate="+(centerYlocation+((gap-width)/(topSpeed*speedGradient*2)*verticalLeap+(gap-width)/(topSpeed*speedGradient*2)*gravity)));
						}
						else
						{	ySpeed=defaults[3]/2+climbStrength*2;
System.out.println("y..31  ys="+ySpeed+" cy="+centerYlocation+" gap="+gap);
						}
					}
					else
					//////////////////////OVER WALL-JUMP CAP//////////////////////		
					{	airJumpAllow=true;
						climbingLeft=true;
						ySpeed=climbStrength*1.5;
						if(keyPress>0)
						{	xMovement = 2;
							xSpeed=-verticalLeap;
							ySpeed=defaults[3]/2+climbStrength*2;
						}
System.out.println("y..32  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
					}
				}
			}
			
		}
	}
	//////////////////////WORLD END COLLISION//////////////////////
	if (centerXlocation-width/2+xSpeed <= Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue() && xSpeed < 0)
	{	xSpeed = 0;
System.out.println("x.31 xs="+xSpeed+" cx="+centerXlocation+" | wStart="+(Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue()));
	}
	//////////////////////RESPAWN//////////////////////
	if(centerYlocation+ySpeed>=Emulator.getResolutionY())
	{	respawnDistance=Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue();
		script=1;
		xMovement=1;
	}	
	//////////////////////SCRIPT 1 RESPAWN//////////////////////
	if(script==1)
	{	int	restartScrollSpeed=100;
		currentSprite=Emulator.getNone();
		centerYlocation=Emulator.getTopScrollingValue();
		ySpeed=0;
System.out.println("y..36  ys="+ySpeed+" cy="+centerYlocation);
		xSpeed=0;
System.out.println("x.32 xs="+xSpeed+" cx="+centerXlocation+" RD="+respawnDistance);
		if(respawnDistance+restartScrollSpeed <= 0)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+restartScrollSpeed);
			}
			Emulator.getMidGround2().setBackgroundXvalue((int)(Emulator.getMidGround2().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((int)(Emulator.getMidGround1().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((int)(Emulator.getForeGround2().getBackgroundXvalue()+restartScrollSpeed/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((int)(Emulator.getForeGround1().getBackgroundXvalue()+restartScrollSpeed/1.6));
			respawnDistance+=restartScrollSpeed;
		}
		else
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()-respawnDistance);
			}
			Emulator.getMidGround2().setBackgroundXvalue((int)(Emulator.getMidGround2().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((int)(Emulator.getMidGround1().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((int)(Emulator.getForeGround2().getBackgroundXvalue()-respawnDistance/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((int)(Emulator.getForeGround1().getBackgroundXvalue()-respawnDistance/1.6));
			script=0;
		}	
	}
	//////////////////////X LOCATION UPDATE//////////////////////
	if (centerXlocation-width/2+xSpeed >= Emulator.getLeftScrollingValue() && centerXlocation+width/2+xSpeed <= Emulator.getRightScrollingValue()|| Emulator.getMatchOver()==4) 
	{	centerXlocation += xSpeed;
//System.out.println("sx.HorrizontalUpdate XS="+xSpeed+" CX="+centerXlocation);	
	}
	//////////////////////RIGHT SCROLLING VALUE//////////////////////			
	if (centerXlocation+width/2+xSpeed > Emulator.getRightScrollingValue()&&climbingRight==false && Emulator.getMatchOver() <4)
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+((int)(-xSpeed)+(Emulator.getRightScrollingValue()-(centerXlocation+width/2))));
		}
		Emulator.getMidGround2().setBackgroundXvalue(Emulator.getMidGround2().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2)))/3.0));
		Emulator.getMidGround1().setBackgroundXvalue(Emulator.getMidGround1().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2)))/3.0));
		Emulator.getForeGround2().setBackgroundXvalue(Emulator.getForeGround2().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2)))/1.6));
		Emulator.getForeGround1().setBackgroundXvalue(Emulator.getForeGround1().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2)))/1.6));
		centerXlocation = Emulator.getRightScrollingValue()-width/2;
//System.out.println("sx.RightScrolling XS="+xSpeed+" CX="+centerXlocation);
	}
	//////////////////////LEFT SCROLLING VALUE//////////////////////
	if (centerXlocation-width/2+xSpeed < Emulator.getLeftScrollingValue()&&climbingLeft==false&& Emulator.getMatchOver() <4 )
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+((int)(-xSpeed)+(Emulator.getLeftScrollingValue()-(centerXlocation-width/2))));
		}
		Emulator.getMidGround2().setBackgroundXvalue(Emulator.getMidGround2().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2)))/3.0));
		Emulator.getMidGround1().setBackgroundXvalue(Emulator.getMidGround1().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2)))/3.0));
		Emulator.getForeGround2().setBackgroundXvalue(Emulator.getForeGround2().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2)))/1.6));
		Emulator.getForeGround1().setBackgroundXvalue(Emulator.getForeGround1().getBackgroundXvalue()+(int)((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2)))/1.6));
		centerXlocation = Emulator.getLeftScrollingValue()+width/2;
//System.out.println("sx.LeftScrolling XS="+xSpeed+" CX="+centerXlocation);
	}
	//////////////////////Y lOCATION UPDATE//////////////////////
	
	

	//////////////////////VIRTICAL PLATFORM SCROLLING//////////////////////
	if(centerYlocation+ySpeed >= platformContact)
	{	airJumpAllow=false;
		if(centerYlocation+ySpeed>= Emulator.getTopScrollingValue() && centerYlocation <= Emulator.getBottomScrollingValue()|| pitFall==true)
		{	centerYlocation = platformContact;
//System.out.println("sy.Ground VerticalUpdate YS="+ySpeed+" CY="+centerYlocation);	
		}
		if(centerYlocation+ySpeed < Emulator.getTopScrollingValue())
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation(Emulator.getPlatform()[i].getPlatformYlocation()+Emulator.getTopScrollingValue()-platformContact);	
			}
			centerYlocation=Emulator.getTopScrollingValue();	
//System.out.println("sy.Ground TopScroll YS="+ySpeed+" CY="+centerYlocation);
		}
		if(centerYlocation>Emulator.getBottomScrollingValue()&&pitFall==false)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation(Emulator.getPlatform()[i].getPlatformYlocation()+(Emulator.getBottomScrollingValue()-platformContact));
			}
			centerYlocation = Emulator.getBottomScrollingValue();
//System.out.println("sy.Ground BottomScroll YS="+ySpeed+" CY="+centerYlocation);	
		}
	}
	//////////////////////VIRTICAL AIR SCROLLING//////////////////////
	else
	{	if(centerYlocation+ySpeed>= Emulator.getTopScrollingValue())
		{	centerYlocation += ySpeed;
//System.out.println("sy.Air VerticalUpdate YS="+ySpeed+" CY="+centerYlocation+" WT="+wallTop);
		}
		if(centerYlocation+ySpeed < Emulator.getTopScrollingValue())
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation( Emulator.getPlatform()[i].getPlatformYlocation()+(((int)-ySpeed)+(Emulator.getTopScrollingValue()-centerYlocation)));
			}
			centerYlocation=Emulator.getTopScrollingValue();	
//System.out.println("sy.Air TopScroll YS="+ySpeed+" CY="+centerYlocation);
		}
		if(centerYlocation > Emulator.getBottomScrollingValue()) 
		{	if(	pitFall == false ||  pitFall == true && yScrollLimit > Emulator.getTopScrollingValue())
			{	for(int i = 0; i < Emulator.getPlatform().length; i++)
				{	Emulator.getPlatform()[i].setPlatformYlocation( Emulator.getPlatform()[i].getPlatformYlocation()+(((int)-ySpeed)+(Emulator.getBottomScrollingValue()-centerYlocation)));
				}
			centerYlocation = Emulator.getBottomScrollingValue();
//System.out.println("sy.Air BottomScroll YS="+ySpeed+" CY="+centerYlocation);	
			}
		}
	}
		
}
	//////////////////////SETTERS AND GETTERS//////////////////////
	
	public int getCenterXlocation() 
	{	return centerXlocation;
	}
	public void setCenterXlocation(int centerXlocation) 
	{	this.centerXlocation = centerXlocation;
	}
	public int getCenterYlocation() 
	{	return centerYlocation;
	}
	public void setCenterYlocation(int centerYlocation) 
	{	this.centerYlocation = centerYlocation;
	}
	public void setYSpeed(int ySpeed) 
	{	this.ySpeed = ySpeed;
	}
	public double getXMovement() 
	{	return xMovement;
	}
	public void setXMovement(double xMovement) 
	{	this.xMovement = xMovement;	
	}
	public double getGradient() 
	{	return speedGradient;
	}
	public void setGradient(double gradient) 
	{	this.speedGradient = gradient;	
	}
	public void setPlayerNumber(int playerNumber) 
	{	this.playerNumber = playerNumber;
	}
	public Image getCurrentSprite() 
	{	return currentSprite;
	}
	public void setPlatformContact(int platformContact) 
	{	this.platformContact = platformContact;
	}
	public void setActiveSlope(double activeSlope) 
	{	this.activeSlope = activeSlope;	
	}
	public int getWall() 
	{	return wall;
	}
	public int getPlatformContact() 
	{	return platformContact;
	}
	public int getWallTop() 
	{	return wallTop;
	}
	public int getScript() 
	{	return script;
	}
	public void setJump(boolean jump) 
	{	this.jump = jump;
	}
	public void setKeyHeld(boolean keyHeld) 
	{	this.keyHeld = keyHeld;
	}
	public boolean getClimbingLeft() 
	{	return climbingLeft;
	}
	public boolean getClimbingRight() 
	{	return climbingRight;
	}
	public int getWidth() {
		return width;
	}
	public int getHight() {
		return hight;
	}
	public int getWallJumpCap() 
	{	return wallJumpCap;
	}
}