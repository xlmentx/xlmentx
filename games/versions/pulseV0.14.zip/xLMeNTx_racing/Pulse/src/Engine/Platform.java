package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{							/////////////////STARTING INITIALIZATIONS/////////////////
	private int				width = 1440,			widthMin= Emulator.getLeftScrollingValue()+50,	
							xShift = 0,				yShift = 0,	
							maxAngle=80, 			incline = 1,
							slopeYOffset,			baseYOffset,
							slopeXOffset;
	private double 			rightGradient= 1,		leftGradient= 1,
							friction = 0.5,	
							rightFriction= leftGradient*friction,	
							leftFriction= rightGradient*friction;
						  
							/*FIRST HALF OF EACH ARRAY GENERATES GAPS/WALLS/DOWNWARD_SLOPES *respectively
						   	SECOND HALF OF EACH ARRAY GENERATES OVERLAPS/DROPS/UPWARD_SLOPES *respectively
						   	THE LENGTH OF THE ARRAYS DETERMINS PERSCISION OF EACH MAX_RANGE
						   	THE VALUE DETERMINES THE RATE AT WHICH THE PROPERTIES WILL APPEAR
							EX.
							array = {mWall%,LWall%,mDrop%,LDrop%}
							vs
							array = {sWall%,mWall%,LWall%,xLWall%,sDrop%,mDrop%,LDrop%,xLDrop%}
						    */
							/////////////////{   GAPS  <--|--> OVERLAPS}/////////////////
	private static int[]	xShiftRates =    {5,5,5,0,/*     */0,0,0,0},
							/////////////////{  WALLS  <--|-->  DROPS }/////////////////
							yShiftRates =    {5,5,5,0,/*     */10,5,0,0},
							/////////////////{DOWNWARD <--|--> UPWARD }/////////////////
							slopeRates =     {10,10,5,0,/*     */10,10,5,0}; 
	
	/////////////////DYNAMIC VARIABLE INITIALIZATIONS/////////////////
	private int 			platformHight,					platformXlocation,											
							platformNumber,					platformYlocation;			
	private double  		platformSlope,					totalFriction;
	Random 					generator = new Random();
	private Image 			baseSprite= Emulator.getLevel1_Base(),
							slopeSprite = Emulator.getLevel1_Slope();
	private boolean matchOver;
	/////////////////CONSTRUCTOR/////////////////	
	public Platform (int x, int y)
	{	platformXlocation = x;
		platformYlocation = y;
	}
	/////////////////PLATFORM UPDATE/////////////////
	public void update() 
	{	/////////////////NEXT & PREVIOUS PLATFORM/////////////////
		int maxWidth = 1920, maxHight=1080, 
		previousPlatform = platformNumber-1,	nextPlatform = platformNumber+1;
		if(platformNumber+1 > Emulator.getPlatform().length-1)
		{	nextPlatform = 0;
		}
		if(platformNumber-1 < 0)
		{	previousPlatform = Emulator.getPlatform().length-1;
		}
			
		/////////////////PLATFORM JUMP & RANDOMIZATION/////////////////
		if (platformXlocation+maxWidth+Emulator.getPlatform()[nextPlatform].getXShift() < 0 && Emulator.getMatchOver() < 4)
		{	int arraySum=0,     oldSum=0,     newSum=0,     worldWidth=0,
			xShiftMinimum= Emulator.getPlayer()[0].getWidth(),	yShiftMin=Emulator.getPlayer()[0].getHight(),
			num = generator.nextInt(100),		overlapMax	=	Emulator.getPlatform()[previousPlatform].getWidth();
			
			/////////////////WORLD WIDTH/////////////////
			for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	worldWidth += Emulator.getPlatform()[i].getWidth()+Emulator.getPlatform()[i].getXShift(); 
			}
			worldWidth -= Emulator.getPlatform()[platformNumber].getWidth()+Emulator.getPlatform()[platformNumber].getXShift(); 
			
			/////////////////X SHIFT/////////////////
			xShift=0;
				
			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < xShiftRates.length; i++)
			{	arraySum += xShiftRates[i];
			}
			
			/////////////////SEARCH/////////////////
			for(int i = 0; i < xShiftRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+xShiftRates[i];
				}
				else
				{	newSum = (int)(oldSum+100*(xShiftRates[i]/(double)arraySum));
				}
//System.out.println("xs. Checking xShiftType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
				
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////GAPS/////////////////
					if( i >= 0 && i < xShiftRates.length/2)
					{	xShift = xShiftMinimum+generator.nextInt(Emulator.getResoultionX()/(xShiftRates.length/2)-xShiftMinimum)+Emulator.getResoultionX()/(xShiftRates.length/2)*i;	
//System.out.println("GAP="+xShift);						
					}
					/////////////////OVERLAPS/////////////////
					if( i >= xShiftRates.length/2 && i < xShiftRates.length)
					{	xShift = -generator.nextInt(overlapMax/(xShiftRates.length/2)-xShiftMinimum)-(overlapMax/(xShiftRates.length/2)*(i-xShiftRates.length/2));
//System.out.println("OVERLAP="+xShift);											
					}
					i = xShiftRates.length;
				}	
				
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < xShiftRates.length)
				{	oldSum += xShiftRates[i];
				}
				if( arraySum >= 100 && i < xShiftRates.length)
				{	oldSum += 100*(xShiftRates[i]/(double)arraySum);
				}		
			}
					
			/////////////////Y SHIFT/////////////////
			yShift=0;
			arraySum=0;     oldSum=0;     newSum=0;     num = generator.nextInt(100);

			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < yShiftRates.length; i++)
			{	arraySum += yShiftRates[i];
			}
		
			/////////////////SEARCH/////////////////
			for(int i = 0; i < yShiftRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+yShiftRates[i];
				}
				else
				{	newSum = (int)(oldSum+100*(yShiftRates[i]/(double)arraySum));
				}
//System.out.println("xs. Checking yShiftType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
			
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////WALLS/////////////////
					if( i >= 0 && i < yShiftRates.length/2)
					{	yShift = -yShiftMin-generator.nextInt(maxHight/(yShiftRates.length/2)-yShiftMin)-maxHight/(yShiftRates.length/2)*i;	
//System.out.println("WALL="+yShift);						
					}
					/////////////////DROPS/////////////////
					if( i >= yShiftRates.length/2 && i < yShiftRates.length)
					{	yShift = generator.nextInt(maxHight/(yShiftRates.length/2))+maxHight/(yShiftRates.length/2)*(i-yShiftRates.length/2);	
//System.out.println("DROP="+yShift);						
					}
					i = yShiftRates.length;
				}	
			
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < yShiftRates.length)
				{	oldSum += yShiftRates[i];
				}
				if( arraySum >= 100 && i < yShiftRates.length)
				{	oldSum += 100*(yShiftRates[i]/(double)arraySum);
				}		
			}

			/////////////////POSITION UPDATE/////////////////	
			platformXlocation = Emulator.getPlatform()[previousPlatform].getPlatformXlocation()+Emulator.getPlatform()[previousPlatform].getWidth()+xShift;
			platformYlocation = (int)(Emulator.getPlatform()[previousPlatform].getPlatformSlope()*Emulator.getPlatform()[previousPlatform].getWidth()+Emulator.getPlatform()[previousPlatform].getPlatformYlocation()+yShift);
		
			/////////////////SLOPES/////////////////
			platformSlope = 0;
			arraySum=0;     oldSum=0;     newSum=0;     num = generator.nextInt(100);

			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < slopeRates.length; i++)
			{	arraySum += slopeRates[i];
			}
	
			/////////////////SEARCH/////////////////
			for(int i = 0; i < slopeRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+slopeRates[i];
				}
				else
				{	newSum = (int)(oldSum+100*(slopeRates[i]/(double)arraySum));
				}
//System.out.println("xs. Checking SlopeType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
		
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////DOWNWARD SLOPE/////////////////
					if( i >= 0 && i < slopeRates.length/2)
					{	platformSlope =	Math.tan(Math.toRadians(generator.nextInt(maxAngle/(slopeRates.length/2))+maxAngle/(slopeRates.length/2)*i));
//System.out.println("DOWNWARD="+platformSlope);
					}
					/////////////////UPWARD SLOPE/////////////////
					if( i >= slopeRates.length/2 && i < slopeRates.length)
					{	platformSlope =	-Math.tan(Math.toRadians(generator.nextInt(maxAngle/(slopeRates.length/2))+maxAngle/(slopeRates.length/2)*(i-slopeRates.length/2)));
//System.out.println("UPWARD="+platformSlope);
					}
					i = slopeRates.length;
				}	
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < slopeRates.length)
				{	oldSum += slopeRates[i];
				}
				if( arraySum >= 100 && i < slopeRates.length)
				{	oldSum += 100*(slopeRates[i]/(double)arraySum);
				}		
			}	
		/////////////////PLATFORM DIMENSIONS/////////////////
			/////////////////MAXIMUM SPRITE HIGHT WIDTH LIMIT/////////////////
			if(platformSlope <= maxHight/(double)maxWidth)
			{	width = generator.nextInt(maxWidth)+widthMin;
				/////////////////WORLD WIDTH REQUIREMENT/////////////////
				if(width+xShift+worldWidth < Emulator.getResoultionX()+maxWidth )
				{	width = maxWidth;
//System.out.println("Slope and Width Alteration, S= "+platformSlope+" W= "+width);
				}
			}
			else
			{	width = generator.nextInt((int)(maxHight/platformSlope));
				/////////////////WORLD WIDTH REQUIREMENT/////////////////
				if(width+xShift+worldWidth < Emulator.getResoultionX()+maxWidth )
				{	width = (Emulator.getResoultionX()+maxWidth)-(xShift+worldWidth);
					platformSlope = maxHight/(double)width;
//System.out.println("Slope and Width Alteration, S= "+platformSlope+" W= "+width);					
				}
			}	
//System.out.println(" Width= "+width);					
			platformHight = (int)Math.abs(width*platformSlope);
//System.out.println(" Hight= "+platformHight);	
			
			/////////////////GRADIENT AND FRICTION/////////////////			
			incline = (int)(width*platformSlope);
			if(incline <= 0)
			{	rightGradient=width/(double)(platformHight+width);
				leftGradient=(platformHight+width)/(double)width;
			}
			else
			{	rightGradient=(platformHight+width)/(double)width;
				leftGradient=width/(double)(platformHight+width);
			}
			rightFriction=leftGradient*friction;
			leftFriction=rightGradient*friction;	
//System.out.println(" Lg= "+leftGradient+" Rg= "+rightGradient);			
			
			/////////////////SPRITE OFFSETS/////////////////			
			if(incline <= 0)
			{	////////////////UPWARD SLOPE///////////////////////
				baseYOffset = 0;
				slopeYOffset = incline;
				slopeXOffset = width;
				incline = -1;
			}
			else
			{	////////////////DOWNWARD SLOPE///////////////////////
				baseYOffset = incline;
				slopeYOffset = 0;
				slopeXOffset = 0;
				incline = 1;
			}
			////////////////SPRITE SELECTION///////////////////////
			baseSprite = Emulator.getLevel1_Base();
			slopeSprite = Emulator.getLevel1_Slope();
			
		}
	}		
	/////////////////GETTERS AND SETTERS/////////////////
	public int getPlatformXlocation() 
	{	return platformXlocation;
	}
	public void setPlatformXlocation(int centerXlocation) 
	{	this.platformXlocation = centerXlocation;
	}
	public int getPlatformYlocation() 
	{	return platformYlocation;
	}
	public void setPlatformYlocation(int platformYlocation) 
	{	this.platformYlocation = platformYlocation;
	}
	public int getPlatformNumber() 
	{	return platformNumber;	
	}
	public void setPlatformNumber(int platformNumber) 
	{	this.platformNumber = platformNumber;
	}
	public int getSlopeYOffset() 	
	{	return slopeYOffset;
	}
	public int getSlopeXOffset() 	
	{	return slopeXOffset;
	}
	public int getBaseYOffset() 	
	{	return baseYOffset;
	}
	public Image getSlopeSprite() 
	{	return slopeSprite;
	}
	public int getIncline() 
	{	return incline;
	}
	public double getTotalFriction() 
	{	return totalFriction;
	}
	public double getPlatformSlope() 
	{	return platformSlope;
	}
	
	public double getRightGradient() 
	{	return rightGradient;
	}
	public double getRightFriction() 
	{	return rightFriction;
	}
	public double getLeftGradient() 
	{	return leftGradient;
	}
	public double getLeftFriction() 
	{	return leftFriction;
	}
	public int getWidth() 
	{	return width;
	}
	public boolean getMatchOver() 
	{	return matchOver;
	}
	public int getXShift() 
	{	return xShift;
	}
	public int getYShift() 
	{	return yShift;
	}
	public int getPlatformHight() {
		return platformHight;
	}public Image getBaseSprite() {
		return baseSprite;
	}
}