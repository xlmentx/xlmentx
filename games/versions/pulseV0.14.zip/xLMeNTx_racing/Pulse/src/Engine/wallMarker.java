package Engine;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;

public class wallMarker 
{	
	private int 			yLocation,			xSpriteShift=0,			xLocation, 
							markerNumber;
	private Image 		currentSprite;
	//////////////////////CONSTRUCTOR//////////////////////
	public wallMarker (int x, int y)
	{	xLocation = x;
		yLocation = y;
	}
	public void update() 
	{	switch(markerNumber)
		{	//////////////////////LEFT SCROLL//////////////////////
			case 0:	xLocation = Emulator.getLeftScrollingValue();	
					yLocation = 0 ;
					currentSprite = Emulator.getVirticalScroll();
					break;
			//////////////////////RIGHT SCROLL//////////////////////
			case 1:	xLocation = Emulator.getRightScrollingValue();	
					yLocation = 0 ;
					currentSprite = Emulator.getVirticalScroll();
					break;
			//////////////////////BOTTOM SCROLL//////////////////////
			case 2:	xLocation = 0;	
					yLocation = Emulator.getBottomScrollingValue();
					currentSprite = Emulator.getHorrizontalScroll();
					break;
			//////////////////////TOP SCROLL//////////////////////
			case 3:	xLocation = 0;	
					yLocation = Emulator.getTopScrollingValue();
					currentSprite = Emulator.getHorrizontalScroll();
					break;
			//////////////////////PLAYER 0 WALL//////////////////////
			case 4:	xLocation = Emulator.getPlayer()[0].getWall();	
					yLocation = Emulator.getPlayer()[0].getWallTop();
					currentSprite = Emulator.getWall();
					break;
			//////////////////////PLAYER 0 WALL JUMP CAP//////////////////////
			case 5:	xLocation = Emulator.getPlayer()[0].getWall();	
					yLocation = Emulator.getPlayer()[0].getWallJumpCap();
					currentSprite = Emulator.getWallJumpCap();
					xSpriteShift = -50;
					break;
		}
		
	}
	public int getXLocation() 
	{	return xLocation;
	}
	public int getYLocation() 
	{	return yLocation;
	}
	public int getXSpriteShift() 
	{	return xSpriteShift;
	}
	public void setYLocation(int yLocation) 
	{	this.yLocation = yLocation;
	}
	public void setXLocation(int xLocation) 
	{	this.xLocation = xLocation;
	}
	public void setMarkerNumber(int markerNumber) 
	{	this.markerNumber = markerNumber;
	}
	public Image getCurrentSprite() {
		return currentSprite;
	}
	
}
