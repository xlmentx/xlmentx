package Engine;

import java.awt.Image;

public class Background 
{	//////////////////////DECLARATIONS//////////////////////		
	private double     		relativeMidStart=0.2,		relativeForeStart=.4,		midYSpeed=.10,	
							foreYSpeed=.194,			backgroundXvalue;	
	private int 			backgroundYvalue,			backgroundType,				backgroundNum,
							backgroundWidth=1920;
	private Image			currentBackGround,			currentMidGround,			currentForeGround;
	
	//////////////////////CONSTRUCTOR//////////////////////
	public Background (int x, int y)
	{	backgroundXvalue = x;
		backgroundYvalue = y;
	}
	//////////////////////BACKGROUND UPDATE//////////////////////
	public void update() 
	{	//////////////////////BACKGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.getCurrentLevel())
		{	case  1: currentBackGround = Emulator.getLevel1_BackGround();   break;
		}
		//////////////////////MIDGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.getCurrentLevel())
		{	case  1: currentMidGround = Emulator.getLevel1_MidGround();   break;
		}
		//////////////////////FOREGROUND SPRITE UPDATE//////////////////////
		switch(Emulator.getCurrentLevel())
		{	case  1: currentForeGround = Emulator.getLevel1_ForeGround();   break;
		}

		//////////////////////Y POSITION//////////////////////
		switch(backgroundType)
		{	case 2:	backgroundYvalue =(int)(Emulator.getResolutionY()*relativeMidStart);
					break;
			case 3:	backgroundYvalue =(int)(Emulator.getResolutionY()*relativeForeStart);
					break;		
		}
		
		if ( backgroundXvalue <= -backgroundWidth)
		{	switch(backgroundNum)
			{	case 1: backgroundXvalue = Emulator.getMidGround2().getBackgroundXvalue()+backgroundWidth;break;
				case 2: backgroundXvalue = Emulator.getMidGround1().getBackgroundXvalue()+backgroundWidth;break;
				case 3: backgroundXvalue = Emulator.getForeGround2().getBackgroundXvalue()+backgroundWidth;break;
				case 4: backgroundXvalue = Emulator.getForeGround1().getBackgroundXvalue()+backgroundWidth;break;
			}
		}
		if ( backgroundXvalue >= backgroundWidth)
		{	switch(backgroundNum)
			{	case 1: backgroundXvalue = Emulator.getMidGround2().getBackgroundXvalue()-backgroundWidth;break;
				case 2: backgroundXvalue = Emulator.getMidGround1().getBackgroundXvalue()-backgroundWidth;break;
				case 3: backgroundXvalue = Emulator.getForeGround2().getBackgroundXvalue()-backgroundWidth;break;
				case 4: backgroundXvalue = Emulator.getForeGround1().getBackgroundXvalue()-backgroundWidth;break;
			}
		}  
	}
	//////////////////////GETTERS AND SETTERS//////////////////////
	public Image getCurrentBackGround() 
	{	return currentBackGround;
	}
	public Image getCurrentMidGround() 
	{	return currentMidGround;
	}
	public Image getCurrentForeGround() 
	{	return currentForeGround;
	}
	public int getBackgroundXvalue() 
	{	return (int)backgroundXvalue;
	}
	public void setBackgroundXvalue(int backgroundXvalue) 
	{	this.backgroundXvalue = backgroundXvalue;
	}
	public int getBackgroundYvalue() 
	{	return (int)backgroundYvalue;
	}
	public void setBackgroundYvalue(int backgroundYvalue) 
	{	this.backgroundYvalue = backgroundYvalue;
	}
	public void setBackgroundType(int backgroundType) 
	{	this.backgroundType = backgroundType;	
	}
	public void setBackgroundNum(int backgroundNum) 
	{	this.backgroundNum = backgroundNum;	
	}
}