package Engine;

import java.awt.Image;

public class Scenery 
{	//////////////////////DECLARATIONS//////////////////////		
	private int				index;
	private double[]		sceneryXY = new double[2];
	
	//////////////////////CONSTRUCTOR//////////////////////
	public Scenery (int index)
	{	this.index = index;
		//////////////////////BACKGROUND //////////////////////
		this.sceneryXY = new double[]{0,0};
		////////////////////// MIDGROUND //////////////////////
		if(index >= 1 && index <=2)	
		{	this.sceneryXY = new double[]{0,Emulator.GameResolutionXY[1]*0.2};
		}	
		////////////////////// FOREGROUND //////////////////////
		if(index >= 3 && index <=4)	
		{	this.sceneryXY = new double[]{0,Emulator.GameResolutionXY[1]*0.4};
		}
	}

	//////////////////////BACKGROUND UPDATE//////////////////////
	public void update() 
	{	if (sceneryXY[0]+Emulator.SceneryResolutionXY[0] <= -Emulator.GameResolutionXY[0])
		{	sceneryXY[0] += Emulator.SceneryResolutionXY[0];
		}
	}
	
	////////////////////// BACKGROUND SPRITE //////////////////////
	static Image getSprite(int index) 
	{	Image currentSprite = Emulator.none; 
		////////////////////// BACKGROUND //////////////////////
		if(index == 0)
		{	currentSprite = Emulator.Background[0];
		}

		////////////////////// MIDGROUND //////////////////////
		if(index >= 1 && index <=2)	
		{	currentSprite = Emulator.Midground[0];
		}	

		////////////////////// FOREGROUND //////////////////////
		if(index >= 3 && index <=5)	
		{	currentSprite = Emulator.Foreground[0];
		}
		
		return currentSprite;
	}
	//////////////////////GETTERS AND SETTERS//////////////////////
	public double[] getSceneryXY() 
	{	return sceneryXY;
	}
}