package Engine;
import java.awt.Image;
public class Character 
{		////////////////////// STATIC VARIABLES //////////////////////
	////////////////////// 		
	static double DefaultAccel = Physics.DefaultFriction+0.2;
	
	////////////////////// DEFAULT STATS AND LIMITS //////////////////////
	static double[]	////////////{grndAccel,	  airAccel,	 topSpeed,	 jump,	  	 doubleJump} 		
					BaseStats = {DefaultAccel,0.2,	  	 20,		 -15,		 -5		},
					EarthClass= {0,			  0,		  0,		  0,		  0		},
					FireClass = {0,			  0,		  0,		  0,		  0		},
					WaterClass= {0,			  0,		  0,		  0,		  0		},
					AirClass  = {0,			  0,		  0,		  0,		  0		},
					StatLimits= {0.3,		  0.3,		  5,		  -5,		  -10	};
		
		////////////////////// STAT UPDATES //////////////////////
	////////////////////// 		
	public static double[] updateStats(int playerNum, int classType, int xpFile)
	{	double[]stats = BaseStats,
	
		////////////////////// CURRENT VALUES //////////////////////
				currentXP = {0,0,0,0,0},
				currentClass = {0,0,0,0,0};
				switch(classType)
				{	case 1:	currentClass = EarthClass;	break;
					case 2:	currentClass = FireClass;	break;
					case 3:	currentClass = WaterClass;	break;
					case 4:	currentClass = AirClass;  	break;
				}
	
		////////////////////// SUMATION AND STATS RETURN //////////////////////
		for(int i = 0; i < stats.length; i++)	
		{	stats[i] += (currentXP[i]/100)*StatLimits[i]+currentClass[i];			
		}
		return stats;
	}
	
		////////////////////// SPRITE UPDATE //////////////////////
	////////////////////// 		
	public static Image getSprite(int index)
	{	Image 	 currentSprite = Emulator.none;
		
		////////////////////// PLAYER VALUES //////////////////////
		int 	playerDirection = Emulator.Player[index].getInputXxYy()[1]; 
		int		spriteIndex = (playerDirection+1)/2;
		double[]velocityXY = Emulator.Player[index].getVelocityXY(),
				proximityXYF = Emulator.Player[index].getProximityXYF();

		////////////////////// RUN //////////////////////
		if(velocityXY[0] != 0)
		{	if(velocityXY[0]*playerDirection > 0)
			{	currentSprite = Emulator.Run[spriteIndex];
			}
			////////////////////// SLIDE //////////////////////
			else
			{	currentSprite = Emulator.Slide[spriteIndex];
			}	
		}
		
		//////////////////////STAND //////////////////////
		else
		{	if(proximityXYF[1] != 180)
			{	currentSprite = Emulator.Stand[spriteIndex];
			}
		}
		
		////////////////////// JUMP //////////////////////
		if(velocityXY[1] <= 0)
		{	if(proximityXYF[1] == 180)
			{	currentSprite = Emulator.Jump[spriteIndex];
			}
		}
		
		////////////////////// FALL //////////////////////
		else
		{	currentSprite = Emulator.Fall[spriteIndex];
		}
		
		////////////////////// RETURN SPRITE //////////////////////
		return currentSprite;
	}	
}