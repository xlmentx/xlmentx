package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	DefaultGravity = 0.5,
					DefaultFriction = DefaultGravity*0.5;
	
		///////////////////// PROXIMITY SCAN //////////////////////
	//////////////////////
	public static double[] scanProximity(double[] centerXY, double[] velocityXY)
	{	/////////////////////// {  XTHETA,  YTHETA,FRICTION} ////////////////////
		double[] proximityXYF = {	  180,	   180,	      0}; 

		////////////////////// PLATFORM SCANS //////////////////////
		for(int i = 0; i < Emulator.Platform.length; i++)
		{	double[] platformXY = Emulator.Platform[i].getPlatformXY();
			double	 width = Emulator.Platform[i].getWidth(),
					 friction = Emulator.Platform[i].getFriction();
		
			////////////////////// RIGHTWARD COLLISION //////////////////////
			if(centerXY[1] > platformXY[1] && velocityXY[0] > 0)
			{	if(centerXY[0] >= platformXY[0] && centerXY[0] <= platformXY[0])
				{	////////////////////// WALL THETA //////////////////////
					proximityXYF[0] = -90;
					////////////////////// WALL FRICTION //////////////////////
					proximityXYF[2] = friction;
				}
			}
			
			////////////////////// LEFTWARD COLLISION //////////////////////
			if(centerXY[1] < platformXY[1] && velocityXY[0] < 0)
			{	if(centerXY[0] <= platformXY[0]+width && centerXY[0] >= platformXY[0]+width)
				{	////////////////////// X THETA //////////////////////
					proximityXYF[0] = 90;
					////////////////////// FRICTION //////////////////////
					proximityXYF[2] = friction;
				}
			}
			
			////////////////////// DOWNWARD COLLISION //////////////////////
			if(centerXY[0] > platformXY[0] && centerXY[0] < platformXY[0]+width)
			{	double slope = Emulator.Platform[i].getSlope(),
					   contact = slope*(centerXY[0]-platformXY[0])+platformXY[1];
			 	if(centerXY[1] >= contact)
				{	////////////////////// Y THETA //////////////////////
			 		proximityXYF[1] = -Math.toDegrees(Math.atan(slope));
					////////////////////// FRICTION //////////////////////
			 		proximityXYF[2] = friction;
				}
			}
		}

		////////////////////// RETURN PROXIMITY VALUES //////////////////////
		return proximityXYF;
	}
	
		///////////////////// FORCES //////////////////////
	//////////////////////
	public static double[] applyForces(double[] centerXY, double[] velocityXY)
	{	Physics physics = new Physics();
//System.out.println("Forces     Vx="+rnd(velocityXY[0])+"	Vy="+rnd(velocityXY[1])+"	V="+rnd(Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2))));
		
		////////////////////// GRAVITY //////////////////////
		double gravity = DefaultGravity;
			   velocityXY[1] += gravity;
//System.out.println("  Gravity  Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
		
		////////////////////// PROXIMITY CHECK //////////////////////
		double[] proximityXYF = physics.scanProximity(centerXY, velocityXY);
				 
		///////////////////// HORRIZONTAL AND VERTICAL COLLISIONS //////////////////////
		for(int i = 0; i <= 1; i++ )
		{	if(proximityXYF[i] != 180)
			{	////////////////////// NORMAL FORCE //////////////////////
				double	velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)), 
						velocityTheta = -Math.atan2(velocityXY[1],velocityXY[0]),
						platformTheta = Math.toRadians(proximityXYF[i]),
						normalTheta = platformTheta + Math.toRadians(90),
						Range1 = Math.toRadians(90),
						Range2 = (proximityXYF[i] >= 0)?
							Math.toRadians(180): -Math.toRadians(180),		
						NormalForce = (normalTheta-velocityTheta >= Range1 && normalTheta-velocityTheta <= Range1*2 
									|| normalTheta-velocityTheta >= Range2 && normalTheta-velocityTheta <= Range2 + Range1)?
							Math.abs(velocityMagnitude*Math.cos(normalTheta-velocityTheta)): 0;
				////////////////////// APPLY NORMAL FORCE //////////////////////
//System.out.println("  vM="+velocityMagnitude+"	vT="+Math.toDegrees(velocityTheta));
//System.out.println("  nF="+NormalForce+"	nT="+Math.toDegrees(normalTheta));
				velocityXY[0] = round(velocityXY[0]+NormalForce*Math.cos(normalTheta));
				velocityXY[1] = round(velocityXY[1]-NormalForce*Math.sin(normalTheta));
//System.out.println("  Normal   Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);

				///////////////////// FRICTION //////////////////////
				velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)); 
				velocityTheta = -Math.atan2(velocityXY[1],velocityXY[0]);
				double	friction = proximityXYF[2],
						frictionForce = friction*Math.cos(platformTheta-velocityTheta);
				////////////////////// APPLY FRICTION //////////////////////
//System.out.println("  vM="+velocityMagnitude+"	vT="+Math.toDegrees(velocityTheta));
//System.out.println("  fF="+frictionForce+"  pT="+Math.toDegrees(platformTheta));
				velocityXY[0] = (Math.abs(velocityXY[0])-Math.abs(frictionForce*Math.cos(platformTheta)) >= 0)?
						velocityXY[0] - frictionForce*Math.cos(platformTheta): velocityXY[0] - velocityXY[0];			
				velocityXY[1] = (Math.abs(velocityXY[1])-Math.abs(frictionForce*Math.sin(platformTheta)) >= 0)?
						round(velocityXY[1]+frictionForce*Math.sin(platformTheta)): round(velocityXY[1]-velocityXY[1]);
//System.out.println("  Friction Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
			}
		}
		
		////////////////////// RETURN SUM OF FORCES //////////////////////
//System.out.println("  Final    Vx="+rnd(velocityXY[0])+"	Vy="+rnd(velocityXY[1]));
		return velocityXY;
	}
	
		///////////////////// ROUND VALUE //////////////////////
	//////////////////////
	public static double round(double value)
	{	double percision = 100;

		value = (int)(value*percision)/percision;
		return value;
	}	
	
}