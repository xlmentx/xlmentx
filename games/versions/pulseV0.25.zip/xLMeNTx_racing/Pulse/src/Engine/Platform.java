package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY//////////////////////
	//////////////////////
	static int[]	////////////{  GAPS	    || OVERLAPS }///////////////
					XShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{  WALLS	||   DROPS  }///////////////
					YShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{     SM,     MD,     LG}///////////////
					WidthRates ={     0,      0,       0}, 
					////////////{ DOWNWARD  ||  UPWARD  }///////////////
					SlopeRates ={0,  0,  0,	   0,  0,  0}; 
	
	static int 		MaxRate = 10, 
					MaxXShift = Emulator.GameResolutionXY[0], 
					MaxYShift = Emulator.GameResolutionXY[0], 
					MaxWidth = Emulator.SceneryResolutionXY[0]*2, 
					WidthMin = Emulator.GameResolutionXY[0]*3/Emulator.Platform.length,
					MaxSlope = 75; 

	static Random 	Rand = new Random();

		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		index;	
	
	private double	width,	slope=0, 	friction = Physics.DefaultFriction;
	
	private double[]platformXY = new double[2];
		
	
		////////////////////// SPRITES //////////////////////
	//////////////////////
	private Image 	baseSprite = Emulator.PlatformBase[Emulator.CurrentLevel],
					slopeSprite = Emulator.PlatformSlope[Emulator.CurrentLevel];
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] platformXY, int width)
	{	this.index = index;
		this.platformXY = platformXY;
		this.width = width;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{
		///////////////// PLATFORM JUMP /////////////////
//System.out.println(index+" startX="+(int)platformXY[0]+" startY="+(int)platformXY[1]);   		
		if (platformXY[0]+width <= -Emulator.GameResolutionXY[0])
		{	
			///////////////// PREVIOUS PLATFORM /////////////////
			int	previous = index-1;
			if(previous < 0)
			{	previous = Emulator.Platform.length-1;
			}
			double previousXEnd = Emulator.Platform[previous].getPlatformXY()[0]+Emulator.Platform[previous].getWidth(),
				   previousYEnd = Emulator.Platform[previous].getPlatformXY()[1]+Emulator.Platform[previous].getWidth()*Emulator.Platform[previous].getSlope();
					
			///////////////// X SHIFT /////////////////
			platformXY[0] = previousXEnd;
			double ratioSum = 0;
			for(int i = 0; i < XShiftRates.length; i++)
			{	ratioSum += XShiftRates[i];
				if(Rand.nextInt(MaxRate) + 1 <= Math.pow(XShiftRates[i],2)/ratioSum)
				{	int rateRange = MaxXShift/(XShiftRates.length/2),
						rangeStart = rateRange*(i-XShiftRates.length/2);
					platformXY[0] = previousXEnd+rangeStart+Rand.nextInt(rateRange);
				}
			}
			
			///////////////// Y SHIFT /////////////////
			platformXY[1] = previousYEnd;
			ratioSum = 0;
			for(int i = 0; i < YShiftRates.length; i++)
			{	ratioSum += YShiftRates[i];
				if(Rand.nextInt(MaxRate) + 1 <= Math.pow(YShiftRates[i],2)/ratioSum)
				{	int rateRange = MaxYShift/(YShiftRates.length/2),
						rangeStart = rateRange*(i-YShiftRates.length/2);
					platformXY[1] = previousYEnd+rangeStart+Rand.nextInt(rateRange);
				}
			}
			
			///////////////// PLATFORM WIDTH /////////////////
			width = WidthMin;    		
			ratioSum = 0;
			for(int i = 0; i < WidthRates.length; i++)
			{	ratioSum += WidthRates[i];
				if(Rand.nextInt(MaxRate) + 1 <= Math.pow(WidthRates[i],2)/ratioSum)
				{	int rateRange = MaxWidth/(WidthRates.length),
						rangeStart = rateRange*i,
						newWidth = rangeStart+Rand.nextInt(rateRange);
					if(newWidth > WidthMin)
					{	width = newWidth;
					}
System.out.println(i+" w="+width+" wm="+WidthMin+" rR="+rateRange+" rS="+rangeStart);				
				}
			}
			///////////////// PLATFORM SLOPE /////////////////
			slope = 0;
			ratioSum = 0;
			for(int i = 0; i < SlopeRates.length; i++)
			{	ratioSum += SlopeRates[i];
				if(Rand.nextInt(MaxRate) + 1 <= Math.pow(SlopeRates[i],2)/ratioSum)
				{	int rateRange = MaxSlope/(SlopeRates.length/2),
						rangeStart = rateRange*(i-SlopeRates.length/2);
					slope = rangeStart+Rand.nextInt(rateRange);
				}
			}
		}
	}		
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] getPlatformXY() 
	{	return platformXY;
	}
	public double getWidth() 
	{	return width;
	}
	public double getSlope() 
	{	return slope;
	}
	public double getFriction() 
	{	return friction;
	}
	public Image getSlopeSprite() 
	{	return slopeSprite;
	}
	public Image getBaseSprite() 
	{	return baseSprite;
	}
	
		////////////////////// SETTERS //////////////////////
	//////////////////////
	public void setPlatformXY(double[] platformXY) 
	{	this.platformXY = platformXY;
	}
}