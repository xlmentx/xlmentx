package Engine;
import java.awt.Image;
public class Character 
{		////////////////////// STATIC VARIABLES //////////////////////
	////////////////////// 		
	static double DefaultAccel = Physics.DefaultFriction+0.2;
	
		////////////////////// DEFAULT STATS //////////////////////
	static double[]	////////////{grndAccel,	  airAccel,	 topSpeed,	 jump,	  	 doubleJump} 		
					BaseStats = {DefaultAccel,0.2,	  	 20,		 -15,		 -5		},
					EarthClass= {0,			  0,		  0,		  0,		  0		},
					FireClass = {0,			  0,		  0,		  0,		  0		},
					WaterClass= {0,			  0,		  0,		  0,		  0		},
					AirClass  = {0,			  0,		  0,		  0,		  0		},
		
		////////////////////// STAT LIMITS //////////////////////					
					StatLimits= {0.3,		  0.3,		  5,		  -5,		  -10	};
		
		////////////////////// STAT UPDATES //////////////////////
	////////////////////// 		
	public static double[] updateStats(int playerNum, int classType, int xpFile)
	{	double[]stats = BaseStats,
	
		////////////////////// CURRENT VALUES //////////////////////
				currentXP = {0,0,0,0,0},
		
				currentClass = {0,0,0,0,0};
				switch(classType)
				{	case 1:	currentClass = EarthClass;	break;
					case 2:	currentClass = FireClass;	break;
					case 3:	currentClass = WaterClass;	break;
					case 4:	currentClass = AirClass;  	break;
				}
	
		////////////////////// SUMATION AND STATS RETURN //////////////////////
		for(int i = 0; i < stats.length; i++)	
		{	stats[i] += (currentXP[i]/100)*StatLimits[i]+currentClass[i];			
		}
		return stats;
	}
	
		////////////////////// SPRITE UPDATE //////////////////////
	////////////////////// 		
	public static Image getSprite(int index)
	{	Image 	 currentSprite = Emulator.None();
		
		////////////////////// PLAYER VALUES //////////////////////
		int [] 	 inputXxYy = Emulator.Player()[index].getInputXxYy(); 
		double[] velocityXY = Emulator.Player()[index].getVelocityXY(),
				 proximityXYF = Emulator.Player()[index].getProximityXYF();
		
		////////////////////// RIGHTWARD MOVEMENT //////////////////////
		if(velocityXY[0] >= 0)
		{	if(inputXxYy[0] >= 0)
			{	currentSprite = Emulator.getRunRight();
			}
			else
			{	currentSprite = Emulator.getSlideRight();
			}
		}
		
		////////////////////// LEFTWARD MOVEMENT //////////////////////
		else
		{	if(inputXxYy[0] <= 0)
			{	currentSprite = Emulator.getRunLeft();
			}
			else
			{	currentSprite = Emulator.getSlideLeft();
			}
		}

		////////////////////// UPWARD MOVEMENT //////////////////////
		if(velocityXY[1] <= 0)
		{	if(proximityXYF[1] == 180)
			{	if(inputXxYy[1] >= 0 && proximityXYF[1] == 180)
				{	currentSprite = Emulator.getJumpRight();
				}
				else
				{	currentSprite = Emulator.getJumpLeft();
				}
			}
		}
		
		////////////////////// DOWNWARD MOVEMENT //////////////////////
		else
		{	if(inputXxYy[1] > 0)
			{	currentSprite = Emulator.getFallRight();
			}
			else
			{	currentSprite = Emulator.getFallLeft();
			}
		}
		
		////////////////////// NO MOVEMENT //////////////////////
		if(velocityXY[0] == 0)
		{	if(proximityXYF[1] != 180)
			{	if(inputXxYy[1] >= 0)
				{	currentSprite = Emulator.getStandRight();
				}
				else
				{	currentSprite = Emulator.getStandLeft();
				}
			}
		}
		
		////////////////////// RETURN SPRITE //////////////////////
		return currentSprite;
	}	
}