package Tests;
public class Tests 
{	
		////////////////////// TESTS //////////////////////
	//////////////////////
	public static void main(String[] args)
	{	double 		vU = Math.atan2(-1,0),
					vUR = Math.atan2(-1,1),
					vR = Math.atan2(0,1),
					vRD = Math.atan2(1,1),
					vD = Math.atan2(1,0),
					vDL = Math.atan2(1,-1),
					vL = Math.atan2(0,-1),
					vLU = Math.atan2(-1,-1),
					
					pU = Math.toRadians(-45),
					pF = Math.toRadians(0),
					pD = Math.toRadians(45),
					pUN = Math.toRadians(-45+90),
					pFN = Math.toRadians(0+90),
					pDN = Math.toRadians(45+90);
					
			
		System.out.println(" vLeft="+round(Math.toDegrees(vL))+" vLeftUp="+round(Math.toDegrees(vLU))+" vUp="+round(Math.toDegrees(vU))+" vUpRight="+round(Math.toDegrees(vUR)));
		System.out.println(" vRight="+round(Math.toDegrees(vR))+" vRightDown="+round(Math.toDegrees(vRD))+" vDown="+round(Math.toDegrees(vD))+" vDownLeft="+round(Math.toDegrees(vDL)));
		
		System.out.println("\n pUp="+round(Math.toDegrees(pU))+" pFlat="+round(Math.toDegrees(pF))+" pDown="+round(Math.toDegrees(pD)));
		System.out.println(" pUpNormal="+round(Math.toDegrees(pUN))+" pFlatNormal="+round(Math.toDegrees(pFN))+" pDownNormal="+round(Math.toDegrees(pDN)));
		
		System.out.println("\n pFN-vLeft="+round(Math.cos(pFN-vL))+" pFN-vLeftUp="+round(Math.cos(pFN-vLU))+" pFN-vUp="+round(Math.cos(pFN-vU))+" pFN-vUpRight="+round(Math.cos(pFN-vUR)));
		System.out.println(" pFN-vRight="+round(Math.cos(pFN-vR))+" pFN-vRightDown="+round(Math.cos(pFN-vRD))+" pFN-vDown="+round(Math.cos(pFN-vD))+" pFN-vDownLeft="+round(Math.cos(pFN-vDL)));
		
		System.out.println("\n pUN-vLeft="+round(Math.cos(pUN-vL))+" pUN-vLeftUp="+round(Math.cos(pUN-vLU))+" pUN-vUp="+round(Math.cos(pUN-vU))+" pUN-vUpRight="+round(Math.cos(pUN-vUR)));
		System.out.println(" pUN-vRight="+round(Math.cos(pUN-vR))+" pUN-vRightDown="+round(Math.cos(pUN-vRD))+" pUN-vDown="+round(Math.cos(pUN-vD))+" pUN-vDownLeft="+round(Math.cos(pUN-vDL)));
		
		System.out.println("\n pDN-vLeft="+round(Math.cos(pDN-vL))+" pDN-vLeftUp="+round(Math.cos(pDN-vLU))+" pDN-vUp="+round(Math.cos(pDN-vU))+" pDN-vUpRight="+round(Math.cos(pDN-vUR)));
		System.out.println(" pDN-vRight="+round(Math.cos(pDN-vR))+" pDN-vRightDown="+round(Math.cos(pDN-vRD))+" pDN-vDown="+round(Math.cos(pDN-vD))+" pDN-vDownLeft="+round(Math.cos(pDN-vDL)));
		
		System.out.println(" ");
		
	}
	
	static double round(double num)
	{	double percision = 100;
		num = ((int)(num*percision))/percision;
		return num;
	}
}