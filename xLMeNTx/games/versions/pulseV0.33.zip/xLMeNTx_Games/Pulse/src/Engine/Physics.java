package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	Gravity = 0.5,
					None = 100,
					input,
					pTheta;
	static double[] centerXY,
					velocityXY;
		///////////////////// PROXIMITY FORCES //////////////////////
	//////////////////////
	public static double[] applyForces(int xInput, double[] oCenterXY, double[] dimensionXY, double[] oVelocityXY)
	{	centerXY = oCenterXY;
		velocityXY = new double[]{oVelocityXY[0], oVelocityXY[1]+Gravity};
		input = xInput;
System.out.println("\nPhysics	Cx="+centerXY[0]+"  Cy="+centerXY[1]+"	Vx="+velocityXY[0]+"  Vy="+velocityXY[1]);
		//////////////////////VISIBLE PLATFORM SCANS //////////////////////
		pTheta = None;
 		for(int i = 0; i < Engine.Platform.length; i++)
		{	if(Engine.Platform[i].OnScreen() == true)
			{	double[] platformXY = Engine.Platform[i].pLocationXY(),
						 pDimensionXY = Engine.Platform[i].pDimensionXY(),
						 pThetaTB = Engine.Platform[i].pThetaTB(),
						 					
				////////////////////// TOP CONTACT //////////////////////
				pStartXY ={ platformXY[0],platformXY[1]},
				pEndXY ={ platformXY[0]+pDimensionXY[0],platformXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[0])};
				proximityCheck(i, pStartXY, pEndXY, pThetaTB[0], -Math.toRadians(90), Engine.Platform[i].pFrictionXY()[1]);
				
				////////////////////// BOTTOM CONTACT //////////////////////
				pStartXY = new double[]{platformXY[0], platformXY[1]+pDimensionXY[1]};
				pEndXY = new double[]{platformXY[0]+pDimensionXY[0], platformXY[1]+pDimensionXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[1])};
				proximityCheck(i, pStartXY, pEndXY, pThetaTB[1], Math.toRadians(90), Engine.Platform[i].pFrictionXY()[1]);
		
				////////////////////// LEFT CONTACT //////////////////////
				pStartXY = new double[]{platformXY[0], platformXY[1]};
				pEndXY = new double[]{platformXY[0], platformXY[1]+pDimensionXY[1]};
				proximityCheck(i, pStartXY, pEndXY, Math.toRadians(90)*-Math.signum(velocityXY[0]), Math.toRadians(90), Engine.Platform[i].pFrictionXY()[0]);
				
				////////////////////// RIGHT CONTACT //////////////////////
				pStartXY = new double[]{platformXY[0]+pDimensionXY[0], platformXY[1]+pDimensionXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[0])};
				pEndXY = new double[]{platformXY[0]+pDimensionXY[0], platformXY[1]+pDimensionXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[1])};
				proximityCheck(i, pStartXY, pEndXY, Math.toRadians(90)*-Math.signum(velocityXY[0]), Math.toRadians(90), Engine.Platform[i].pFrictionXY()[0]);
			
				/*///////////////////// HORIZONTAL CONTACT //////////////////////
				xContact = platformXY[0]+pDimensionXY[0]*(Math.signum(velocityXY[0])-1)/2;
				yContact = Math.tan(vTheta)*(xContact-centerXY[0])+centerXY[1];
				rStart = platformXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[0])*(Math.signum(velocityXY[0])-1)/2;
				rEnd = platformXY[1]+pDimensionXY[1]+pDimensionXY[0]*Math.tan(pThetaTB[1])*(Math.signum(velocityXY[0])-1)/2;
				proximityCheck(i, rStart, yContact, rEnd, new double[]{xContact,yContact}, Math.toRadians(90)*-Math.signum(velocityXY[0]), Math.toRadians(90), Engine.Platform[i].pFrictionXY()[0]);
				*/		
					
					
			}
		}
		
//System.out.println("  finalSum  Vx="+round(velocityXY[0])+"  Vy="+round(velocityXY[1])+"  Cx="+round(centerXY[0])+"  Cy="+round(centerXY[1]));
		return new double[] {centerXY[0], centerXY[1], round(velocityXY[0]), round(velocityXY[1]), pTheta};
	}
	
			///////////////////// PROXIMITY CHECK //////////////////////
	//////////////////////
	private static void proximityCheck(int i, double[] pStartXY, double[] pEndXY, double cTheta, double normal, double pFriction)
	{	double	vTheta = Math.atan2(velocityXY[1],velocityXY[0]);
		////////////////////// COLLISION ORIENTATION //////////////////////
System.out.println("   p"+i+" collision orientation="+Math.cos(cTheta+normal-vTheta));
		if(Math.cos(cTheta+normal-vTheta) <= 0)
		{	double	xContact = (Math.tan(vTheta)*centerXY[0]-Math.tan(cTheta)*pStartXY[0]+pStartXY[1]-centerXY[1])/(Math.tan(vTheta)-Math.tan(cTheta)),
					yContact = Math.tan(cTheta)*(xContact-pStartXY[0])+pStartXY[1];
			////////////////////// VELOCITY XY RANGE //////////////////////
System.out.println("	xRange="+round(velocityXY[0])+" xDistance="+(int)Math.abs(centerXY[0]-xContact)+" yRange="+round(velocityXY[1])+" yDistance="+(int)Math.abs(centerXY[1]-yContact));
			if(Math.abs(velocityXY[0]) >= (int)Math.abs(centerXY[0]-xContact) && Math.abs(velocityXY[1]) >= (int)Math.abs(centerXY[1]-yContact))
			{	////////////////////// PLATFORM XY RANGE //////////////////////
System.out.println("	xStart="+round(pStartXY[0])+" xContact="+round(xContact)+" xEnd="+round(pEndXY[0])+" yStart="+pStartXY[1]+" yContact="+yContact+" yEnd="+pEndXY[1]);
				if(xContact >= pStartXY[0] && xContact <= pEndXY[0] && yContact >= pStartXY[1] && yContact <= pEndXY[1])
				{		pTheta = cTheta;
					centerXY = new double[]{xContact,yContact};
System.out.println("	Collision p"+i+" cT="+round(Math.toDegrees(cTheta))+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" vT="+vTheta);
					////////////////////// NORMAL FORCE //////////////////////
					double	velocity = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)), 
							nForce = Math.abs(velocity*Math.cos(cTheta+normal-vTheta));
					velocityXY[0] += nForce*Math.cos(cTheta+normal);
					velocityXY[1] += nForce*Math.sin(cTheta+normal);
System.out.println("	nF="+round(nForce)+" nFX="+round(nForce*Math.cos(cTheta+normal))+" nFY="+round(nForce*Math.sin(cTheta+normal)));	
				////////////////////// FRICTION FORCE //////////////////////
					if(input*velocityXY[0] <= 0)
					{	double	frictionTheta = Math.atan2(-velocityXY[1],velocityXY[0])+Math.toRadians(180),
								frictionForce = nForce*pFriction;
						if(frictionForce > Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)))
						{	frictionForce = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2));
						}
						//velocityXY[0] += frictionForce*Math.cos(frictionTheta);
						//velocityXY[1] -= frictionForce*Math.sin(frictionTheta);
//System.out.println("  frictionForce Fx="+round(frictionForce*Math.cos(frictionTheta))+"  Fy="+round(-frictionForce*Math.sin(frictionTheta)));
					}
				}
			}
		}		
	}
		
		
		///////////////////// ROUND VALUES //////////////////////
	//////////////////////
	static double round(double num)
	{	double percision = 100;
		num = ((int)(num*percision))/percision;
		return num;
	}
}