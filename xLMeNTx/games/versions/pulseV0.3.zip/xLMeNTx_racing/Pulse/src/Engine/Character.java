package Engine;
import java.awt.Image;
public class Character 
{		////////////////////// STATIC VARIABLES //////////////////////
	////////////////////// 		
	
	////////////////////// DEFAULT STATS AND LIMITS //////////////////////
	static double[]	////////////{groundAccel,	airAccel,	 	topSpeed,	 	jump,	  	 	doubleJump} 		
					BaseStats = {0.3,			0.2, 			30,		 		-15,		 	-10		  },
					StatLimits= {0.2,		  	0.2,		  	3,		  		-3,		  		-3		  },
					////////////////////// CLASS PERKS //////////////////////
					BaseClass = {0,			  	0,		  		0,		  		0,		  		0		  },
					EarthClass= {0,	 	      	0,		  		0,		  		0,		  		0		  },
					FireClass = {0,			  	0,		  		0,		  		0,		  		0		  },
					WaterClass= {0,			  	0,		  		0,		  		0,		  		0		  },
					AirClass  = {0,			  	0,		  		0,		  		0,		  		0		  };
		
		////////////////////// STAT UPDATES //////////////////////
	////////////////////// 		
	public static double[] updateStats(int playerNum, int classType, int xpFile)
	{	double[]stats = BaseStats,
		////////////////////// CURRENT VALUES //////////////////////
				currentXP = {0,0,0,0,0},
				currentClass = BaseClass;
				switch(classType)
				{	case 1:	currentClass = EarthClass;	break;
					case 2:	currentClass = FireClass;	break;
					case 3:	currentClass = WaterClass;	break;
					case 4:	currentClass = AirClass;  	break;
				}
	
		////////////////////// SUMATION AND STATS RETURN //////////////////////
		for(int i = 0; i < stats.length; i++)	
		{	stats[i] += (currentXP[i]/10)*StatLimits[i]+currentClass[i];			
		}
		return stats;
	}
	
		////////////////////// SPRITE UPDATE //////////////////////
	////////////////////// 		
	public static Image getSprite(int[] xInputPL, int jumpCounter, double[] velocityXY, double[] contactThetaXY)
	{	int	spriteIndex = (xInputPL[1]+1)/2;
		Image	currentSprite = Emulator.Stand[spriteIndex];
				
		////////////////////// GROUND //////////////////////
		if(contactThetaXY[1] != Physics.Inactive)
		{	////////////////////// STAND //////////////////////
			if(velocityXY[0] == 0)
			{	currentSprite = Emulator.Stand[spriteIndex];
			}
			////////////////////// RUN //////////////////////
			else
			{	currentSprite = Emulator.Run[spriteIndex];
				////////////////////// SLIDE //////////////////////
				if(velocityXY[0]*xInputPL[0] < 0)
				{	currentSprite = Emulator.Slide[spriteIndex];
				}
			}
		}
		
		////////////////////// AIR //////////////////////
		if(contactThetaXY[0] == Physics.Inactive && contactThetaXY[1] == Physics.Inactive)
		{	////////////////////// JUMP //////////////////////
			if(velocityXY[1] < 0)
			{	currentSprite = Emulator.Jump[spriteIndex];
			}
			////////////////////// FALL //////////////////////
			else
			{	currentSprite = Emulator.Fall[spriteIndex];
			}
		}
		
		////////////////////// WALL //////////////////////
		if(contactThetaXY[0] != Physics.Inactive && contactThetaXY[1] == Physics.Inactive)
		{	}
	
	
		
		////////////////////// RETURN SPRITE //////////////////////
		return currentSprite;
	}	
}