package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int 		None=0, 	Min=1, 		Low=2,		Med=20, 	High=60, 	Max=200;
	static int[]	////////////{ SMALL,   MEDIUM,  LARGE}///////////////
					Gaps =		{  High,    None,    None},
					Walls =		{  High,    High,    None},
					Drops =		{  High,    High,    None},
					Widths =	{  High,    High,    None},
					Inclines =	{  High,    High,    None},
					Declines =	{  High,    High,    None}, 
					uFrictionX=	{  None,    None,    High}, 
					uFrictionY=	{  None,    None,    High}; 
					
	static int 		xShiftMax = (int)(Emulator.ResolutionXY[0]*0.75),
					xShiftMin = Emulator.Stand[0].getWidth(),
					yShiftMax = Emulator.ResolutionXY[1],
					yShiftMin = Emulator.Stand[0].getHeight()/2,
					WidthMax = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax, 
					WidthMin = Emulator.Stand[0].getWidth(),		
					AngleMax = 40,
					AngleMin = 1,
					uFrictionMax = 100,
					uFrictionMin = 10;
	
	static double	RatioSum = 0; 
	static Random 	Rand = new Random();
	
		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double[]	 ScrollSpeedXY = {0, 0};
	
		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		 index;
	private double[] locationXY = new double[2],
					 dimensionXY = new double[2],
					 uFrictionXY = new double[2];
	private boolean  onScreen =  false;
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] locationXY, double[] dimensionXY, double[] uFrictionXY)
	{	this.index = index;
		this.locationXY = locationXY;
		this.dimensionXY = dimensionXY;
		this.uFrictionXY = uFrictionXY;
	}
	public Platform (int index)
	{	this.index = index;
		randomize();
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	///////////////// LOCATION UPDATE /////////////////
		locationXY[0] = locationXY[0]+ScrollSpeedXY[0];
		locationXY[1] = locationXY[1]+ScrollSpeedXY[1];
//System.out.println("p"+index+" pX="+locationXY[0]+" sS="+ScrollSpeedXY[0]);   		
//System.out.println("p"+index+" pY="+locationXY[1]+" sS="+ScrollSpeedXY[1]);   		
		
		///////////////// ON SCREEN CHECK /////////////////
		onScreen = false;
		if(locationXY[0]+dimensionXY[0] > 0 && locationXY[0] < Emulator.ResolutionXY[0])
		{	if(locationXY[1]+dimensionXY[1] < Emulator.ResolutionXY[1] || locationXY[1] < Emulator.ResolutionXY[1])
			{	onScreen = true;
			}
		}	
	}	
	
		///////////////////// WORLD GENERATOR //////////////////////
	//////////////////////
	public void randomize()
	{	///////////////// PREVIOUS PLATFORM XY /////////////////
			double 	previousXEnd = Emulator.Platform[index-1].LocationXY()[0]+Emulator.Platform[index-1].dimensionXY[0],
	   				previousYEnd = Emulator.Platform[index-1].LocationXY()[1]+Emulator.Platform[index-1].dimensionXY[1];		
//System.out.println("p"+index+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
				
			///////////////// X SHIFT /////////////////
			RatioSum = 0;
			locationXY[0] = (int)(previousXEnd+getOffSet(Gaps, xShiftMax, xShiftMin, -1, "Gap"));
			
			///////////////// Y SHIFT /////////////////
			RatioSum = 0;
			locationXY[1] = previousYEnd+getOffSet(Drops, yShiftMax, yShiftMin, -getOffSet(Walls, yShiftMax, yShiftMin, 0, "Wall"), "Drop");
			
			///////////////// WIDTH /////////////////
			RatioSum = 0;
			dimensionXY[0] = getOffSet(Widths, WidthMax, WidthMin, WidthMax, "Width");
			
			///////////////// GRADIENT /////////////////
			RatioSum = 0;
			dimensionXY[1] = (int)(dimensionXY[0]*Math.tan(Math.toRadians(getOffSet(Declines, AngleMax, AngleMin, -getOffSet(Inclines, AngleMax, AngleMin, 0, "Incline"), "Decline"))));
			
			///////////////// uFRICTION /////////////////
			RatioSum = 0;
			uFrictionXY[0] = getOffSet(uFrictionX, uFrictionMax, uFrictionMin, 100, "uFrictionX")/100.00;
			RatioSum = 0;
			uFrictionXY[1] = getOffSet(uFrictionY, uFrictionMax, uFrictionMin, 100, "uFrictionY")/100.00;
	}
	
		///////////////////// OFFSETS //////////////////////
	//////////////////////
	public double getOffSet(int[] array, int valueMax, int valueMin, double offset, String type)
	{	double 	ratioScaling = 1;
		for(int i = 0; i < array.length; i++)
		{	RatioSum += array[i];
			if(RatioSum > Max)
			{ 	ratioScaling = Max/RatioSum;
			}
			double rand = Rand.nextInt(Max)+1;
			if(rand <= array[i]*ratioScaling)
			{	int rangeStart = valueMax/array.length*i,
					variant = Rand.nextInt(valueMax/array.length-valueMin/(i+1))+valueMin/(i+1);
				offset = rangeStart+variant;
//System.out.println("p"+index+" "+type+"="+offset+" rangeStart="+rangeStart);   		
			}
		}
		return offset;
	}	

		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] LocationXY() 
	{	return locationXY;
	}
	public double[] DimensionXY() 
	{	return dimensionXY;
	}
	public double[] uFrictionXY() 
	{	return uFrictionXY;
	}
	public boolean OnScreen() 
	{	return onScreen;
	}
}