package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int[]	////////////{    OVERLAPS     ||      GAPS     }///////////////
					XShiftRates={0,  0,  0,  0,      0,  0,  0,  0},
					////////////{     WALLS	      ||      DROPS    }///////////////
					YShiftRates={0,  0,  10,  0,       0,  10,  0,  0},
					////////////{     SMALL,    MEDIUM,   LARGE    }///////////////
					WidthRates ={       10,        0,        0	   }, 
					////////////{    DOWNWARD     ||      UPWARD   }///////////////
					SlopeRates ={ 0,  0,  0,  0,	  0,  0,  0,  0}; 
	
		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static int 		RateCap = 10, 
					XShiftMax = Emulator.ResolutionXY[0],
					XShiftMin = Emulator.Stand[0].getWidth(),
					YShiftMax = (int)(Emulator.PlatformBase[0].getHeight()*1.5),
					YShiftMin = Emulator.Stand[0].getHeight()/2,
					WidthMax = Emulator.PlatformBase[0].getWidth()*2, 
					WidthMin = Emulator.Stand[0].getWidth(),
					SlopeMax = 75, 
					EndPlatform = 0;
	static double[]	ScrollSpeedXY = {0, 0};
	static Random 	Rand = new Random();
	
		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		index,			width;
	private double	slope, 			friction;
	private boolean onScreen =  true;
	private double[]platformXY = new double[2];	
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] platformXY)
	{	this.index = index;
		this.platformXY = platformXY;
		width = WidthMax;
		slope = 0;
		friction = Physics.DefaultFriction;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	
		///////////////// PLATFORM JUMP /////////////////
		if (platformXY[0]+width <= -Emulator.ResolutionXY[0])
		{	///////////////// PREVIOUS AND NEXT PLATFORMS /////////////////
			int	previous = index - 1;
			if(previous < 0)
			{	previous = Emulator.Platform.length-1;
			}
			int	next = index + 1;
			if(next > Emulator.Platform.length-1)
			{	next = 0;
			}	
			double previousXEnd = Emulator.Platform[previous].getPlatformXY()[0]+Emulator.Platform[previous].getWidth(),
				   previousYEnd = Emulator.Platform[previous].getPlatformXY()[1]+Emulator.Platform[previous].getWidth()*Emulator.Platform[previous].getSlope();
//System.out.println("	"+index+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
				
			///////////////// X SHIFT /////////////////
			platformXY[0] = previousXEnd-(Character.BaseStats[2]+Character.StatLimits[2]);
			double ratioSum = 0;
			for(int i = 0; i < XShiftRates.length; i++)
			{	ratioSum += XShiftRates[i];
				if(Rand.nextInt(RateCap) + 1 <= Math.pow(XShiftRates[i],2)/ratioSum)
				{	double incrament = i - (XShiftRates.length-1)/2.0,
						   incramentRange = XShiftMax/(XShiftRates.length/2),
						   rangeVariance = Math.signum(incrament)*(Rand.nextInt((int)incramentRange-XShiftMin)+XShiftMin);
					platformXY[0] = previousXEnd + incramentRange*(int)incrament + rangeVariance;
//System.out.println(index+" i="+incrament+" iR="+incramentRange+" rV="+rangeVariance);   		
//System.out.println(index+" xShift="+(platformXY[0]-previousXEnd));   		
				}
			}
			
			///////////////// Y SHIFT /////////////////
			platformXY[1] = previousYEnd;
			ratioSum = 0;
			for(int i = 0; i < YShiftRates.length; i++)
			{	ratioSum += YShiftRates[i];
				if(Rand.nextInt(RateCap) + 1 <= Math.pow(YShiftRates[i],2)/ratioSum)
				{	double incrament = i - (YShiftRates.length-1)/2.0,
						   incramentRange = YShiftMax/(YShiftRates.length/2),
						   rangeVariance = Math.signum(incrament)*(Rand.nextInt((int)incramentRange-YShiftMin)+YShiftMin);
					platformXY[1] = previousYEnd + incramentRange*(int)incrament + rangeVariance;
//System.out.println(index+" i="+incrament+" iR="+incramentRange+" rV="+rangeVariance);   		
//System.out.println(index+" yShift="+(platformXY[1]-previousYEnd));   		
				}
			}
			
			///////////////// PLATFORM WIDTH /////////////////
			width = WidthMax;    		
			ratioSum = 0;
			for(int i = 0; i < WidthRates.length; i++)
			{	ratioSum += WidthRates[i];
				if(Rand.nextInt(RateCap) + 1 <= Math.pow(WidthRates[i],2)/ratioSum)
				{	double 	incramentRange = WidthMax/(WidthRates.length),
						   	rangeVariance = Rand.nextInt((int)incramentRange-WidthMin)+WidthMin,
						   	worldWidth = 0;
					width = (int)(incramentRange*i + rangeVariance);
//System.out.println(index+" wMax="+WidthMax+" i="+i+" iR="+incramentRange+" wMin="+WidthMin+" rV="+rangeVariance);   		
					///////////////// WORLD WIDTH CHECK /////////////////
					for(int J = 0; J < Emulator.Platform.length; J++)
					{	worldWidth += Emulator.Platform[J].getWidth();
					}
					if( worldWidth <= XShiftMax*2 + WidthMax)		
					{	width = WidthMax;
					}
//System.out.println(index+" width="+width+" worldWidth="+worldWidth);   		
				}
			}
			///////////////// PLATFORM SLOPE /////////////////
			slope = 0;
			ratioSum = 0;
			for(int i = 0; i < SlopeRates.length; i++)
			{	ratioSum += SlopeRates[i];
				if(Rand.nextInt(RateCap) + 1 <= Math.pow(SlopeRates[i],2)/ratioSum)
				{	int rateRange = SlopeMax/(SlopeRates.length/2),
						rangeStart = rateRange*(i-SlopeRates.length/2);
					slope = rangeStart+Rand.nextInt(rateRange);
				}
			}

			///////////////// LAST PLATFORM /////////////////
			EndPlatform += 1;
			if(EndPlatform >= Emulator.Platform.length)
			{	EndPlatform = 0;
			}
		}
		
		///////////////// LOCATION UPDATE /////////////////
		platformXY[0] += ScrollSpeedXY[0];
		platformXY[1] += ScrollSpeedXY[1];
		
		///////////////// ON SCREEN UPDATE /////////////////
		onScreen = false;
		///////////////// X CHECK /////////////////
		if(platformXY[0]+width > 0 && platformXY[0] < Emulator.ResolutionXY[0])
		{	///////////////// Y CHECK /////////////////
			if(platformXY[1]+slope*width < Emulator.ResolutionXY[1] || platformXY[1] < Emulator.ResolutionXY[1])
			{	onScreen = true;
			}
		}	
	}		
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] getPlatformXY() 
	{	return platformXY;
	}
	public double getWidth() 
	{	return width;
	}
	public double getSlope() 
	{	return slope;
	}
	public double getFriction() 
	{	return friction;
	}
	public boolean getOnScreen() 
	{	return onScreen;
	}
}