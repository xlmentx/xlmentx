package Engine;
import java.awt.Image;
public class Player 	
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int			index,				airAllow;		
	private double		groundAccel,		airAccel,			
						topSpeed,		
						jump,				doubleJump;
	private int[]		inputXxYy = new int [4];	
	private double[]	centerXY = new double[2],
						velocityXY = new double[2],
						proximityValue = new double[5];
	
		//////////////////////CONSTRUCTOR//////////////////////
	//////////////////////
	public Player (int index, double[] centerXY)
	{	this.index = index;
		this.centerXY = centerXY;
		double[] stats = Character.updateStats(index, 0, 0);
		groundAccel = stats[0];
		airAccel = stats[1];	
		topSpeed = stats[2];		
		jump = stats[3];
		doubleJump = stats[4];
		proximityValue = Physics.scanProximity(centerXY, velocityXY);
	}

		////////////////////// PLAYER UPDATE //////////////////////
	//////////////////////
	public void update( int[] inputXxYy) 
	{	this.inputXxYy = inputXxYy;
//System.out.println("   ");
		///////////////////// PROXIMITY CHECK //////////////////////
			//////////////////{ CONTACT X, CONTACT Y, THETA X, THETA Y, FRICTION }///////////////
			proximityValue = Physics.scanProximity(centerXY, velocityXY);
	
		////////////////////// X INPUT //////////////////////
		if(Math.abs(inputXxYy[0]) == 1)
		{	////////////////////// ACCELERATION //////////////////////
			if(Math.abs(velocityXY[0]) < topSpeed)
			{	////////////////////// SURFACE CONTACT //////////////////////
				if(proximityValue[3] != 180)
				{	velocityXY[0] += groundAccel*inputXxYy[0]*Math.cos(Math.toRadians(proximityValue[3])); 	 
					velocityXY[1] -= groundAccel*inputXxYy[0]*Math.sin(Math.toRadians(proximityValue[3])); 	 
//System.out.println("xI.1 a="+groundAccel*inputXxYy[0]+" xa="+groundAccel*inputXxYy[0]*Math.cos(Math.toRadians(proximityValue[3]))+" ya="+-groundAccel*inputXxYy[0]*Math.sin(Math.toRadians(proximityValue[3])));
					airAllow = 0;
				}
				////////////////////// IN AIR //////////////////////
				else
				{	////////////////////// ACCELERATION //////////////////////
					if( airAllow > 0 || inputXxYy[0]*velocityXY[0] <= 0)
					{	velocityXY[0] += airAccel*inputXxYy[0]; 	 
//System.out.println("xI.2 xa="+airAccel*inputXxYy[0]+" xv="+velocityXY[0]+" yv="+velocityXY[1]);
					}
				}	
			}	
		}
	
		////////////////////// Y INPUT //////////////////////
		if(inputXxYy[2] == 1 && inputXxYy[3] == 0) 
		{	////////////////////// KEY PRESSED //////////////////////
			inputXxYy[3] = 1;
			////////////////////// SURFACE CONTACT //////////////////////
			if(Math.abs(proximityValue[2]) == 90 || proximityValue[3] != 180)
			{	velocityXY[1] = jump;	
				airAllow = 1;
				////////////////////// WALL //////////////////////
				if(Math.abs(proximityValue[2]) == 90 && proximityValue[3] == 180)
				{	velocityXY[0] += jump*Math.sin(Math.toRadians(proximityValue[2]))/2;	
//System.out.println("y.1  vX="+velocityXY[0]+" vY="+velocityXY[1]+" yI="+jump);						
				}	
				////////////////////// GROUND //////////////////////
				if(proximityValue[3] != 180)
				{	velocityXY[0] += jump*Math.sin(Math.toRadians(proximityValue[3]))/2;	
//System.out.println("y.2  vX="+velocityXY[0]+" vY="+velocityXY[1]+" yI="+jump);						
				}
			}
			////////////////////// AIR //////////////////////
			else
			{	if(airAllow == 1)
				{	velocityXY[1] = (velocityXY[1]+doubleJump>=jump && velocityXY[1]<0)? 
						velocityXY[1] + doubleJump: doubleJump;
					airAllow = 2;					
//System.out.println("y.3  ys="+velocityXY[1]+" cy="+centerXY[1]+" yI="+inputXxYy[2]);						
				}	
			}
		}
	
		////////////////////// PHYSICS //////////////////////
		double[] vectorUpdate = Physics.applyForces(centerXY, velocityXY);
		velocityXY = new double[] {vectorUpdate[0], vectorUpdate[1]};	
		centerXY = new double[] {vectorUpdate[2], vectorUpdate[3]};	
		
		////////////////////// X LOCATION UPDATE//////////////////////
		if(centerXY[0]+velocityXY[0] <= Emulator.XLimitLR[1] && centerXY[0]+velocityXY[0] >= Emulator.XLimitLR[0])
		{	centerXY[0] += velocityXY[0];
			Platform.ScrollSpeedXY[0] = 0;
//System.out.println("	uX.1 v="+velocityXY[0]+" x="+centerXY[0]);	
		}
		
		////////////////////// HORRIZONTAL SCROLLING //////////////////////
		else
		{	////////////////////// RIGHTWARD SCROLLING //////////////////////
			if(centerXY[0]+velocityXY[0] > Emulator.XLimitLR[1])
			{	Platform.ScrollSpeedXY[0] = -velocityXY[0]-Math.abs(Emulator.XLimitLR[1]-centerXY[0]);
				centerXY[0] = Emulator.XLimitLR[1];	
//System.out.println("	uX.2 vX="+velocityXY[0]+" cX="+centerXY[0]+" lR="+Emulator.XLimitLR[1]+" diff="+Math.abs(Emulator.XLimitLR[1]-centerXY[0]));	
			}
			////////////////////// LEFTWARD SCROLLING //////////////////////
			if(centerXY[0]+velocityXY[0] < Emulator.XLimitLR[0])
			{	Platform.ScrollSpeedXY[0] = -velocityXY[0]+Math.abs(Emulator.XLimitLR[0]-centerXY[0]);
				centerXY[0] = Emulator.XLimitLR[0];				
//System.out.println("	uX.3 vX="+velocityXY[0]+" cX="+centerXY[0]+" diff="+Math.abs(Emulator.XLimitLR[0]-centerXY[0]));	
			}
		}
		
		////////////////////// Y LOCATION UPDATE//////////////////////
		if(centerXY[1]+velocityXY[1] <= Emulator.YLimitUD[1] && centerXY[1]+velocityXY[1] >= Emulator.YLimitUD[0])
		{	centerXY[1] += velocityXY[1];
			Platform.ScrollSpeedXY[1] = 0;
//System.out.println("	uY.1 v="+velocityXY[1]+" y="+centerXY[1]);	
		}

		////////////////////// VERTICAL SCROLLING //////////////////////
		else
		{	////////////////////// UPWARD SCROLLING //////////////////////
			if(centerXY[1]+velocityXY[1] < Emulator.YLimitUD[0])
			{	Platform.ScrollSpeedXY[1] = -velocityXY[1]+Math.abs(Emulator.YLimitUD[0]-centerXY[1]);
				centerXY[1] = Emulator.YLimitUD[0];	
//System.out.println("	uY.2 vY="+velocityXY[1]+" cY="+centerXY[1]+" diff="+Math.abs(Emulator.YLimitUD[0]-centerXY[1]));	
			}
			////////////////////// DOWNWARD SCROLLING //////////////////////
			if(centerXY[1]+velocityXY[1] > Emulator.YLimitUD[1])
			{	Platform.ScrollSpeedXY[1] = -velocityXY[1]-Math.abs(Emulator.YLimitUD[1]-centerXY[1]);
				centerXY[1] = Emulator.YLimitUD[1];				
//System.out.println("	uY.3 vY="+velocityXY[1]+" cY="+centerXY[1]+" diff="+Math.abs(Emulator.YLimitUD[1]-centerXY[1]));	
			}
		}	
//System.out.println("  psX="+Platform.ScrollSpeedXY[0]+"    psY="+Platform.ScrollSpeedXY[1]);	
	}
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public int[] getInputXxYy() 
	{	return inputXxYy;
	}
	public double[] getCenterXY() 
	{	return centerXY;
	}
	public double[] getVelocityXY() 
	{	return velocityXY;
	}
	public double[] getProximityValue() 
	{	return proximityValue;
	}
}	