package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	DefaultGravity = 0.5,
					DefaultFriction = DefaultGravity*0.5;
	
		///////////////////// PROXIMITY SCAN //////////////////////
	//////////////////////
	public static double[] scanProximity(double[] centerXY, double[] velocityXY)
	{	////////////////////// DEFAULT PROXIMITY VALUES //////////////////////
			//////////////////{ CONTACT X, CONTACT Y, THETA X, THETA Y, FRICTION }///////////////
			double[] proximityValues ={ Emulator.ResolutionXY[0], Emulator.ResolutionXY[1], 180, 180, 0};
		
		////////////////////// PLATFORM SCANS //////////////////////
		for(int i = 0; i < Emulator.Platform.length; i++)
		{	double[] platformXY = Emulator.Platform[i].getPlatformXY();
			double	 width = Emulator.Platform[i].getWidth(),
					 slope = Emulator.Platform[i].getSlope(),
					 friction = Emulator.Platform[i].getFriction();
			
			////////////////////// RIGHTWARD COLLISIONS //////////////////////
			if(centerXY[1] > platformXY[1])
			{	double contact = platformXY[0];
				if(centerXY[0] + velocityXY[0] >= contact && centerXY[0] <= contact)
				{	////////////////////// CONTACT //////////////////////
					proximityValues[0] = contact;
					////////////////////// THETA //////////////////////
					proximityValues[2] = 90;
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
//System.out.println("RCollision");
				}
			}
			
			////////////////////// LEFTWARD COLLISIONS //////////////////////
			if(centerXY[1] > platformXY[1]+slope*width)
			{	double contact = platformXY[0] + width;
				if(centerXY[0] + velocityXY[0] <= contact && centerXY[0] >= contact)
				{	////////////////////// CONTACT //////////////////////
					proximityValues[0] = contact;
					////////////////////// THETA //////////////////////
					proximityValues[2] = -90;
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
//System.out.println("LCollision");
				}
			}
			
			////////////////////// DOWNWARD COLLISIONS //////////////////////
			if(centerXY[0] > platformXY[0] && centerXY[0] < platformXY[0]+width)
			{	double 	contact = slope*(centerXY[0]-platformXY[0])+platformXY[1];
				if(centerXY[1] + velocityXY[1] >= contact)
				{	////////////////////// CONTACT //////////////////////
					proximityValues[1] = contact;
					////////////////////// THETA //////////////////////
					proximityValues[3] =  -Math.toDegrees(Math.atan(slope));
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
//System.out.println("DCollision @ y="+contact);
				}
			}
		}

		////////////////////// LEFTWARD SCROLL BOUNDARY //////////////////////
		if(centerXY[0] + velocityXY[0] <= Emulator.Platform[Platform.EndPlatform].getPlatformXY()[0]+Emulator.XLimitLR[0])
		{	////////////////////// CONTACT //////////////////////
			proximityValues[0] = Emulator.Platform[Platform.EndPlatform].getPlatformXY()[0]+Emulator.XLimitLR[0];
			////////////////////// THETA //////////////////////
			proximityValues[2] = -89;
		}

		////////////////////// RETURN PROXIMITY VALUES //////////////////////
		return proximityValues;
	}
	
		///////////////////// FORCES //////////////////////
	//////////////////////
	public static double[] applyForces(double[] centerXY, double[] velocityXY)
	{	
//System.out.println("    ");		
//System.out.println("Forces     Vx="+velocityXY[0]+"	Vy="+velocityXY[1]+"	Vm="+Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)));
		////////////////////// GRAVITY //////////////////////
		double gravity = DefaultGravity;
			   velocityXY[1] += gravity;
//System.out.println("  Gravity  Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
		
		////////////////////// PROXIMITY CHECK //////////////////////
			//////////////////{ CONTACT X, CONTACT Y, THETA X, THETA Y, FRICTION } ///////////////
			double[] proximityValue = Physics.scanProximity(centerXY, velocityXY);
				 
		///////////////////// HORRIZONTAL AND VERTICAL COLLISIONS //////////////////////
		for(int i = 2; i <= 3; i++ )
		{	if(proximityValue[i] != 180)
			{	////////////////////// SNAP TO X CONTACT //////////////////////
				if( i == 2 )
				{	centerXY[0] = proximityValue[0];
//System.out.println("  Snap  cX="+proximityValue[0]);
				}	
				////////////////////// SNAP TO Y CONTACT //////////////////////
				if( i == 3 )
				{	centerXY[1] = proximityValue[1];
//System.out.println("  Snap  cY="+proximityValue[1]);
				}
				
				////////////////////// NORMAL FORCE //////////////////////
				double	velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)), 
						velocityTheta = -Math.atan2(velocityXY[1],velocityXY[0]),
						platformTheta = Math.toRadians(proximityValue[i]),
						normalTheta = platformTheta + Math.toRadians(90),
						Range1 = Math.toRadians(90),
						Range2 = (proximityValue[i] >= 0)?
							Math.toRadians(180): -Math.toRadians(180),		
						NormalForce = (normalTheta-velocityTheta >= Range1 && normalTheta-velocityTheta <= Range1*2 
									|| normalTheta-velocityTheta >= Range2 && normalTheta-velocityTheta <= Range2 + Range1)?
							Math.abs(velocityMagnitude*Math.cos(normalTheta-velocityTheta)): 0;
				////////////////////// APPLY NORMAL FORCE //////////////////////
//System.out.println("  vM="+velocityMagnitude+"	vT="+Math.toDegrees(velocityTheta));
//System.out.println("  nF="+NormalForce+"	nT="+Math.toDegrees(normalTheta));
				velocityXY[0] = round(velocityXY[0]+NormalForce*Math.cos(normalTheta));
				velocityXY[1] = round(velocityXY[1]-NormalForce*Math.sin(normalTheta));
//System.out.println("  Normal   Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);

				///////////////////// FRICTION //////////////////////
				velocityMagnitude = Math.sqrt(Math.pow(velocityXY[1],2)+Math.pow(velocityXY[0],2)); 
				velocityTheta = -Math.atan2(velocityXY[1],velocityXY[0]);
				double	friction = proximityValue[4],
						frictionForce = friction*Math.cos(platformTheta-velocityTheta);
				////////////////////// APPLY FRICTION //////////////////////
//System.out.println("  vM="+velocityMagnitude+"	vT="+Math.toDegrees(velocityTheta));
//System.out.println("  fF="+frictionForce+"  pT="+Math.toDegrees(platformTheta));
				velocityXY[0] = (Math.abs(velocityXY[0])-Math.abs(frictionForce*Math.cos(platformTheta)) >= 0)?
						velocityXY[0] - frictionForce*Math.cos(platformTheta): velocityXY[0] - velocityXY[0];			
				velocityXY[1] = (Math.abs(velocityXY[1])-Math.abs(frictionForce*Math.sin(platformTheta)) >= 0)?
						round(velocityXY[1]+frictionForce*Math.sin(platformTheta)): round(velocityXY[1]-velocityXY[1]);
//System.out.println("  Friction Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
			}
		}
		
		////////////////////// RETURN SUM OF FORCES AND LOCATION //////////////////////
//System.out.println("  Final    Vx="+velocityXY[0]+"	Vy="+velocityXY[1]+" Cx="+centerXY[0]+"	Cy="+centerXY[1]);
		return new double[] {velocityXY[0], velocityXY[1], centerXY[0], centerXY[1]};
	}
	
		///////////////////// ROUND VALUE //////////////////////
	//////////////////////
	public static double round(double value)
	{	double percision = 100;

		value = (int)(value*percision)/percision;
		return value;
	}	
	
}