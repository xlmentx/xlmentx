package Engine;
import java.awt.Image;
public class Sprites 
{	////////////////////// IMAGE //////////////////////
	Image[] currentSprite = new Image[Emulator.getPlayer().length];
			
			
	public void upDate(int playerNum, int sprite, double xSpeed, double ySpeed)
	{	////////////////////// SPRITES //////////////////////
		switch(sprite)
		{	case  0: 	currentSprite[playerNum] = Emulator.getNone(); 	
/*System.out.println("image.  None");*/											break;
			////////////////////// GROUND //////////////////////
			case -1: 	currentSprite[playerNum] = Emulator.getStandLeft();		break;
			case  1: 	currentSprite[playerNum] = Emulator.getStandRight(); 	
/*System.out.println("image.  Stand");*/										break;
			case -2: 	currentSprite[playerNum] = Emulator.getRunLeft();		break;
			case  2:	currentSprite[playerNum] = Emulator.getRunRight(); 	
/*System.out.println("image.  Run");*/											break;
			case -3:	currentSprite[playerNum] = Emulator.getPushLeft();		break;
			case  3:	currentSprite[playerNum] = Emulator.getPushRight(); 	
/*System.out.println("image.  Push");*/											break;
			case -4:	currentSprite[playerNum] = Emulator.getSlideLeft(); 	break;
			case  4:	currentSprite[playerNum] = Emulator.getSlideRight(); 
/*System.out.println("image.  Slide");*/										break;
		}
		
		////////////////////// AIR //////////////////////
		if(ySpeed < 0)
		{	switch(sprite)
			{	case -10:	currentSprite[playerNum] = Emulator.getJumpLeft();		break;
				case  10:	currentSprite[playerNum] = Emulator.getJumpRight(); 
/*System.out.println("image.  Jump");*/												break;  	
				case -12: currentSprite[playerNum] = Emulator.getWallLeapLeft();	break;
				case  12: currentSprite[playerNum] = Emulator.getWallLeapRight(); 
/*System.out.println("image.  WallLeap");*/										break;
				case -22: currentSprite[playerNum] = Emulator.getClimbLeft(); 		break;
				case  22: currentSprite[playerNum] = Emulator.getClimbRight();
/*System.out.println("image.  Climb");*/										break;
				case -23: currentSprite[playerNum] = Emulator.getClimbJumpLeft();	break;
				case  23: currentSprite[playerNum] = Emulator.getClimbJumpRight(); 
/*System.out.println("image.  ClimbJump");*/									break;
			}
		}
		else
		{	switch(sprite)
			{	case -10:	currentSprite[playerNum] = Emulator.getFallLeft();		break;
				case  10:	currentSprite[playerNum] = Emulator.getFallRight();
/*System.out.println("image.  Fall");*/												break;  	
				case -21: currentSprite[playerNum] = Emulator.getWallSlideLeft(); 	break;
				case  21: currentSprite[playerNum] = Emulator.getWallSlideRight(); 	
/*System.out.println("image.  WallSlide");*/									break;
			}
		}
	}
	//////////////////////SETTERS AND GETTERS//////////////////////
	public Image[] getCurrentSprite() 
	{	return currentSprite;
	}
}