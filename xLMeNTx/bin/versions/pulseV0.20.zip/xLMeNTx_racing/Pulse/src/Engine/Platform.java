package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{	////////////////////// ATRIBUTES //////////////////////
	private int				platformNumber;			
	private double			platformXlocation,		platformYlocation,
							hight,					width = Emulator.getResolutionX(),
							platformSlope,			incline = 1,
							rightGradient= 1,		leftGradient= 1,
							
							friction = 0.25,	
							
							xShift = 0,				yShift = 0, 			
							
	//////////////////////GAME PLAY//////////////////////
							widthMin= Emulator.getLeftScrollingValue()+50,	
							maxAngle=75;	
							
							/*FIRST HALF OF EACH ARRAY GENERATES GAPS/WALLS/DOWNWARD_SLOPES *respectively
						   	SECOND HALF OF EACH ARRAY GENERATES OVERLAPS/DROPS/UPWARD_SLOPES *respectively
						   	THE LENGTH OF THE ARRAYS DETERMINS PERSCISION OF EACH MAX_RANGE
						   	THE VALUE DETERMINES THE RATE AT WHICH THE PROPERTIES WILL APPEAR
							EX.
							array = {mWall%,LWall%,mDrop%,LDrop%}
							vs
							array = {sWall%,mWall%,LWall%,xLWall%,sDrop%,mDrop%,LDrop%,xLDrop%}
						    */
							/////////////////{   GAPS  <--|--> OVERLAPS}/////////////////
	private static int[]	xShiftRates =    {0,0,0,0,/*     */0,0,0,0},
							/////////////////{  WALLS  <--|-->  DROPS }/////////////////
							yShiftRates =    {0,0,0,0,/*     */0,0,0,0},
							/////////////////{DOWNWARD <--|--> UPWARD }/////////////////
							slopeRates =     {0,0,0,0,/*     */0,100,0,0}; 
	
	Random 					generator = new Random();
	
	///////////////// SPRITES /////////////////
	private Image 			baseSprite= Emulator.getLevel1_Base(),
							slopeSprite = Emulator.getLevel1_Slope();
	private double			slopeYOffset,			baseYOffset,
							slopeXOffset;
	private boolean matchOver;

	/////////////////CONSTRUCTOR/////////////////	
	public Platform (int x, int y)
	{	platformXlocation = x;
		platformYlocation = y;
	}
	/////////////////PLATFORM UPDATE/////////////////
	public void update() 
	{	/////////////////NEXT & PREVIOUS PLATFORM/////////////////
		double 	maxWidth = 1920,/*1080p Images*/ maxHight=1080 /*1080p Images*/; 
		int		previousPlatform = platformNumber-1,	nextPlatform = platformNumber+1;
		if(platformNumber+1 > Emulator.getPlatform().length-1)
		{	nextPlatform = 0;
		}
		if(platformNumber-1 < 0)
		{	previousPlatform = Emulator.getPlatform().length-1;
		}
			
		/////////////////PLATFORM JUMP & RANDOMIZATION/////////////////
		if (platformXlocation+maxWidth+Emulator.getPlatform()[nextPlatform].getXShift() < 0 && Emulator.getMatchOver() < 4)
		{	double arraySum=0,     oldSum=0,     newSum=0,     worldWidth=0,
			xShiftMinimum= Emulator.getCharacter().getRunner()[0],	yShiftMin=Emulator.getCharacter().getRunner()[1],
			num = generator.nextInt(100),		overlapMax	=	Emulator.getPlatform()[previousPlatform].getWidth();
			
			/////////////////WORLD WIDTH/////////////////
			for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	worldWidth += Emulator.getPlatform()[i].getWidth()+Emulator.getPlatform()[i].getXShift(); 
			}
			worldWidth -= Emulator.getPlatform()[platformNumber].getWidth()+Emulator.getPlatform()[platformNumber].getXShift(); 
			
			/////////////////X SHIFT/////////////////
			xShift=0;
				
			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < xShiftRates.length; i++)
			{	arraySum += xShiftRates[i];
			}
			
			/////////////////SEARCH/////////////////
			for(int i = 0; i < xShiftRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+xShiftRates[i];
				}
				else
				{	newSum = oldSum+100*(xShiftRates[i]/arraySum);
				}
//System.out.println("xs. Checking xShiftType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
				
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////GAPS/////////////////
					if( i >= 0 && i < xShiftRates.length/2.0)
					{	xShift = xShiftMinimum+generator.nextInt((int)(Emulator.getResolutionX()/(xShiftRates.length/2.0)-xShiftMinimum))+Emulator.getResolutionX()/(xShiftRates.length/2.0)*i;	
//System.out.println("GAP="+xShift);						
					}
					/////////////////OVERLAPS/////////////////
					if( i >= xShiftRates.length/2.0 && i < xShiftRates.length)
					{	xShift = -generator.nextInt((int)(overlapMax/(xShiftRates.length/2.0)-xShiftMinimum))-(overlapMax/(xShiftRates.length/2.0)*(i-xShiftRates.length/2.0));
//System.out.println("OVERLAP="+xShift);											
					}
					i = xShiftRates.length;
				}	
				
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < xShiftRates.length)
				{	oldSum += xShiftRates[i];
				}
				if( arraySum >= 100 && i < xShiftRates.length)
				{	oldSum += 100*(xShiftRates[i]/(double)arraySum);
				}		
			}
					
			/////////////////Y SHIFT/////////////////
			yShift=0;
			arraySum=0;     oldSum=0;     newSum=0;     num = generator.nextInt(100);

			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < yShiftRates.length; i++)
			{	arraySum += yShiftRates[i];
			}
		
			/////////////////SEARCH/////////////////
			for(int i = 0; i < yShiftRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+yShiftRates[i];
				}
				else
				{	newSum = oldSum+100*(yShiftRates[i]/arraySum);
				}
//System.out.println("xs. Checking yShiftType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
			
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////WALLS/////////////////
					if( i >= 0 && i < yShiftRates.length/2.0)
					{	yShift = -yShiftMin-generator.nextInt((int)(maxHight/(yShiftRates.length/2.0)-yShiftMin))-maxHight/(yShiftRates.length/2.0)*i;	
//System.out.println("WALL="+yShift);						
					}
					/////////////////DROPS/////////////////
					if( i >= yShiftRates.length/2.0 && i < yShiftRates.length)
					{	yShift = generator.nextInt((int)(maxHight/(yShiftRates.length/2.0)))+maxHight/(yShiftRates.length/2.0)*(i-yShiftRates.length/2.0);	
//System.out.println("DROP="+yShift);						
					}
					i = yShiftRates.length;
				}	
			
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < yShiftRates.length)
				{	oldSum += yShiftRates[i];
				}
				if( arraySum >= 100 && i < yShiftRates.length)
				{	oldSum += 100*(yShiftRates[i]/(double)arraySum);
				}		
			}

			/////////////////POSITION UPDATE/////////////////	
			platformXlocation = Emulator.getPlatform()[previousPlatform].getPlatformXlocation()+Emulator.getPlatform()[previousPlatform].getWidth()+xShift;
			platformYlocation = Emulator.getPlatform()[previousPlatform].getPlatformSlope()*Emulator.getPlatform()[previousPlatform].getWidth()+Emulator.getPlatform()[previousPlatform].getPlatformYlocation()+yShift;
		
			/////////////////SLOPES/////////////////
			platformSlope = 0;
			arraySum=0;     oldSum=0;     newSum=0;     num = generator.nextInt(100);

			/////////////////PERCENTAGE VS ALLOCATION/////////////////
			for(int i = 0; i < slopeRates.length; i++)
			{	arraySum += slopeRates[i];
			}
	
			/////////////////SEARCH/////////////////
			for(int i = 0; i < slopeRates.length; i++)
			{	/////////////////NEW SUM/////////////////
				if( arraySum < 100)
				{	newSum = oldSum+slopeRates[i];
				}
				else
				{	newSum = oldSum+100*(slopeRates[i]/arraySum);
				}
//System.out.println("xs. Checking SlopeType "+i+" for "+num+" From "+oldSum+" to "+ newSum);
		
				/////////////////SELECT/////////////////
				if(num > oldSum && num < newSum)
				{	/////////////////DOWNWARD SLOPE/////////////////
					if( i >= 0 && i < slopeRates.length/2.0)
					{	platformSlope =	Math.tan(Math.toRadians(generator.nextInt((int)(maxAngle/(slopeRates.length/2.0)))+maxAngle/(slopeRates.length/2.0)*i));
//System.out.println("DOWNWARD="+platformSlope);
					}
					/////////////////UPWARD SLOPE/////////////////
					if( i >= slopeRates.length/2.0 && i < slopeRates.length)
					{	platformSlope =	-Math.tan(Math.toRadians(generator.nextInt((int)(maxAngle/(slopeRates.length/2.0)))+maxAngle/(slopeRates.length/2.0)*(i-slopeRates.length/2.0)));
//System.out.println("UPWARD="+platformSlope);
					}
					i = slopeRates.length;
				}	
				/////////////////OLD SUM/////////////////
				if( arraySum < 100 && i < slopeRates.length)
				{	oldSum += slopeRates[i];
				}
				if( arraySum >= 100 && i < slopeRates.length)
				{	oldSum += 100*(slopeRates[i]/(double)arraySum);
				}		
			}	
		/////////////////PLATFORM DIMENSIONS/////////////////
			/////////////////MAXIMUM SPRITE HIGHT WIDTH LIMIT/////////////////
			if(platformSlope <= maxHight/maxWidth)
			{	width = generator.nextInt((int)maxWidth)+widthMin;
				/////////////////WORLD WIDTH REQUIREMENT/////////////////
				if(width+xShift+worldWidth < Emulator.getResolutionX()+maxWidth )
				{	width = maxWidth;
//System.out.println("Slope and Width Alteration, S= "+platformSlope+" W= "+width);
				}
			}
			else
			{	width = generator.nextInt((int)(maxHight/platformSlope))+widthMin;
//System.out.println("!!!!! Width= "+width+" widthMin= "+widthMin+" pS= "+platformSlope);						
				/////////////////WORLD WIDTH REQUIREMENT/////////////////
				if(width+xShift+worldWidth < Emulator.getResolutionX()+maxWidth )
				{	width = (Emulator.getResolutionX()+maxWidth)-(xShift+worldWidth);
					platformSlope = maxHight/width;
//System.out.println("Slope and Width Alteration, S= "+platformSlope+" W= "+width);					
				}
			}	
//System.out.println(" Width= "+width+" widthMin= "+widthMin);					
			hight = Math.abs(width*platformSlope);
//System.out.println(" Hight= "+platformHight);	
			
			/////////////////GRADIENT AND FRICTION/////////////////			
			incline = width*platformSlope;
			if(incline <= 0)
			{	rightGradient=width/(hight+width);
				leftGradient=(hight+width)/width;
			}
			else
			{	rightGradient=(hight+width)/width;
				leftGradient=width/(hight+width);
			}
				
//System.out.println(" Lg= "+leftGradient+" Rg= "+rightGradient);			
			
			/////////////////SPRITE OFFSETS/////////////////			
			if(incline <= 0)
			{	////////////////UPWARD SLOPE///////////////////////
				baseYOffset = 0;
				slopeYOffset = incline;
				slopeXOffset = width;
				incline = -1;
			}
			else
			{	////////////////DOWNWARD SLOPE///////////////////////
				baseYOffset = incline;
				slopeYOffset = 0;
				slopeXOffset = 0;
				incline = 1;
			}
			////////////////SPRITE SELECTION///////////////////////
			baseSprite = Emulator.getLevel1_Base();
			slopeSprite = Emulator.getLevel1_Slope();
			
		}
	}		
	/////////////////GETTERS AND SETTERS/////////////////
	public double getPlatformXlocation() 
	{	return platformXlocation;
	}
	public void setPlatformXlocation(double centerXlocation) 
	{	this.platformXlocation = centerXlocation;
	}
	public double getPlatformYlocation() 
	{	return platformYlocation;
	}
	public void setPlatformYlocation(double platformYlocation) 
	{	this.platformYlocation = platformYlocation;
	}
	public int getPlatformNumber() 
	{	return platformNumber;	
	}
	public void setPlatformNumber(int platformNumber) 
	{	this.platformNumber = platformNumber;
	}
	public double getSlopeYOffset() 	
	{	return slopeYOffset;
	}
	public double getSlopeXOffset() 	
	{	return slopeXOffset;
	}
	public double getBaseYOffset() 	
	{	return baseYOffset;
	}
	public Image getSlopeSprite() 
	{	return slopeSprite;
	}
	public double getIncline() 
	{	return incline;
	}
	public double getFriction() 
	{	return friction;
	}
	public double getPlatformSlope() 
	{	return platformSlope;
	}
	public double getWidth() 
	{	return width;
	}
	public boolean getMatchOver() 
	{	return matchOver;
	}
	public double getXShift() 
	{	return xShift;
	}
	public double getYShift() 
	{	return yShift;
	}
	public double getHight() {
		return hight;
	}public Image getBaseSprite() {
		return baseSprite;
	}
}