package Engine;
import java.awt.Image;
public class Characters 
{	//////////////////////CHARACTER TYPES//////////////////////
		// 			 	accel,	 	topSpd,		jump 		
	double[] runner=	{0.1,		15,			-11},
		  	 ball=		{0.1,		15,			-11},
			
	//////////////////////CLASS PERKS//////////////////////
		  	 none=		{0,			0,			0},
		  	 earth=		{0,			0,			0},
			 fire=		{0,			0,			0},
		 	 water=		{0,			0,			0},
			 air=		{0,			0,			0},
			
	//////////////////////MAX XP PERKS//////////////////////
			 maxXpPerk=	{0.5,		3,			-3};
			
			
	public void update(int playerNum, int charType, int classType, int xpFile)
	{	//////////////////////SAVE FILE XP VALUES//////////////////////
		double[]	xP=	{50, 		100, 		100},
					charDefaults= {xP.length},	classPerks= {xP.length}; 
		
		//////////////////////CHARACTER TYPE DEFAULTS//////////////////////
		switch(charType)
		{	case 1:	charDefaults = runner; break;
			case 2:	charDefaults = ball; break;
		}
		
		//////////////////////CLASS TYPE PERKS//////////////////////
		switch(classType)
		{	case 0: classPerks = none;  break;
			case 1:	classPerks = earth; break;
			case 2:	classPerks = fire; 	break;
			case 3:	classPerks = water; break;
			case 4:	classPerks = air; 	break;
		}
		
		//////////////////////TRAIT SUMMATION AND ASSIGNMENT//////////////////////
		for(int i = 0; i < xP.length; i++)	
		{	double lvlPercent=0;
			if(xP[i]>100)	
			{	lvlPercent = maxXpPerk[i]+charDefaults[i]+classPerks[i];
			}	
			if(xP[i]<=100 && xP[i]>0)	
			{	lvlPercent = maxXpPerk[i]*(xP[i]/100.00)+charDefaults[i]+classPerks[i];
			}
			if(xP[i]<=0)	
			{	lvlPercent = charDefaults[i]+classPerks[i];
			}
			switch(i)
			{	case 0:	Emulator.getPlayer()[playerNum].setAcceleration	(lvlPercent);			break;
				case 1:	Emulator.getPlayer()[playerNum].setTopSpeed		(lvlPercent);			break;					
				case 2:	Emulator.getPlayer()[playerNum].setJump			(lvlPercent);
						Emulator.getPlayer()[playerNum].setDoubleJump	(lvlPercent*xP[i]/100);	break;
			}
		}			
	}
	//////////////////////SETTERS AND GETTERS//////////////////////
	public double[] getRunner() 
	{	return runner;
	}
}