package Engine;
import java.awt.Image;
public class Physics 
{	
		///////////////////// PROXIMITY SCAN //////////////////////
	//////////////////////
	public double[] scanProximity(double[] centerYX, double[] velocityYX)
	{	/////// PROXIMITYVALUES {YTHETA,XTHETA,YCONTACT,XCONTACT,FRICTION} ///////
		double[] proximityValues = {180, 180, 0, 0, 0}; 
		
		////////////////////// PLATFORM SCANS //////////////////////
		for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	double	X1 = Emulator.getPlatform()[i].getPlatformXlocation(), 
					X2 = X1 + Emulator.getPlatform()[i].getWidth(),
					Y1 = Emulator.getPlatform()[i].getPlatformYlocation(),
					Y2 = Y1 - Emulator.getPlatform()[i].getHight(),
					slope = -Emulator.getPlatform()[i].getHight()/Emulator.getPlatform()[i].getWidth(),
					ground = slope*(centerYX[1]-X1)+Y1,
					friction = Emulator.getPlatform()[i].getFriction();
			////////////////////// DOWNWARD COLLISION //////////////////////
			if(centerYX[1] > X1 && centerYX[1] < X2)
			{	if(centerYX[0] >= ground)
				{	////////////////////// THETA //////////////////////
					proximityValues[0] = -Math.toDegrees(Math.atan(slope));
					////////////////////// CONTACT //////////////////////
					proximityValues[2] = ground;
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
				}
			}
			////////////////////// RIGHTWARD COLLISION //////////////////////
			if(centerYX[0] > Y1 && velocityYX[1] > 0)
			{	if(centerYX[1] >= X1 && centerYX[1] <= X1)
				{	////////////////////// THETA //////////////////////
					proximityValues[1] = -90;
					////////////////////// CONTACT //////////////////////
					proximityValues[3] = X1;
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
				}
			}
			////////////////////// LEFTWARD COLLISION //////////////////////
			if(centerYX[0] < Y2 && velocityYX[1] < 0)
			{	if(centerYX[1] <= X2 && centerYX[1] >= X2)
				{	////////////////////// THETA //////////////////////
					proximityValues[1] = 90;
					////////////////////// CONTACT //////////////////////
					proximityValues[3] = X2;
					////////////////////// FRICTION //////////////////////
					proximityValues[4] = friction;
				}
			}
		}
		return proximityValues;
	}

	
		///////////////////// FORCES //////////////////////
	//////////////////////
	public void applyForces(int playerNum, double[] centerYX, double[] velocityYX)
	{	Physics physics = new Physics();				
System.out.println("Forces Vy="+velocityYX[0]+" Vx="+velocityYX[1]+" V="+Math.sqrt(Math.pow(velocityYX[0],2)+Math.pow(velocityYX[1],2)));
		
		//////////////////////GRAVITY //////////////////////
		double gravity = 0.5;
		velocityYX[0] += gravity;
//System.out.println("  Gravity Vy="+velocityYX[0]+" Vx="+velocityYX[1]);
		
		////////////////////// PROXIMITY CHECK //////////////////////
		double[]proximityValues = physics.scanProximity(centerYX, velocityYX);
		
		///////////////////// Y[0] AND X[1] COLLISIONS //////////////////////
		for(int i = 0; i <= 1; i++ )
		{	if(proximityValues[i] != 180)
			{	////////////////////// NORMAL FORCE //////////////////////
				double	V = Math.sqrt(Math.pow(velocityYX[0],2)+Math.pow(velocityYX[1],2)), 
						Vo = -Math.atan2(velocityYX[0],velocityYX[1]),
						Po = Math.toRadians(proximityValues[0]),
						No = Po + Math.toRadians(90),
						R1 = Math.toRadians(90),
						R2 = (proximityValues[0] >= 0)?
							Math.toRadians(180): -Math.toRadians(180),		
						NF = (No-Vo >= R1 && No-Vo <= R1*2 || No-Vo >= R2 && No-Vo <= R2 + R1)?
							Math.abs(V*Math.cos(No-Vo)): 0;
				////////////////////// APPLY NORMAL FORCE //////////////////////
				velocityYX[0] += -NF*Math.sin(No);
				velocityYX[1] += NF*Math.cos(No);
System.out.println("  Normal Vy="+velocityYX[0]+" Vx="+velocityYX[1]);
				///////////////////// FRICTION //////////////////////
				Vo = -Math.atan2(velocityYX[0],velocityYX[1]);
				double	friction = proximityValues[4],
						FF = friction*Math.cos(Po-Vo);
				////////////////////// APPLY FRICTION //////////////////////
				velocityYX[0] -= (Math.abs(velocityYX[0])-Math.abs(FF*Math.sin(Po)) >= 0)?
						FF*Math.sin(Po): velocityYX[0];
				velocityYX[1] -= (Math.abs(velocityYX[1])-Math.abs(FF*Math.cos(Po)) >= 0)?
						FF*Math.cos(Po): velocityYX[1];			
System.out.println("  Friction Vy="+velocityYX[0]+" Vx="+velocityYX[1]);
			}
		}
			
		////////////////////// APPLY SUM OF FORCES //////////////////////
		Emulator.getPlayer()[playerNum].setVelocityYX(velocityYX);
//System.out.println("  Final Vy="+velocityYX[0]+" Vx="+velocityYX[1]);
	}
	
}