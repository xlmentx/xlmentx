package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// GAME PLAY //////////////////////
	//////////////////////
	static int 		None=0, 	Low=1, 		Medium=2, 	High=3, 	Max=4;
	static int[]	///////////{ SMALL,   MEDIUM,  LARGE,   XLARGE }///////////////
					Gaps=	   {  None,    None,    None,    None  },
					Walls=	   {  None,    None,    None,    None   },
					Drops=	   {  None,    None,    None,    None  },
					Widths=	   {  None,    None,    None,    None   },
					Inclines=  {  Max,    None,    None,    None  },
					Declines=  {  Max,     None,    None,    None  }, 
					uFrictionX={  None,     None,    None,    None  }, 
					uFrictionY={  None,     None,    None,    Max  }; 
					
	static int 		xShiftMax = Emulator.ResolutionXY[0],
					xShiftMin = Emulator.Stand[0].getWidth(),
					yShiftMax = Emulator.ResolutionXY[1],
					yShiftMin = Emulator.Stand[0].getHeight()/2,
					WidthMax = Emulator.BaseSprite[0].getWidth()*Emulator.ScalingMax, 
					WidthMin = Emulator.Stand[0].getWidth(),		
					HeightMax = Emulator.BaseSprite[0].getHeight()*Emulator.ScalingMax,
					HeightMin = 10,
					uFrictionMax = 150,
					uFrictionMin = 10,
					RatioSum = 0; 

		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double[]	ScrollSpeedXY = {0, 0};
	static Random 	Rand = new Random();
	
		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		 index;
	private double[] platformXY = new double[2],
					 dimensionXY = new double[2],
					 uFrictionXY = new double[2];
	private boolean  onScreen =  true;
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (int index, double[] platformXY, double[] dimensionXY, double[] uFrictionXY)
	{	this.index = index;
		this.platformXY = platformXY;
		this.dimensionXY = dimensionXY;
		this.uFrictionXY = uFrictionXY;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{	///////////////// LOCATION UPDATE /////////////////
		platformXY[0] += ScrollSpeedXY[0];
		platformXY[1] += ScrollSpeedXY[1];
//System.out.println("p"+index+" pX="+platformXY[0]+" sS="+ScrollSpeedXY[0]);   		
//System.out.println("p"+index+" pY="+platformXY[1]+" sS="+ScrollSpeedXY[1]);   		
		
		///////////////// PLATFORM JUMP /////////////////
		if (platformXY[0]+dimensionXY[0] <= -Emulator.ResolutionXY[0])
		{	///////////////// PREVIOUS PLATFORM /////////////////
			double previousXEnd, previousYEnd;
			if(index-1 < 0)
			{	previousXEnd = Emulator.Platform[Emulator.Platform.length-1].PlatformXY()[0]+Emulator.Platform[Emulator.Platform.length-1].dimensionXY[0]-23;
			   	previousYEnd = Emulator.Platform[Emulator.Platform.length-1].PlatformXY()[1]+Emulator.Platform[Emulator.Platform.length-1].dimensionXY[1]+ScrollSpeedXY[1];
			}
			else
			{	previousXEnd = Emulator.Platform[index-1].PlatformXY()[0]+Emulator.Platform[index-1].dimensionXY[0];
		   		previousYEnd = Emulator.Platform[index-1].PlatformXY()[1]+Emulator.Platform[index-1].dimensionXY[1];		
			}
//System.out.println("p"+index+" previousXEnd="+previousXEnd+" previousYEnd="+previousYEnd);   		
				
			///////////////// X SHIFT /////////////////
			RatioSum = 0;
			platformXY[0] = previousXEnd+offSet(Gaps, xShiftMax, xShiftMin, 0);
//System.out.println("p"+index+" xShift="+(platformXY[0]-previousXEnd)+" pX="+platformXY[0]);   		
			
			///////////////// Y SHIFT /////////////////
			RatioSum = 0;
			platformXY[1] = previousYEnd+offSet(Drops, yShiftMax, yShiftMin,-offSet(Walls, yShiftMax, yShiftMin, 0));
//System.out.println("p"+index+" yShift="+(platformXY[1]-previousYEnd)+" pY="+platformXY[1]);   		
	
			///////////////// WIDTH /////////////////
			RatioSum = 0;
			dimensionXY[0] = offSet(Widths, WidthMax, WidthMin, WidthMax);
//System.out.println("p"+index+" Width="+dimensionXY[0]);   		
			
			///////////////// HEIGHT /////////////////
			RatioSum = 0;
			dimensionXY[1] = offSet(Declines, HeightMax, HeightMin,-offSet(Inclines, HeightMax, HeightMin, 0));
//System.out.println("p"+index+" Height="+dimensionXY[1]);   		
			///////////////// uFRICTION X /////////////////
			RatioSum = 0;
			uFrictionXY[0] = offSet(uFrictionX, uFrictionMax, uFrictionMin, 0)/100;
//System.out.println("p"+index+" uFrictionX="+uFrictionXY[0]);   		
			///////////////// uFRICTION Y /////////////////
			RatioSum = 0;
			uFrictionXY[1] = offSet(uFrictionY, uFrictionMax, uFrictionMin, 0)/100;
//System.out.println("p"+index+" uFrictionY="+uFrictionXY[1]);   		
		}
		
		///////////////// ON SCREEN CHECK /////////////////
		onScreen = false;
		if(platformXY[0]+dimensionXY[0] > 0 && platformXY[0] < Emulator.ResolutionXY[0])
		{	///////////////// Y CHECK /////////////////
			if(platformXY[1]+dimensionXY[1] < Emulator.ResolutionXY[1] || platformXY[1] < Emulator.ResolutionXY[1])
			{	onScreen = true;
			}
		}	
	}	
	
		///////////////////// OFFSETS //////////////////////
	//////////////////////
	public static double offSet(int[] array, int valueMax, int valueMin, double defaultOffSet)
	{	double offSet = defaultOffSet;
		for(int i = 0; i < array.length; i++)
		{	RatioSum += array[i];
			if(Rand.nextInt(Max) + 1 <= Math.pow(array[i],2)/RatioSum)
			{	int rangeStart = valueMax/array.length*i,
					variant = Rand.nextInt(valueMax/array.length-valueMin/(i+1))+valueMin/(i+1);
				offSet = rangeStart + variant;
//System.out.println("Max"+valueMax+" Min"+valueMin+" Default"+defaultOffSet);   		
//System.out.println("rangeStart "+rangeStart+" variant "+variant);   		
			}
		}
		return offSet;
	}	


		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] PlatformXY() 
	{	return platformXY;
	}
	public double[] DimensionXY() 
	{	return dimensionXY;
	}
	public double[] uFrictionXY() 
	{	return uFrictionXY;
	}
	public boolean OnScreen() 
	{	return onScreen;
	}
}