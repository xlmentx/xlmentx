package Engine;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.ImageObserver;
import java.awt.Graphics;
import java.net.URL;
import java.util.Random;

import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Emulator 
extends Applet 
implements Runnable, KeyListener
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static int 			Fps=60,					CurrentLevel= 1;
	
	static int[]        ResolutionXY = { 720*16/9, 720}, 	// 1080p=16/9
						ScrollingLimitLRUD = {ResolutionXY[0]/10, ResolutionXY[0]*3/10, ResolutionXY[1]/3, ResolutionXY[1]*2/3},
						inputXxYy = {0,0,0,0};
	
	private URL base;
	
		////////////////////// OBJECT DECLARATIONS //////////////////////
	//////////////////////
	static 	Player[]	Player = new Player[1];
	static	Character 	Character = new Character();
	static 	Platform[]	Platform = new Platform[5];
	static 	Background 	BackGround,				MidGround1,        		MidGround2,	
						ForeGround1,        	ForeGround2;
	
		////////////////////// SPRITE DECLARATIONS //////////////////////
	//////////////////////
	private Graphics second;
	static Image 		image,  				none;
	
	////////////////////// BACKGROUND SPRITES //////////////////////
	static Image[]		Background = new Image[1],
						Midground = new Image[1],
						Foreground = new Image[1],
	
	////////////////////// PLATFORM SPRITES //////////////////////
						PlatformBase = new Image[1],
						PlatformSlope = new Image[1],					
	
	//////////////////////CHARACTER SPRITES //////////////////////
						Stand = new Image[2], 				
						Run = new Image[2], 	
						Slide = new Image[2], 
						Push = new Image[2],
						Jump = new Image[2], 
						Fall = new Image[2];

		////////////////////// INITIALIZATION //////////////////////
	//////////////////////
	@Override 
	public void init()
	{	////////////////////// ROOM PROPERTIES //////////////////////
		setSize(ResolutionXY[0],ResolutionXY[1]);
		setBackground(Color.BLACK);
		setFocusable(true);
		Frame myframe = (Frame) this.getParent().getParent();
		myframe.setTitle("pulse");
		addKeyListener(this);
		try 
	   	{	base = getDocumentBase();
	   	} 
		catch (Exception e) 
		{
		}

		////////////////////// BACKGROUND SPRITE DIRECTORY //////////////////////			
	   	Foreground[0] = getImage(base, "data/level12/Backgrounds/level12foreground.png");
	   	Midground[0] = getImage(base, "data/level12/Backgrounds/level12midground.PNG");
	   	Background[0]= getImage(base, "data/level12/Backgrounds/level12background.png");

		//////////////////////PLATFORM SPRITE DIRECTIORY //////////////////////					
		PlatformBase[0]  = getImage(base, "data/platforms/base.png");
		PlatformSlope[0]  = getImage(base, "data/platforms/slope.png"); 	
			
	   	//////////////////////CHARACTER SPRITE DIRECTORY //////////////////////			
		Stand[0] = getImage(base, "data/players/standleft.png");
		Stand[1] = getImage(base, "data/players/standright.png");
		Run[0] = getImage(base, "data/players/runleft.png");
		Run[1] = getImage(base, "data/players/runright.png");
		Slide[0] = getImage(base, "data/players/slideleft.png"); 
		Slide[1] = getImage(base, "data/players/slideright.png");
		Push[0] = getImage(base, "data/players/pushLeft.png");
		Push[1] = getImage(base, "data/players/pushRight.png");
		Jump[0] = getImage(base, "data/players/jumpleft.png");
		Jump[1] = getImage(base, "data/players/jumpright.png");
		Fall[0] = getImage(base, "data/players/fallLeft.png");
		Fall[1] = getImage(base, "data/players/fallRight.png");
	}
	
		////////////////////// OBJECT START //////////////////////
	//////////////////////
	@SuppressWarnings("static-access")
	@Override
   	public void start() 
 	{	////////////////////// BACKGROUND START //////////////////////
   		BackGround = new Background(0,0);		BackGround.setBackgroundType(1);
   		MidGround1 = new Background(0,175);		MidGround1.setBackgroundType(2);	MidGround1.setBackgroundNum(1);
   		MidGround2 = new Background(-1920,175);	MidGround2.setBackgroundType(2);	MidGround2.setBackgroundNum(2);
   		ForeGround1 = new Background(0,350);	ForeGround1.setBackgroundType(3);	ForeGround1.setBackgroundNum(3);
   		ForeGround2 = new Background(-1920,350);ForeGround2.setBackgroundType(3);	ForeGround2.setBackgroundNum(4);
   		
  		////////////////////// PLATFORM START //////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	Platform[i] = new Platform(new double[]{-960+720*i, ScrollingLimitLRUD[3]}, 720, i); 
   		}
   		
   		////////////////////// PLAYER START //////////////////////
   		for(int i=0; i < Player.length; i++)
   		{	Player[i] = new Player(new double[]{ScrollingLimitLRUD[0]+50*i, ScrollingLimitLRUD[2]}, i, Character.updateStats(i, 0, 0));	
   		}

   		////////////////////// GAMETHREAD START //////////////////////
   	   	Thread nonamethread = new Thread(this);	
   		nonamethread.start();
 	}   		

   		////////////////////// RUN LOOP //////////////////////
	//////////////////////
	@Override
   	public void run()
   	{	while (true) 
   		{	////////////////////// GAME LOOP SPEED //////////////////////
   			try 
   			{	Thread.sleep(1000/(long)Fps);
   			} 
   			catch (InterruptedException e) 
   			{	e.printStackTrace();
   			}
   			
   			////////////////// BACKGROUND UPDATE //////////////////////
   			BackGround.update();
   			MidGround1.update();		MidGround2.update();
   			ForeGround1.update();		ForeGround2.update();
   			
   			////////////////////// PLATFORM UPDATE //////////////////////
   			for(int i=0; i < Platform.length; i++)
   			{	Platform[i].update();
   			}
   			
   			////////////////////// CHARACTER UPDATE //////////////////////
   			for(int i=0; i < Player.length; i++)
   			{	Player[i].update(inputXxYy);
   			}
   				
   			////////////////////// GRAPHICS UPDATE //////////////////////
   			repaint();
   		}
   	}
   	
				
   		////////////////////// PAINT //////////////////////
	//////////////////////
	@SuppressWarnings("static-access")
	@Override
   	public void paint(Graphics g) 
   	{	////////////////////// BACKGROUNDS //////////////////////
   		g.drawImage(BackGround.getCurrentBackGround(), (int)BackGround.getBackgroundXvalue(), (int)BackGround.getBackgroundYvalue(), this);
   		g.drawImage(MidGround1.getCurrentMidGround(), (int)MidGround1.getBackgroundXvalue(), (int)MidGround1.getBackgroundYvalue(), this);
   		g.drawImage(MidGround2.getCurrentMidGround(), (int)MidGround2.getBackgroundXvalue(), (int)MidGround2.getBackgroundYvalue(), this);
   		g.drawImage(ForeGround1.getCurrentForeGround(), (int)ForeGround1.getBackgroundXvalue(), (int)ForeGround1.getBackgroundYvalue(), this);
   		g.drawImage(ForeGround2.getCurrentForeGround(), (int)ForeGround2.getBackgroundXvalue(), (int)ForeGround2.getBackgroundYvalue(), this);
   		
   		////////////////////// PLATFORMS //////////////////////
   		for(int i=0; i < Platform.length; i++)
   		{	g.drawImage(Platform[i].getSlopeSprite(), (int)Platform[i].getPlatformXY()[0], (int)Platform[i].getPlatformXY()[1], (int)Platform[i].getWidth(), (int)(Platform[i].getWidth()*Platform[i].getSlope()), this);
   			g.drawImage(Platform[i].getBaseSprite(), (int)Platform[i].getPlatformXY()[0], (int)Platform[i].getPlatformXY()[1], (int)Platform[i].getWidth(), 720, this);
  //System.out.println(i+"x="+(int)Platform[i].getPointA()[0]+" y="+(int)Platform[i].getPointA()[1]);   		
   		}
   		
   		////////////////////// PLAYERS //////////////////////   	   	
   		for(int i=0; i < Player.length; i++)
   		{	g.drawImage(Character.getSprite(i), (int)Player[i].getCenterXY()[0]-50, (int)Player[i].getCenterXY()[1]-50, this);
   		}
   	}
   	
   		////////////////////// GRAPHICS UPDATE //////////////////////
	//////////////////////
	@Override
   	public void update(Graphics g) 
   	{	if (image == null) 
		{	image = createImage(this.getWidth(), this.getHeight());
			second = image.getGraphics();
		}
		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);
		g.drawImage(image, 0, 0, this);
   	}
   	
   		////////////////////// KEY PRESS //////////////////////
	//////////////////////
	@Override
   	public void keyPressed(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT:	inputXxYy[0] = -1;
   									inputXxYy[1] = -1;	break;
	   		case KeyEvent.VK_RIGHT:	inputXxYy[0] = 1;		
	   								inputXxYy[1] = 1;	break;
	   		case KeyEvent.VK_SPACE:	inputXxYy[2] = 1;	break;
	   	}
   	}
	
		////////////////////// KEY RELEASE //////////////////////
	//////////////////////
	@Override
   	public void keyReleased(KeyEvent user) 
   	{	switch (user.getKeyCode()) 
   		{	case KeyEvent.VK_LEFT: 	inputXxYy[0] = 0; 	break;
	   		case KeyEvent.VK_RIGHT:	inputXxYy[0] = 0;	break;
	   		case KeyEvent.VK_SPACE:	inputXxYy[2] = 0;
	   								inputXxYy[3] = 0;	break;
	   	}
   	}
	
   	////////////////////// GETERS AND SETTERS //////////////////////
   	public static Background BackGround() 
    {	return BackGround;
    }
    public static Background MidGround1() 
    {	return MidGround1;
    }
    public static Background MidGround2() 
    {	return MidGround2;
    }
    public static Background ForeGround1() 
    {	return ForeGround1;
    }
    public static Background ForeGround2() 
    {	return ForeGround2;
    }
    
////////////////////// NOT USED //////////////////////
   	@Override
   	public void stop(){}
   	@Override
   	public void destroy(){}
   	@Override
   	public void keyTyped(KeyEvent e){}
	
	
}