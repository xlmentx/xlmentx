package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{	
		////////////////////// GAME PLAY//////////////////////
	//////////////////////
	static int[]	////////////{  GAPS	    || OVERLAPS }///////////////
					XShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{  WALLS	||   DROPS  }///////////////
					YShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{ DOWNWARD  ||  UPWARD  }///////////////
					SlopeRates ={0,  0,  0,	   0,  0,  0}; 
	
	static Random 	Rand = new Random();

		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int		index=0;	
	
	private double	width=0,	slope=0, 	friction = Physics.DefaultFriction;
	
	private double[]platformXY = new double[2];
		
	
		////////////////////// SPRITES //////////////////////
	//////////////////////
	private Image 	baseSprite = Emulator.PlatformBase[0],
					slopeSprite = Emulator.PlatformSlope[0];
	
		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (double[] platformXY, int width, int index)
	{	this.platformXY = platformXY;
		this.width = width;
		this.index = index;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{
		///////////////// PLATFORM JUMP /////////////////
//System.out.println(index+" startX="+(int)platformXY[0]+" startY="+(int)platformXY[1]);   		
		if (platformXY[0]+width <= -Emulator.ResolutionXY[0])
		{	
			///////////////// PREVIOUS PLATFORM /////////////////
			int	previous = index-1;
			if(previous < 0)
			{	previous = Emulator.Platform.length-1;
			}
			double previousXEnd = Emulator.Platform[previous].getPlatformXY()[0]+Emulator.Platform[previous].getWidth(),
				   previousYEnd = Emulator.Platform[previous].getPlatformXY()[1]+Emulator.Platform[previous].getWidth()*Emulator.Platform[previous].getSlope();
					
			///////////////// X SHIFT /////////////////
			platformXY[0] = previousXEnd;
			int	maxRate = 10; 
			double ratioSum = 0;
			for(int i = 0; i < XShiftRates.length; i++)
			{	ratioSum += XShiftRates[i];
				if(Rand.nextInt(maxRate) + 1 <= Math.pow(XShiftRates[i],2)/ratioSum)
				{	int rangeValues = Emulator.ResolutionXY[0]/(XShiftRates.length/2),
						rangeStart = rangeValues*(i-XShiftRates.length/2);
					platformXY[0] = previousXEnd+rangeStart+Rand.nextInt(rangeValues);
				}
			}
			
			///////////////// Y SHIFT /////////////////
			platformXY[1] = previousYEnd;
			ratioSum = 0;
			for(int i = 0; i < YShiftRates.length; i++)
			{	ratioSum += YShiftRates[i];
				if(Rand.nextInt(maxRate) + 1 <= Math.pow(YShiftRates[i],2)/ratioSum)
				{	int valueRange = Emulator.ResolutionXY[1]/(YShiftRates.length/2),
						rangeStart = valueRange*(i-YShiftRates.length/2);
					platformXY[1] = previousYEnd+rangeStart+Rand.nextInt(valueRange);
				}
			}
			
			///////////////// PLATFORM WIDTH /////////////////
			int widthMax = 1920, widthMin = 100;
			width = widthMin + Rand.nextInt(widthMax - widthMin);    		
			
			///////////////// PLATFORM SLOPE /////////////////
			slope = 0;
			int maxAngle = 75; 
			ratioSum = 0;
			for(int i = 0; i < SlopeRates.length; i++)
			{	ratioSum += SlopeRates[i];
				if(Rand.nextInt(maxRate) + 1 <= Math.pow(SlopeRates[i],2)/ratioSum)
				{	int valueRange = maxAngle/(SlopeRates.length/2),
						rangeStart = valueRange*(i-SlopeRates.length/2);
					slope = rangeStart+Rand.nextInt(valueRange);
				}
			}
		}
	}		
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] getPlatformXY() 
	{	return platformXY;
	}
	public double getWidth() 
	{	return width;
	}
	public double getSlope() 
	{	return slope;
	}
	public double getFriction() 
	{	return friction;
	}
	public Image getSlopeSprite() 
	{	return slopeSprite;
	}
	public Image getBaseSprite() 
	{	return baseSprite;
	}
	
		////////////////////// SETTERS //////////////////////
	//////////////////////
	public void setPlatformXY(double[] platformXY) 
	{	this.platformXY = platformXY;
	}
}