package Engine;
import java.awt.Image;
import java.util.Random;

import javax.imageio.IIOImage;
public class Platform
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	static double	defaultFriction = Physics.defaultGravity*0.5;
	
	private int		index=0;	
	
	private double	friction = defaultFriction,	
					width=0, 		
					slope=0;
	
	private double[]platformXY = new double[2];
	
		////////////////////// GAME PLAY//////////////////////
	//////////////////////
	static int[]	////////////{  GAPS	    || OVERLAPS }///////////////
					xShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{  WALLS	||   DROPS  }///////////////
					yShiftRates={0,  0,  0,	   0,  0,  0},
					////////////{ DOWNWARD  ||  UPWARD  }///////////////
					slopeRates ={0,  0,  0,	   0,  0,  0}; 
	
	Random 			rand = new Random();

		////////////////////// SPRITES //////////////////////
	//////////////////////
	private Image 	baseSprite = Emulator.Level1_Base(),
					slopeSprite = Emulator.Level1_Slope();
	private double	slopeYOffset=0,			baseYOffset=0,
					slopeXOffset=0;

		////////////////////// CONSTRUCTOR //////////////////////
	//////////////////////
	public Platform (double[] platformXY, int width, int index)
	{	this.platformXY = platformXY;
		this.width = width;
		this.index = index;
	}
	
		////////////////////// PLATFORM UPDATE //////////////////////
	//////////////////////
	public void update() 
	{
		///////////////// PLATFORM JUMP /////////////////
System.out.println(index+" startX="+(int)platformXY[0]+" startY="+(int)platformXY[1]);   		
		if (platformXY[0]+width <= -Emulator.getResolutionX())
		{	
			///////////////// PREVIOUS PLATFORM /////////////////
			int	previous = index-1;
			if(previous < 0)
			{	previous = Emulator.Platform().length-1;
			}
			double previousXEnd = Emulator.Platform()[previous].getPlatformXY()[0]+Emulator.Platform()[previous].getWidth(),
				   previousYEnd = Emulator.Platform()[previous].getPlatformXY()[1]+Emulator.Platform()[previous].getWidth()*Emulator.Platform()[previous].getSlope();
					
			///////////////// X SHIFT /////////////////
			platformXY[0] = previousXEnd;
			int	maxRate = 10; 
			double ratioSum = 0;
			for(int i = 0; i < xShiftRates.length; i++)
			{	ratioSum += xShiftRates[i];
				if(rand.nextInt(maxRate) + 1 <= Math.pow(xShiftRates[i],2)/ratioSum)
				{	int rangeValues = Emulator.getResolutionX()/(xShiftRates.length/2),
						rangeStart = rangeValues*(i-xShiftRates.length/2);
					platformXY[0] = previousXEnd+rangeStart+rand.nextInt(rangeValues);
				}
			}
			
			///////////////// Y SHIFT /////////////////
			platformXY[1] = previousYEnd;
			ratioSum = 0;
			for(int i = 0; i < yShiftRates.length; i++)
			{	ratioSum += yShiftRates[i];
				if(rand.nextInt(maxRate) + 1 <= Math.pow(yShiftRates[i],2)/ratioSum)
				{	int valueRange = Emulator.getResolutionY()/(yShiftRates.length/2),
						rangeStart = valueRange*(i-yShiftRates.length/2);
					platformXY[1] = previousYEnd+rangeStart+rand.nextInt(valueRange);
				}
			}
			
			///////////////// PLATFORM WIDTH /////////////////
			int widthMax = 1920, widthMin = 100;
			width = widthMin + rand.nextInt(widthMax - widthMin);    		
			
			///////////////// PLATFORM SLOPE /////////////////
			slope = 0;
			int maxAngle = 75; 
			ratioSum = 0;
			for(int i = 0; i < slopeRates.length; i++)
			{	ratioSum += slopeRates[i];
				if(rand.nextInt(maxRate) + 1 <= Math.pow(slopeRates[i],2)/ratioSum)
				{	int valueRange = maxAngle/(slopeRates.length/2),
						rangeStart = valueRange*(i-slopeRates.length/2);
					slope = rangeStart+rand.nextInt(valueRange);
				}
			}
		}
	}		
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] getPlatformXY() 
	{	return platformXY;
	}
	public double getWidth() 
	{	return width;
	}
	public double getSlope() 
	{	return slope;
	}
	public double getFriction() 
	{	return friction;
	}
	public Image getSlopeSprite() 
	{	return slopeSprite;
	}
	public double getSlopeYOffset() 
	{	return slopeYOffset;
	}
	public double getSlopeXOffset() 
	{	return slopeXOffset;
	}
	public Image getBaseSprite() 
	{	return baseSprite;
	}
	public double getBaseYOffset() 
	{	return baseYOffset;
	}
	
		////////////////////// SETTERS //////////////////////
	//////////////////////
	public void setPlatformXY(double[] platformXY) 
	{	this.platformXY = platformXY;
	}
	public void setSlopeSprite(Image slopeSprite) 
	{	this.slopeSprite = slopeSprite;
	}
	public void setBaseSprite(Image baseSprite) 
	{	this.baseSprite = baseSprite;
	}
}