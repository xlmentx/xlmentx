package Engine;
import java.awt.Image;
public class Characters 
{	
		////////////////////// STATS UPDATE //////////////////////
	////////////////////// 		
	public void update(int playerNum, int classType, int xpFile)
	{	double friction = Platform.defaultFriction;
	
		////////////////////// DEFAULT STATS //////////////////////
				///////{grndAccel,		airAccel,		topSpeed,		jump,	  		doubleJump} 		
		double[]stats= {friction+0.2,	0.2,		   	20,			 	-15,			-5	},
				
				maxXp= {0.3,			0.3,			5,				-5,				-10	},
				
				earth= {0,				0,				0,				0,				0	},
				fire = {0,				0,				0,				0,				0	},
				water= {0,				0,				0,				0,				0	},
				air  = {0,				0,				0,				0,				0	},
			
		////////////////////// RETREIVED XP //////////////////////
				xP	 = {0,	 			0,				0,		 		0,				0	},
			
		////////////////////// RETREIVED CLASS //////////////////////
		classStats = {0,0,0,0,0};
		switch(classType)
		{	case 1:	classStats = earth; break;
			case 2:	classStats = fire; 	break;
			case 3:	classStats = water; break;
			case 4:	classStats = air; 	break;
		}
	
		////////////////////// STAT ASSIGNMENTS //////////////////////
		for(int i = 0; i < stats.length; i++)	
		{	stats[i] += (xP[i]/100)*maxXp[i]+classStats[i];
			switch(i)
			{	case 0:	Emulator.Player()[playerNum].setGroundAccel(stats[i]);	break;
				case 1:	Emulator.Player()[playerNum].setAirAccel(stats[i]);		break;
				case 2:	Emulator.Player()[playerNum].setTopSpeed(stats[i]);		break;					
				case 3:	Emulator.Player()[playerNum].setJump(stats[i]);			break;
				case 4:	Emulator.Player()[playerNum].setDoubleJump(stats[i]);	break;
			}
		}			
	}
}