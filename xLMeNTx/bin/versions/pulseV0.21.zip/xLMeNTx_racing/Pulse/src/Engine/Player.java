package Engine;
import java.awt.Image;
public class Player 	
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int			index=0,			sprite=1,
						yKeyPressed=0,		airAllow=1;		
	
	private double		groundAccel=0,		airAccel=0,			topSpeed=0,		
						jump=0,				doubleJump=0;
	
	private double[]	centerXY = new double[2],
						velocityXY = new double[2];
		
		//////////////////////CONSTRUCTOR//////////////////////
	//////////////////////
	public Player (double[] centerXY, int index)
	{	this.centerXY = centerXY;
		this.index = index;
	}

		////////////////////// PLAYER UPDATE //////////////////////
	//////////////////////
	public void update( int xInput, int yInput) 
	{	Physics physics = new Physics();				
	
		///////////////////// COLLISION CHECK //////////////////////
		double[]proximityValues = physics.scanProximity(centerXY, velocityXY),
				thetaXY = {proximityValues[0], proximityValues[1]};
System.out.println(" ");

		////////////////////// X INPUT //////////////////////
		if(Math.abs(xInput) == 1)
		{	////////////////////// ACCELERATION //////////////////////
			if(Math.abs(velocityXY[0]) < topSpeed)
			{	////////////////////// SURFACE CONTACT //////////////////////
				if(thetaXY[0] != 180 || thetaXY[1] != 180)
				{	velocityXY[0] += groundAccel*xInput*Math.cos(Math.toRadians(thetaXY[1])); 	 
					velocityXY[1] -= groundAccel*xInput*Math.sin(Math.toRadians(thetaXY[1])); 	 
System.out.println("xI.1 a="+groundAccel*xInput+" xa="+groundAccel*xInput*Math.cos(Math.toRadians(thetaXY[1]))+" ya="+-groundAccel*xInput*Math.sin(Math.toRadians(thetaXY[1])));
					airAllow = 0;
				}
				////////////////////// IN AIR //////////////////////
				else
				{	////////////////////// ACCELERATION //////////////////////
					if( airAllow > 0 || xInput*velocityXY[0] <= 0)
					{	velocityXY[0] += airAccel*xInput; 	 
System.out.println("xI.2 xa="+airAccel*xInput+" xv="+velocityXY[0]+" yv="+velocityXY[1]);
					}
				}	
			}
			sprite = 2;	
		}
	
		////////////////////// Y INPUT //////////////////////
		if(yInput == 1 && yKeyPressed == 0) 
		{	////////////////////// KEY PRESSED //////////////////////
			yKeyPressed = 1;
			////////////////////// SURFACE CONTACT //////////////////////
			if(thetaXY[0] != 180 || thetaXY[1] != 180)
			{	velocityXY[0] += jump*Math.sin(Math.toRadians(thetaXY[1]))/2;	
				velocityXY[1] += jump;	
				airAllow = 1;
System.out.println("y.1  ys="+velocityXY[1]+" cy="+centerXY[1]+" yI="+jump);						
			}
			////////////////////// IN AIR //////////////////////
			else
			{	if(airAllow == 1)
				{	velocityXY[1] = (velocityXY[1]+doubleJump>=jump && velocityXY[1]<0)? 
						velocityXY[1] + doubleJump: doubleJump;
					airAllow = 2;					
System.out.println("y.2  ys="+velocityXY[1]+" cy="+centerXY[1]+" yI="+yInput);						
				}	
			}
		}
		////////////////////// Y KEY RESET //////////////////////
		if(yInput == 0)
		{	yKeyPressed = 0;
		}
	
		////////////////////// PHYSICS //////////////////////
		velocityXY = physics.applyForces(centerXY, velocityXY);	
	
		////////////////////// X LOCATION UPDATE//////////////////////
		if(centerXY[0] + velocityXY[0] < Emulator.getRightScrollingValue() && centerXY[0] + velocityXY[0] > Emulator.getLeftScrollingValue())
		{	centerXY[0] += velocityXY[0];
System.out.println("	uX.1 v="+velocityXY[0]+" x="+centerXY[0]);	
		}
		else
		{	for(int i = 0; i < Emulator.Platform().length; i++)
			{	Emulator.Platform()[i].setPlatformXY(new double[] {(Emulator.Platform()[i].getPlatformXY()[0] - velocityXY[0]), Emulator.Platform()[i].getPlatformXY()[1]});			
			}
System.out.println("	uX.2 v="+velocityXY[0]+" x="+centerXY[0]);	
		}	
	
		////////////////////// Y LOCATION UPDATE//////////////////////
		if(centerXY[1] + velocityXY[1] < Emulator.getBottomScrollingValue() && centerXY[1] + velocityXY[1] > Emulator.getTopScrollingValue())
		{	centerXY[1] += velocityXY[1];
//System.out.println("	uY.1 v="+velocityXY[1]+" y="+centerXY[1]);	
		}
		else
		{	for(int i = 0; i < Emulator.Platform().length; i++)
			{	Emulator.Platform()[i].setPlatformXY(new double[] {Emulator.Platform()[i].getPlatformXY()[0], (Emulator.Platform()[i].getPlatformXY()[1] - velocityXY[1])});	
			}
//System.out.println("	uY.2 v="+velocityXY[1]+" y="+centerXY[1]);	
		}	
		Emulator.getSprites().upDate(index, sprite, velocityXY[0], velocityXY[1]);	
	}
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] getCenterXY() 
	{	return centerXY;
	}
	
		////////////////////// SETTERS //////////////////////
	//////////////////////
	public void setIndex(int index) 
	{	this.index = index;
	}
	public void setGroundAccel(double groundAccel) 
	{	this.groundAccel = groundAccel;
	}
	public void setAirAccel(double airAccel) 
	{	this.airAccel = airAccel;
	}
	public void setTopSpeed(double topSpeed) 
	{	this.topSpeed = topSpeed;
	}
	public void setJump(double jump) 
	{	this.jump = jump;
	}
	public void setDoubleJump(double doubleJump) 
	{	this.doubleJump = doubleJump;
	}
}	