package Tests;
public class Tests 
{	
		////////////////////// TESTS //////////////////////
	//////////////////////
	public static void main(String[] args)
	{	double[] p0 = {Math.toRadians(-20),Math.toRadians(90)},
			 	 vXY = {0, -10},
				 nFXY = {0, 0},
				 sFXY = {0, 0},
				 X = {0,1,1,1,0,-1,-1,-1},
				 Y = {-1,-1,0,1,1,1,0,-1};
		double 	 vM = Math.sqrt(Math.pow(vXY[1],2)+Math.pow(vXY[0],2)),
				x = 0,
				y = -1,
				pTheta = -180,
				shift = -360;
				for(int i=0; i < X.length; i++)
				{	double vTheta = Math.toDegrees(Math.atan2(-Y[i], X[i]));
					if(vTheta >= 90)
					{	vTheta += shift;
					}
System.out.println("vTheta = "+vTheta+" pTheta = "+pTheta);
					if(vTheta < pTheta && vTheta > pTheta-180)
					{	
System.out.println("	passed = "+vTheta);
					}
				}
		///////////////////// SUM CONTACT FORCES //////////////////////
		for(int i = 0; i < p0.length; i++)
		{	nFXY = applyForces(i, p0[i], vXY);
			vXY[0] += nFXY[0];
			vXY[1] += nFXY[1];
			vM = Math.sqrt(Math.pow(vXY[1],2)+Math.pow(vXY[0],2)); 					
System.out.println("vM = "+round(vM)+"	vX = "+round(vXY[0])+"	vY = "+round(vXY[1]));
		}

		///////////////////// SUM CONTACT FORCES //////////////////////
System.out.println("\nVS ");
		vXY[0] = 0;
		vXY[1] = -10;
		for(int i = 0; i < p0.length; i++)
		{	nFXY = applyForces(i, p0[i], vXY);
			sFXY[0] += nFXY[0];
			sFXY[1] += nFXY[1];
		}
			vXY[0] += sFXY[0];
			vXY[1] += sFXY[1];
			vM = Math.sqrt(Math.pow(vXY[1],2)+Math.pow(vXY[0],2)); 					
System.out.println("vM = "+round(vM)+"	vX = "+round(vXY[0])+"	vY = "+round(vXY[1]));


	}
	
	public static double[] applyForces(int i, double p0, double[] vXY)
	{	////////////////////// NORMAL FORCE //////////////////////
System.out.println("\nCOLLISION "+(i+1));
		double		v0 = Math.atan2(-vXY[1],vXY[0]),
					vM = Math.sqrt(Math.pow(vXY[1],2)+Math.pow(vXY[0],2)), 
					n0 = p0 + Math.toRadians(90),
					nF = Math.abs(vM*Math.cos(n0-v0));
		double[] 	nFXY = {nF*Math.cos(n0), nF*Math.sin(n0)};
System.out.println("p"+(i+1)+"0 = "+round(Math.toDegrees(p0))+"	n"+(i+1)+"0 = "+round(Math.toDegrees(n0)));
System.out.println("vM = "+round(vM)+"	vX = "+round(vXY[0])+"	vY = "+round(vXY[1]));
System.out.println("nF = "+round(nF)+"	nFX = "+round(nFXY[0])+"	nFY = "+round(nFXY[1]));
		return nFXY;
	}
	
	static double round(double num)
	{	double percision = 100;
		num = ((int)(num*percision))/percision;
		return num;
	}
}