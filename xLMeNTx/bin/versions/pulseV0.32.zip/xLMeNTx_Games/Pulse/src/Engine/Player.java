package Engine;
import java.awt.Image;
import java.math.BigDecimal;
public class Player extends Character
{		////////////////////// ATRIBUTES //////////////////////
	//////////////////////
	private int			index,  xKeyLast, yKeyHeld,		
						jumpCounter;
	private double[]	centerXY = new double[2],
						dimensionXY = new double[2],
						velocityXY = new double[2],
						thetaXY = new double[2];
	private Image		currentSprite = Engine.none;
		//////////////////////CONSTRUCTOR//////////////////////
	//////////////////////
	public Player (int index, double[] centerXY)
	{	this.index = index;
		this.xKeyLast = 1;
		this.centerXY = centerXY;
		dimensionXY = new double[]{100,100};
		updateStats(index, 0, 0);
	}

		////////////////////// PLAYER UPDATE //////////////////////
	//////////////////////
	public void update(int xInput, int yInput) 
	{	////////////////////// X INPUT //////////////////////
//System.out.println();
		if(Math.abs(xInput) == 1)
		{	xKeyLast = xInput;
			////////////////////// GROUND ACCELERATION //////////////////////
			if(thetaXY[1] != Physics.Null && xInput*velocityXY[0] >= 0)
			{	////////////////////// TOPSPEED LIMIT //////////////////////
				if(Math.abs(velocityXY[0]) <= topSpeed)
				{	velocityXY[0] += groundAccel*xInput*Math.cos(thetaXY[1]); 	 
					velocityXY[1] -= groundAccel*xInput*Math.sin(thetaXY[1]); 	 
//System.out.println("x.1 vX="+velocityXY[0]+" aX="+groundAccel*xInput*Math.cos(thetaXY[1])+" tS="+topSpeed*Math.cos(thetaXY[1]));						
//System.out.println("y.1 vY="+velocityXY[1]+" aY="+(-groundAccel*xInput*Math.sin(contactThetaXY[1])));											
				}
			}
			////////////////////// AERIAL ACCELERATION //////////////////////
			if(thetaXY[1] == Physics.Null)
			{	////////////////////// TOPSPEED LIMIT //////////////////////
				if(Math.abs(velocityXY[0]) <= topSpeed)
				{	velocityXY[0] += airAccel*xInput; 	 
//System.out.println("x.2 xa="+airAccel*xInputPL[0]+" xv="+velocityXY[0]+" yv="+velocityXY[1]+" tS="+topSpeed);
				}
			}
		}
				
		////////////////////// Y INPUT //////////////////////
		if(yInput == 1) 
		{	if(yKeyHeld == 0) 
			{	////////////////////// GROUND JUMP//////////////////////
				if(thetaXY[1] != Physics.Null)
				{	velocityXY[0] += jump*Math.sin(thetaXY[1]/3);
		    		velocityXY[1] = jump*Math.cos(thetaXY[1]/3);
System.out.println("x.4 vX="+velocityXY[0]+" aX="+jump*Math.sin(thetaXY[1]/3));						
System.out.println("y.3 vY="+velocityXY[1]+" aY="+jump*Math.cos(thetaXY[1]/3));						
		    		jumpCounter = 1;					
				}
				////////////////////// WALL JUMP //////////////////////
				if(thetaXY[0] != Physics.Null && thetaXY[1] == Physics.Null)
				{	velocityXY[0] = jump*Math.sin(thetaXY[0]/3);
					velocityXY[1] = jump*Math.cos(thetaXY[0]/3);
System.out.println("x.5 vX="+velocityXY[0]+" aX="+jump*Math.sin(thetaXY[1]/3));						
System.out.println("y.4 vY="+velocityXY[1]+" aY="+jump*Math.cos(thetaXY[1]/3));						
					jumpCounter = 1;					
				}
				////////////////////// AERIAL JUMP //////////////////////
				if(thetaXY[0] == Physics.Null && thetaXY[1] == Physics.Null && jumpCounter == 1)
				{	 velocityXY[1] = doubleJump;
System.out.println("y.5  vY="+velocityXY[1]);							
					jumpCounter = 0;					
				}	
				yKeyHeld = 1;
			}
		}
		////////////////////// Y RELEASE //////////////////////
		else
		{	yKeyHeld = 0;
		}
		
		////////////////////// PHYSICS //////////////////////
		double[] vectorUpdate = Physics.applyForces(xInput, centerXY, dimensionXY, velocityXY);
		centerXY = new double[] {vectorUpdate[0], vectorUpdate[1]};	
		velocityXY = new double[] {vectorUpdate[2], vectorUpdate[3]};	
		thetaXY = new double[] {vectorUpdate[4], vectorUpdate[5]};	
		
		////////////////////// X LOCATION UPDATE//////////////////////
		if(centerXY[0]+velocityXY[0] < Engine.XLimitLR[1] && centerXY[0]+velocityXY[0] > Engine.XLimitLR[0])
		{	centerXY[0] += velocityXY[0];
			Platform.ScrollSpeedXY[0] = 0;
//System.out.println("x.6 cX="+centerXY[0]+" vX="+velocityXY[0]+" sS="+Platform.ScrollSpeedXY[0]);	
		}
		////////////////////// HORRIZONTAL SCROLLING //////////////////////
		else
		{	////////////////////// RIGHTWARD //////////////////////
			if(centerXY[0]+velocityXY[0] >= Engine.XLimitLR[1])
			{	Platform.ScrollSpeedXY[0] = Engine.XLimitLR[1]-(centerXY[0]+velocityXY[0]);
//System.out.println("x.7 cX="+centerXY[0]+" vX="+velocityXY[0]+" lY="+Emulator.XLimitLR[1]+" sS="+Platform.ScrollSpeedXY[0]);	
				centerXY[0] = Engine.XLimitLR[1];
			}
			////////////////////// LEFTWARD //////////////////////
			if(centerXY[0]+velocityXY[0] <= Engine.XLimitLR[0])
			{	Platform.ScrollSpeedXY[0] = Engine.XLimitLR[0]-(centerXY[0]+velocityXY[0]);
//System.out.println("x.8 cX="+centerXY[0]+" vX="+velocityXY[0]+" lY="+Emulator.XLimitLR[0]+" sS="+Platform.ScrollSpeedXY[0]);	
				centerXY[0] = Engine.XLimitLR[0];
			}
		}
		
		////////////////////// Y LOCATION UPDATE//////////////////////
		if(centerXY[1]+velocityXY[1] < Engine.YLimitUD[1] && centerXY[1]+velocityXY[1] > Engine.YLimitUD[0])
		{	centerXY[1] += velocityXY[1];
			Platform.ScrollSpeedXY[1] = 0;
//System.out.println("y.6 cX="+centerXY[1]+" vX="+velocityXY[1]+" sS="+Platform.ScrollSpeedXY[1]);	
		}
		////////////////////// VERTICAL SCROLLING //////////////////////
		else
		{	////////////////////// DOWNWARD //////////////////////
			if(centerXY[1]+velocityXY[1] >= Engine.YLimitUD[1])
			{	Platform.ScrollSpeedXY[1] = Engine.YLimitUD[1]-(centerXY[1]+velocityXY[1]);
//System.out.println("y.7 cY="+centerXY[1]+" vY="+velocityXY[1]+" lY="+Emulator.YLimitUD[1]+" sS="+Platform.ScrollSpeedXY[1]);	
				centerXY[1] = Engine.YLimitUD[1];
			}
			////////////////////// UPWARD //////////////////////
			if(centerXY[1]+velocityXY[1] <= Engine.YLimitUD[0])
			{	Platform.ScrollSpeedXY[1] = Engine.YLimitUD[0]-(centerXY[1]+velocityXY[1]);
//System.out.println("y.8 cY="+centerXY[1]+" vY="+velocityXY[1]+" lY="+Emulator.YLimitUD[0]+" sS="+Platform.ScrollSpeedXY[1]);	
				centerXY[1] = Engine.YLimitUD[0];
			}
		}	
		
		////////////////////// SPRITE UPDATE //////////////////////
		currentSprite = getSprite(xInput, xKeyLast, velocityXY, thetaXY);
	}
	
		////////////////////// GETTERS //////////////////////
	//////////////////////
	public double[] CenterXY() 
	{	return centerXY;
	}
	public double[] DimensionXY() 
	{	return dimensionXY;
	}
	public Image CurrentSprite() 
	{	return currentSprite;
	}
	
}	