package Engine;
import java.awt.Image;
import java.text.DecimalFormat;
public class Physics 
{		////////////////////// STATIC DECLARATIONS //////////////////////
	//////////////////////
	static double 	Gravity = 0.5,
					Null = Engine.ResolutionXY[0];
					
		///////////////////// FORCE VECTORS SUMMATION //////////////////////
	//////////////////////
	public static double[] applyForces(int xInput, double[] centerXY, double[] dimensionXY, double[] velocityXY)
	{	////////////////////// GRAVITY //////////////////////
		velocityXY[1] += Gravity;
//System.out.println("  Gravity  Vx="+velocityXY[0]+"	Vy="+velocityXY[1]);
 		
		////////////////////// PROXIMITY DEFAULT VALUES //////////////////////
		double[] 	contactXY	={Null, Null},
			 		thetaXY 	={Null, Null},
			 		uFrictionXY ={Null, Null};
		
		////////////////////// PLATFORM SCANS //////////////////////
		for(int i = 0; i < Engine.Platform.length; i++)
		{	if(Engine.Platform[i].OnScreen() == true)
			{	double[] platformLocationXY = Engine.Platform[i].LocationXY(),
					 	 platformDimensionXY = Engine.Platform[i].DimensionXY();
				//////////////////////RIGHTWARD CONTACT //////////////////////
				if(centerXY[1]-dimensionXY[1]/4 > platformLocationXY[1])
				{	double contact = platformLocationXY[0];
					if(centerXY[0]+velocityXY[0] >= contact && centerXY[0]-dimensionXY[0]/4 <= contact)
					{	contactXY[0] = contact;
						thetaXY[0] = Math.toRadians(90);
						uFrictionXY[0] = Engine.Platform[i].uFrictionXY()[0];						
//System.out.println("RCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+Math.toDegrees(thetaXY[0]));
					}	
				}
				////////////////////// LEFTWARD CONTACT //////////////////////
				if(centerXY[1]-dimensionXY[1]/4 > platformLocationXY[1]+platformDimensionXY[1])
				{	double contact = platformLocationXY[0] + platformDimensionXY[0];
					if(centerXY[0]+velocityXY[0] <= contact && centerXY[0]+dimensionXY[0]/4 >= contact)
					{	contactXY[0] = contact;
						thetaXY[0] = -Math.toRadians(90);
						uFrictionXY[0] = Engine.Platform[i].uFrictionXY()[0];						
//System.out.println("LCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+Math.toDegrees(thetaXY[0]));
					}
				}
				////////////////////// DOWNWARD CONTACT //////////////////////
				if(centerXY[0]+dimensionXY[0]/4 >= platformLocationXY[0] && centerXY[0]-dimensionXY[0]/4 <= platformLocationXY[0]+platformDimensionXY[0])
				{	double 	futureContact = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]+velocityXY[0]-platformLocationXY[0])+platformLocationXY[1],
							currentContact = (platformDimensionXY[1]/platformDimensionXY[0])*(centerXY[0]-platformLocationXY[0])+platformLocationXY[1];
					if(centerXY[1]+velocityXY[1] >= futureContact && centerXY[1]-dimensionXY[1]/4 <= futureContact)
					{	contactXY[1] = currentContact;
						thetaXY[1] =  Math.atan2(-platformDimensionXY[1], platformDimensionXY[0]);
						uFrictionXY[1] = Engine.Platform[i].uFrictionXY()[1];						
//System.out.println("DCollision p"+i+" Cx="+centerXY[0]+" Cy="+centerXY[1]+" CT="+Math.toDegrees(thetaXY[1]));
					}
				}
			}
		}
		
			///////////////////// APPLY CONTACT FORCES //////////////////////
		//////////////////////
		for(int i = 0; i < thetaXY.length; i++)
		{	if(thetaXY[i] != Null)
			{	////////////////////// NORMAL FORCE //////////////////////
				double	velocityTheta = Math.atan2(-velocityXY[1],velocityXY[0]),
						velocity = Math.sqrt(velocityXY[0]*velocityXY[0]+velocityXY[1]*velocityXY[1]), 
						normalTheta = thetaXY[i] + Math.toRadians(90),
						normalForce = Math.abs(velocity*Math.cos(normalTheta-velocityTheta));
				centerXY[i] = contactXY[i];
				velocityXY[0] += normalForce*Math.cos(normalTheta);
				velocityXY[1] -= normalForce*Math.sin(normalTheta);
//System.out.println("  nForceXY["+i+"] nF="+round(normalForce)+" nFX="+round(normalForce*Math.cos(normalTheta))+" nFY="+round(-normalForce*Math.sin(normalTheta)));
				////////////////////// FRICTION FORCE //////////////////////
				if(i == 0 && velocityXY[1] >= 0 || i == 1 && xInput*velocityXY[0] <= 0 )
				{	double frictionForce = normalForce*uFrictionXY[i];
					velocity = Math.sqrt(velocityXY[0]*velocityXY[0]+velocityXY[1]*velocityXY[1]); 
					if(frictionForce > Math.abs(velocityXY[1-i]))
					{	frictionForce = velocity;
					}
						velocityXY[0] -= frictionForce*Math.cos(thetaXY[i])*Math.signum(velocityXY[0]); 	 
						velocityXY[1] -= frictionForce*Math.abs(Math.sin(thetaXY[i]))*Math.signum(velocityXY[1]); 	 
//System.out.println("  fForceXY["+i+"] fF="+round(frictionForce)+" Fx="+-round(frictionForce*Math.cos(thetaXY[i])*Math.signum(velocityXY[0]))+" Fy="+-round(frictionForce*Math.abs(Math.sin(thetaXY[i]))*Math.signum(velocityXY[1])));
				}
			}
		}
		
//System.out.println("  finalSum  Vx="+round(velocityXY[0])+"  Vy="+round(velocityXY[1])+"  Cx="+round(centerXY[0])+"  Cy="+round(centerXY[1]));
		////////////////////// VECTOR RETURN //////////////////////
		return new double[] {centerXY[0], centerXY[1], round(velocityXY[0]), round(velocityXY[1]), thetaXY[0], thetaXY[1]};
	}
		
		///////////////////// ROUND VALUES //////////////////////
	//////////////////////
	static double round(double num)
	{	double percision = 100;
		num = ((int)(num*percision))/percision;
		return num;
	}
}