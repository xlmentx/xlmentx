package Engine;
import java.awt.Image;
public class Player 
{	////////////////////// ATRIBUTES //////////////////////
	private int			playerNum,			charType = 1,		classType=1,		xpFile=0;
						
	private double		centerXlocation,	centerYlocation,					
						width, 				hight,
						acceleration,		torque,				topSpeed,	
						verticalLeap,		airJump,			
						climbStrength,		wallLeap;
	
	////////////////////// USER INPUT //////////////////////
	private int 		xMovement=1,		xKeyPressed=0,	
						doubleJump=1,		yKeyPressed=0;
	
	private double 		xSpeed,				ySpeed;
	
	//////////////////////PHYSICS//////////////////////
	private int 		currentPlatform,	previousPlatform,	nextPlatform;		
	private double		activeSlope,		platformContact,	gradient,		stoppingFriction,				
						
						wall,				wallTop,			wallBottom,			wallHight,
						wallJumpCap,				
	
						gap,
						
						gravity=0.5;		
	
	////////////////////// GAME PLAY//////////////////////
	private int			script=0;			
						
	private double		yScrollLimit,
	
						slideRate = 1,			wallReleaseMin=30,		
						
						respawnDistance;
						  			
	private boolean 	limbingLeft,limbingRight;				
	
	////////////////////// SPRITES //////////////////////
	private Image 		currentSprite;
		
//////////////////////CONSTRUCTOR//////////////////////
public Player (int x, int y)
{	centerXlocation = x;
	centerYlocation = y;
}

////////////////////// PLAYER CLASS UPDATE //////////////////////
public void update() 
{		
	
	
		////////////////////// USER INPUT //////////////////////
//////////////////////
	//////////////////////
	if(script == 0)
	{	
		////////////////////// X RIGHT //////////////////////
		if(Emulator.getXKey() == 1)
		{	if(centerXlocation - width/2.0 + xSpeed != wall || centerYlocation + ySpeed < wallTop || centerYlocation + ySpeed >= platformContact)
			{	if(xSpeed < 0 && centerYlocation + ySpeed >= platformContact)
				{	xMovement = -3;
				}
				else
				{	if(centerXlocation + width/2.0 + xSpeed == wall && centerYlocation >= wallTop)
					{	xMovement = 5;
					}
					else
					{	xMovement = 2;
					}	
				}
				xKeyPressed = 1;
			}
			else
			{	++xKeyPressed;
				if(xKeyPressed == wallReleaseMin)
				{	xMovement = 2;
				}
			}	
		}
		
		////////////////////// X LEFT //////////////////////
		if(Emulator.getXKey() == -1)
		{	if(centerXlocation + width/2.0 + xSpeed != wall || centerYlocation + ySpeed < wallTop || centerYlocation + ySpeed >= platformContact)
			{	if(xSpeed > 0 && centerYlocation + ySpeed >= platformContact)
				{	xMovement = 3;
				}
				else
				{	if(centerXlocation - width/2.0 + xSpeed == wall && centerYlocation >= wallTop)
					{	xMovement = -5;
					}
					else
					{	xMovement = -2;
					}
				}	
				xKeyPressed = -1;
			}
			else
			{	--xKeyPressed;
				if(xKeyPressed == -wallReleaseMin)
				{	xMovement = -2;
				}
			}
		}
		
		////////////////////// X NONE //////////////////////
		if(Emulator.getXKey() == 0)
		{	if(xMovement < 0)
			{	if(centerXlocation - width/2.0 + xSpeed == wall && centerYlocation >= wallTop)
				{	xMovement = -4;
				}
				else
				{	xMovement = -1;
				}
			}
			if(xMovement > 0)
			{	if(centerXlocation + width/2.0 + xSpeed == wall && centerYlocation >= wallTop)
				{	xMovement = 4;
				}
				else
				{	xMovement = 1;
				}	
			}
			xKeyPressed = 0;
		}
		
		////////////////////// Y INPUT //////////////////////
		if(Emulator.getYKey() == 1)
		{	yKeyPressed++;
		}
		
		////////////////////// Y NONE //////////////////////
		if(Emulator.getYKey() == 0)
		{	yKeyPressed = 0;
		}
	
		
		
		////////////////////// X AXIS MOVEMENT //////////////////////
//////////////////////
	//////////////////////
		
		int sameDirection = xMovement/Math.abs(xMovement);
		int oppositeDirection = xMovement/-Math.abs(xMovement);
		
		////////////////////// GROUND //////////////////////
		if(centerYlocation + ySpeed >= platformContact)
		{	if(xMovement == 2 && xSpeed >= 0 || xMovement == -2 && xSpeed <= 0 )  
			{	////////////////////// ACCELERATION //////////////////////
				if(xMovement == 2 && xSpeed + acceleration*gradient < topSpeed*gradient || xMovement == -2 && xSpeed - acceleration*gradient > -topSpeed*gradient)
				{	xSpeed = xSpeed + sameDirection*acceleration*gradient;
System.out.println("x.1  xs="+xSpeed+" cx="+centerXlocation);
				}
				////////////////////// TOP SPEED //////////////////////
				if(xSpeed != sameDirection*topSpeed*gradient)
				{	if(xMovement == 2 && xSpeed + acceleration*gradient >= topSpeed*gradient || xMovement == -2 && xSpeed - acceleration*gradient <= -topSpeed*gradient)
					{	if(xMovement == 2 && xSpeed + stoppingFriction <= topSpeed*gradient || xMovement == -2 && xSpeed - stoppingFriction >= -topSpeed*gradient)
						{	xSpeed = sameDirection*topSpeed*gradient;
System.out.println("x.2  xs="+xSpeed+" cx="+centerXlocation);
						}
					}
				}
				////////////////////// GRADIENT SPEED REDUCTION //////////////////////
				if(xMovement == 2 && xSpeed + stoppingFriction >= topSpeed*gradient || xMovement == -2 && xSpeed - stoppingFriction <= -topSpeed*gradient)
				{	xSpeed = xSpeed + sameDirection*stoppingFriction*0.5;
System.out.println("x.3  xs="+xSpeed+" cx="+centerXlocation);		
				}
			}
			////////////////////// STOPPING //////////////////////
			if(xMovement > 0 && xMovement != 2  && xSpeed + stoppingFriction >= 0 || xMovement < 0 && xMovement != -2  && xSpeed - stoppingFriction <= 0)
			{	xSpeed = xSpeed + sameDirection*stoppingFriction;
System.out.println("x.4 xs="+xSpeed+" cx="+centerXlocation+" sf= "+(sameDirection*stoppingFriction));
				////////////////////// SLIDING //////////////////////
				if(xMovement == 3 && xSpeed - acceleration >= 0 || xMovement == -3 && xSpeed + acceleration <= 0)
				{	xSpeed = xSpeed + oppositeDirection*acceleration;
System.out.println("x.5  xs="+xSpeed+" cx="+centerXlocation+" a= "+ (oppositeDirection*acceleration));			
				}
			}
			////////////////////// STOP //////////////////////
			if(xMovement > 0 && xMovement != 2  && xSpeed + stoppingFriction < 0 || xMovement < 0 && xMovement != -2  && xSpeed - stoppingFriction > 0)
			{	if(xSpeed != 0)
				{	xSpeed = 0;
System.out.println("x.6 xs="+xSpeed+" cx="+centerXlocation);
				}
			}
		}
		
		////////////////////// AIR //////////////////////
		else
		{	if(xMovement == 2 && xSpeed < 0 || xMovement == -2 && xSpeed > 0)
			{	xSpeed = sameDirection;
System.out.println("x.7 xs="+xSpeed+" cx="+centerXlocation);	
			}
			if(xMovement == 2 && xSpeed + acceleration/2.0 < topSpeed || xMovement == -2 && xSpeed - acceleration/2.0 > -topSpeed)
			{	xSpeed = xSpeed + sameDirection*acceleration/2.0;
System.out.println("x.8 xs="+xSpeed+" cx="+centerXlocation);	
			}
		}

		
		
		////////////////////// Y AXIS MOVEMENT //////////////////////
//////////////////////
	//////////////////////
		
		////////////////////// GROUND //////////////////////
		if (centerYlocation + ySpeed >= platformContact) 
		{	////////////////////// JUMP //////////////////////
			if (yKeyPressed == 1) 
			{	ySpeed = verticalLeap;						
System.out.println("	y.1  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
			}
		}		
		
		////////////////////// AIR //////////////////////
		else
		{	if(ySpeed <= slideRate)
			{	if(centerXlocation + width/2.0 == wall || centerXlocation - width/2.0 == wall)
				{	////////////////////// CLIMB //////////////////////
					if(xMovement == 5 || xMovement == -5)
					{	if(centerYlocation >= wallTop && ySpeed >= climbStrength  )
						{	ySpeed = climbStrength;
System.out.println("	y.2 ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop);	
						}
					}
					if (yKeyPressed == 1) 
					{	script = 2;
						////////////////////// JUMP CLIMB //////////////////////
						if(centerYlocation <= wallJumpCap || gap > verticalLeap*(wallLeap/gravity))
						{	ySpeed = climbStrength*2;
							xMovement = sameDirection*6;	
System.out.println("	y.3  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
							////////////////////// WALL JUMP //////////////////////
							if(xMovement > 0 && xKeyPressed < 0 || xMovement < 0 && xKeyPressed > 0)
							{	doubleJump = 1;	
								ySpeed = wallLeap;
System.out.println("	y.4  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
								xSpeed = oppositeDirection*Math.abs(verticalLeap);
System.out.println("x.9  xs= "+xSpeed+" cx= "+centerXlocation+" xm= "+xMovement);						
								xMovement = oppositeDirection*7;
							}
						}
						////////////////////// SCRIPTED WALL-JUMP //////////////////////		
						else
						{	doubleJump = 0;					
							xSpeed = oppositeDirection*gap/((Math.abs(wallLeap)/gravity) - 1);
System.out.println("x.10 xs="+xSpeed+" cx="+centerXlocation+" xM="+xMovement+" xK="+xKeyPressed);
							ySpeed = wallLeap; 
System.out.println("	y.5  ys="+ySpeed+" cy="+centerYlocation+" WJC="+wallJumpCap+" xk="+Emulator.getXKey());						
							////////////////////// OVERSHOOT PREVENTION//////////////////////
							if(centerYlocation - (wallLeap*(wallLeap*(0.5/gravity) + 0.5)) < wallJumpCap)
							{	if(xMovement > 0 && xKeyPressed > 0 || xMovement < 0 && xKeyPressed < 0)
								{	ySpeed = -(Math.sqrt(0.25 + 4*(0.5/gravity)*(centerYlocation-wallJumpCap)) - 0.5)/(1/gravity);
System.out.println("	y.6  ys="+ySpeed+" cy="+centerYlocation);
									xSpeed = oppositeDirection*gap/((Math.abs(ySpeed)/gravity) - 1);
System.out.println("x.11  xs="+xSpeed+" cx="+centerXlocation);
								}
							}
							xMovement = oppositeDirection*7;	
						}
					}
				}			
			}
			////////////////////// DOUBLE JUMP //////////////////////
			if( yKeyPressed == 1 && doubleJump == 1 && script == 0)
			{	ySpeed = airJump;
				doubleJump = 0;					
System.out.println("	y.7  ys="+ySpeed+" cy="+centerYlocation+" wt="+wallTop);						
			}		
		}
	}

	
	
		////////////////////// WORLD PROPERTIES //////////////////////
//////////////////////
	//////////////////////

	int sameDirection = xMovement/Math.abs(xMovement);
	int oppositeDirection = xMovement/-Math.abs(xMovement);

	//////////////////////DEFAULT VALUES//////////////////////
	platformContact=Emulator.getResolutionY();
	boolean pitFall = true;
	wall = sameDirection*Emulator.getResoultionX();
	wallTop = Emulator.getResolutionY();
	wallBottom = Emulator.getResolutionY();
	wallHight = 0;
	wallJumpCap = Emulator.getResolutionY();
	gap = Emulator.getResoultionX();
	gradient = 1;
	stoppingFriction = 0;
	
	//////////////////////PLATFORM VARIABLES//////////////////////
	for(int i = 0; i < Emulator.getPlatform().length; i++)
	{	nextPlatform = i+1;
		if(nextPlatform > Emulator.getPlatform().length-1)
		{	nextPlatform = 0;
		}
		previousPlatform = i-1;
		if(previousPlatform < 0)
		{	previousPlatform = Emulator.getPlatform().length-1;
		}
		double 	platformXStart = Emulator.getPlatform()[i].getPlatformXlocation(),
		 		platformXEnd = platformXStart+Emulator.getPlatform()[i].getWidth(),
		 		platformYStart = Emulator.getPlatform()[i].getPlatformYlocation(),
				platformYEnd = Emulator.getPlatform()[i].getPlatformSlope()*Emulator.getPlatform()[i].getWidth()+platformYStart,
				currentContact = Emulator.getPlatform()[i].getPlatformSlope()*(centerXlocation-platformXStart)+platformYStart,
				previousYStart = Emulator.getPlatform()[previousPlatform].getPlatformYlocation(),
				previousYEnd = Emulator.getPlatform()[previousPlatform].getPlatformSlope()*Emulator.getPlatform()[previousPlatform].getWidth()+previousYStart,
				nextYStart = Emulator.getPlatform()[nextPlatform].getPlatformYlocation();
		//////////////////////RIGHT WALL DETECTION//////////////////////
		if(xMovement > 0 )
		{	////////////////////// Y RANGE //////////////////////
			if(	centerYlocation >= platformYStart)
			{	////////////////////// X RANGE //////////////////////
				if(centerXlocation + width/2.0 + xSpeed >= platformXStart && centerXlocation <= platformXStart)
				{	//////////////////////WALL HIGHT//////////////////////
					if(Emulator.getPlatform()[i].getXShift()<=0)
					{	wallHight=(previousYStart+(Emulator.getPlatform()[previousPlatform].getPlatformSlope()*(Emulator.getPlatform()[previousPlatform].getWidth()-(width/2.0)+Emulator.getPlatform()[i].getXShift())))-platformYStart;						 
					}
					else
					{	wallHight= Emulator.getPlatform()[i].getPlatformYlocation()+1080-platformYStart;						
					}
					//////////////////////NEXT PLATFORM'S XSHIFT AND YSHIFT//////////////////////
					if(	Emulator.getPlatform()[i].getYShift()<0 || Emulator.getPlatform()[i].getXShift()!=0)
					{	wall= platformXStart;
						wallTop=platformYStart;
						wallBottom = Emulator.getPlatform()[i].getPlatformYlocation()+1080; 
					}	
				}
			}
			////////////////////// OPPOSITE WALL //////////////////////
			if(centerXlocation-Emulator.getResoultionX() <= platformXEnd && centerXlocation >= platformXEnd && centerXlocation-platformXEnd <= gap)
			{	gap = centerXlocation - width/2-platformXEnd;	
				wallJumpCap = platformYEnd;								
			}
				
		}
		//////////////////////LEFT WALLS//////////////////////
		if(xMovement < 0 )
		{	//////////////////////Y PERAMETER RANGE//////////////////////
			if( centerYlocation >= platformYEnd)
			{	//////////////////////X PERAMETER PERCISION//////////////////////
				if(centerXlocation-width/2+xSpeed <= platformXEnd && centerXlocation >= platformXEnd)
				{	//////////////////////WALL HIGHT//////////////////////
					if(Emulator.getPlatform()[nextPlatform].getXShift()<=0)
					{	wallHight=Emulator.getPlatform()[nextPlatform].getPlatformSlope()*((width/2.0)-Emulator.getPlatform()[nextPlatform].getXShift())+Emulator.getPlatform()[nextPlatform].getPlatformYlocation()-platformYEnd;						
					}
					else
					{	wallHight= (Emulator.getPlatform()[i].getPlatformYlocation()+1080)-platformYEnd;						
					}
					//////////////////////PLATFORM'S XSHIFT AND YSHIFT//////////////////////
					if(	Emulator.getPlatform()[nextPlatform].getYShift()>0 || Emulator.getPlatform()[nextPlatform].getXShift()!=0 )
					{	wall = platformXEnd;
						wallTop = platformYEnd;
						wallBottom = Emulator.getPlatform()[i].getPlatformYlocation()+1080; 
					}	
				}
			}
			////////////////////// OPPOSITE WALL //////////////////////
			if(centerXlocation+Emulator.getResoultionX() >= platformXStart && centerXlocation <= platformXStart && platformXStart-centerXlocation <= gap)
			{	gap = platformXStart-centerXlocation-width/2;	
				wallJumpCap = platformYStart;
			}
				
		}
		//////////////////////GROUND DETECTION//////////////////////
		//////////////////////X PERAMETER RANGE//////////////////////
		if(centerXlocation >= platformXStart && centerXlocation < platformXEnd)
		{	pitFall=false;
		    currentPlatform=i;
			//////////////////////Y PERAMETER PERCISION//////////////////////
			if(centerYlocation+ySpeed >= currentContact)
			{	script = 0;
				doubleJump=1;
				activeSlope = Emulator.getPlatform()[i].getPlatformSlope();
				platformContact= currentContact;
				if(xMovement > 0)
				{	stoppingFriction=-Emulator.getPlatform()[i].getRightFriction();
					gradient=Emulator.getPlatform()[i].getRightGradient();
				}
				if(xMovement < 0)
				{	stoppingFriction=-Emulator.getPlatform()[i].getLeftFriction();	
					gradient=Emulator.getPlatform()[i].getLeftGradient();
				}
				if(gradient<1)
				{	gradient+=(1-gradient)*torque;
				}
			}
		}
	}
	nextPlatform = currentPlatform+1;
	if(nextPlatform > Emulator.getPlatform().length-1)
	{	nextPlatform = 0;
	}
	if(centerXlocation < Emulator.getPlatform()[currentPlatform].getPlatformXlocation()+Emulator.getPlatform()[currentPlatform].getWidth()/2.0)
	{	if(Emulator.getPlatform()[currentPlatform].getYShift() < 0 )
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformYlocation()-Emulator.getPlatform()[currentPlatform].getYShift();
		}
		else
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformYlocation();
		}	
	}
	else
	{	if(Emulator.getPlatform()[nextPlatform].getYShift() > 0 )
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformSlope()*Emulator.getPlatform()[currentPlatform].getWidth()+Emulator.getPlatform()[currentPlatform].getPlatformYlocation()+Emulator.getPlatform()[nextPlatform].getYShift();
		}
		else
		{	yScrollLimit = Emulator.getPlatform()[currentPlatform].getPlatformSlope()*Emulator.getPlatform()[currentPlatform].getWidth()+Emulator.getPlatform()[currentPlatform].getPlatformYlocation();
		}
	}
	
	
	
		////////////////////// PHYSICS //////////////////////
//////////////////////
	//////////////////////
	
	////////////////////// WALLS //////////////////////
	if(xMovement > 0 && centerXlocation+width/2.0+xSpeed >= wall || xMovement < 0 && centerXlocation-width/2.0+xSpeed <= wall)
	{	if(centerYlocation + ySpeed > wallTop)
		{	////////////////////// X ALLIGNMENT //////////////////////
			if(xSpeed != 0 || centerXlocation != wall + oppositeDirection*width/2.0)
			{	centerXlocation = wall + oppositeDirection*width/2.0;
				xSpeed = 0;
System.out.println(" pX.1 xs="+xSpeed+" cx="+centerXlocation+" "+xMovement);
			}
			////////////////////// Y ALLIGNMENT //////////////////////
			if(centerYlocation - hight/4 + ySpeed <= wallTop && xMovement > -4 && xMovement < 4)
			{	ySpeed = 9; 
System.out.println("	 pY.1  ys="+ySpeed+" cy="+centerYlocation);	
			}
			////////////////////// END WALL JUMP SCRIPT //////////////////////
			if(script==2)
			{	if( xMovement != sameDirection*6 || ySpeed >= 0)
				{	ySpeed = 0;
					script = 0;
					xMovement = sameDirection;
System.out.println("	 pY.2  ys="+ySpeed+" cy="+centerYlocation);			
				}
			}
			////////////////////// GRIP DELAY //////////////////////
			if(ySpeed > slideRate)
			{	ySpeed += climbStrength/3.0;	
System.out.println("	 pY.3  ys="+ySpeed+" cy="+centerYlocation+" WT="+wallTop);	
			}
			////////////////////// WALL SLIDE //////////////////////
			if(ySpeed >= 0 && centerYlocation + ySpeed < platformContact && ySpeed != slideRate)
			{	if(xMovement == 4 || xMovement == -4 )
				{	ySpeed = slideRate;
System.out.println("	 pY.4  ys="+ySpeed+" cy="+centerYlocation+" "+climbStrength);			
				}
			}
			//////////////////////SPRITES //////////////////////
			switch(xMovement)
			{ 	case -4: currentSprite = Emulator.getWallSlideLeft(); 	break;
				case  4: currentSprite = Emulator.getWallSlideRight(); 	break;
			}
//System.out.println("image.  WallSlide");
			switch(xMovement)
			{ 	case -5: currentSprite = Emulator.getClimbLeft(); 	break;
				case  5: currentSprite = Emulator.getClimbRight(); 	break;
			}
//System.out.println("image.  Climb");
			switch(xMovement)
			{ 	case -6: currentSprite = Emulator.getClimbJumpLeft(); 	break;
				case  6: currentSprite = Emulator.getClimbJumpRight(); 	break;
			}
//System.out.println("image.  ClimbJump");
		}
		else
		{	//////////////////////LEDGE TAKE OFF //////////////////////
			doubleJump = 1;
			centerYlocation = wallTop;
			xSpeed = sameDirection*topSpeed/2.0;
System.out.println("pX.2 xs="+xSpeed+" cx="+centerXlocation);
			ySpeed = verticalLeap;
System.out.println("	 pY.5  ys="+ySpeed+" cy="+centerYlocation);
		}	
	}

	////////////////////// GROUND //////////////////////
	if(centerYlocation + ySpeed >= platformContact)
	{	////////////////////// DOWNHILL //////////////////////
		if(xMovement > 0 && activeSlope > 0 || xMovement < 0 && activeSlope < 0)
		{	if(ySpeed > 0 && ySpeed != activeSlope*(xSpeed+acceleration))
			{	ySpeed = activeSlope*(xSpeed+acceleration);
System.out.println("	 pY.8  ys="+ySpeed+" cy="+centerYlocation+" as="+activeSlope);
			}		
		}
		////////////////////// UPHILL //////////////////////
		if(xMovement > 0 && activeSlope <= 0 || xMovement < 0 && activeSlope >= 0)
		{	if(ySpeed != 0 || centerYlocation != platformContact)
			{	ySpeed = 0;
				centerYlocation = platformContact;
System.out.println("	 pY.9  ys="+ySpeed+" cy="+centerYlocation+" as="+activeSlope);
			}		
		}
		////////////////////// SPRITES //////////////////////
		if(xSpeed == 0)
		{	switch(xMovement)
			{	case  1: currentSprite = Emulator.getStandRight();	break;
				case -1: currentSprite = Emulator.getStandLeft(); 	break;
			}
//System.out.println("image.  Stand");
		}
		else
		{	switch(xMovement)
			{	case  2: currentSprite = Emulator.getRunRight();	break;
				case -2: currentSprite = Emulator.getRunLeft(); 	break;
			}
//System.out.println("image.  Run");
			switch(xMovement)
			{ 	case -3: currentSprite = Emulator.getSlideLeft(); 	break;
				case  3: currentSprite = Emulator.getSlideRight(); 	break;
			}
//System.out.println("image.  Slide");		
		}
	}
ingestigate redundant x movements 3, 7, ect
	////////////////////// AIR //////////////////////
	else
	{	ySpeed += gravity;
System.out.println("	 pY.10  ys="+ySpeed+" cy="+centerYlocation);			
		////////////////////// SPRITES //////////////////////
		if (ySpeed < 0)
		{	switch(sameDirection)
			{	case  1: currentSprite = Emulator.getJumpRight();	break;
				case -1: currentSprite = Emulator.getJumpLeft(); 	break;
			}
//System.out.println("image.  Jump");
		}
		else
		{	switch(sameDirection)
			{	case  1: currentSprite = Emulator.getFallRight();	break;
				case -1: currentSprite = Emulator.getFallLeft(); 	break;
			}
//System.out.println("image.  Fall");
		}
		switch(xMovement)
		{	case  7: currentSprite = Emulator.getWallLeapRight();	break;
			case -7: currentSprite = Emulator.getWallLeapLeft(); 	break;
		}
//System.out.println("image.  WallLeap");
	
		
	}	
			
	//////////////////////END WALL JUMP SCRIPT //////////////////////
	if(ySpeed >= 0)
	{	script = 0;
	}
	//////////////////////WORLD END COLLISION//////////////////////
	if (centerXlocation-width/2.0+xSpeed <= Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue() && xSpeed < 0)
	{	xSpeed = 0;
//System.out.println("x.31 xs="+xSpeed+" cx="+centerXlocation+" | wStart="+(Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue()));
	}
	//////////////////////RESPAWN//////////////////////
	if(centerYlocation+ySpeed>=Emulator.getResolutionY())
	{	respawnDistance=Emulator.getLeftPlatformLimit()+Emulator.getLeftScrollingValue();
		script=1;
		xMovement=1;
		Emulator.getCharacter().traitUpdates(playerNum, charType, classType, xpFile);
	}	
	//////////////////////SCRIPT 1 RESPAWN//////////////////////
	if(script==1)
	{	double	restartScrollSpeed=100;
		currentSprite=Emulator.getNone();
		centerYlocation=Emulator.getTopScrollingValue();
		ySpeed=0;
//System.out.println("y..36  ys="+ySpeed+" cy="+centerYlocation);
		xSpeed=0;
//System.out.println("x.32 xs="+xSpeed+" cx="+centerXlocation+" RD="+respawnDistance);
		if(respawnDistance+restartScrollSpeed <= 0)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation(Emulator.getPlatform()[i].getPlatformXlocation()+restartScrollSpeed);
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()+restartScrollSpeed/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()+restartScrollSpeed/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()+restartScrollSpeed/1.6));
			respawnDistance+=restartScrollSpeed;
		}
		else
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation()-respawnDistance));
			}
			Emulator.getMidGround2().setBackgroundXvalue((Emulator.getMidGround2().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getMidGround1().setBackgroundXvalue((Emulator.getMidGround1().getBackgroundXvalue()-respawnDistance/3.0));
			Emulator.getForeGround2().setBackgroundXvalue((Emulator.getForeGround2().getBackgroundXvalue()-respawnDistance/1.6));
			Emulator.getForeGround1().setBackgroundXvalue((Emulator.getForeGround1().getBackgroundXvalue()-respawnDistance/1.6));
			script=0;
		}	
	}
	//////////////////////X LOCATION UPDATE//////////////////////
	if (centerXlocation-width/2.0+xSpeed >= Emulator.getLeftScrollingValue() && centerXlocation+width/2.0+xSpeed <= Emulator.getRightScrollingValue()|| Emulator.getMatchOver()==4) 
	{	centerXlocation += xSpeed;
//System.out.println("sx.HorrizontalUpdate XS="+xSpeed+" CX="+centerXlocation);	
	}
	//////////////////////RIGHT SCROLLING VALUE//////////////////////			
	if (centerXlocation+width/2.0+xSpeed > Emulator.getRightScrollingValue() && Emulator.getMatchOver() <4)
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation()+(-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2.0)))));
		}
		Emulator.getMidGround2().setBackgroundXvalue(Emulator.getMidGround2().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2.0)))/3.0));
		Emulator.getMidGround1().setBackgroundXvalue(Emulator.getMidGround1().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2.0)))/3.0));
		Emulator.getForeGround2().setBackgroundXvalue(Emulator.getForeGround2().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2.0)))/1.6));
		Emulator.getForeGround1().setBackgroundXvalue(Emulator.getForeGround1().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation+width/2.0)))/1.6));
		centerXlocation =Emulator.getRightScrollingValue()-width/2.0;
//System.out.println("sx.RightScrolling XS="+xSpeed+" CX="+centerXlocation);
	}
	//////////////////////LEFT SCROLLING VALUE//////////////////////
	if (centerXlocation-width/2.0+xSpeed < Emulator.getLeftScrollingValue() && Emulator.getMatchOver() <4 )
	{	for(int i = 0; i < Emulator.getPlatform().length; i++)
		{	Emulator.getPlatform()[i].setPlatformXlocation((Emulator.getPlatform()[i].getPlatformXlocation()+(-xSpeed+(Emulator.getLeftScrollingValue()-(centerXlocation-width/2.0)))));
		}
		Emulator.getMidGround2().setBackgroundXvalue(Emulator.getMidGround2().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2.0)))/3.0));
		Emulator.getMidGround1().setBackgroundXvalue(Emulator.getMidGround1().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2.0)))/3.0));
		Emulator.getForeGround2().setBackgroundXvalue(Emulator.getForeGround2().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2.0)))/1.6));
		Emulator.getForeGround1().setBackgroundXvalue(Emulator.getForeGround1().getBackgroundXvalue()+((-xSpeed+(Emulator.getRightScrollingValue()-(centerXlocation-width/2.0)))/1.6));
		centerXlocation = Emulator.getLeftScrollingValue()+width/2.0;
//System.out.println("sx.LeftScrolling XS="+xSpeed+" CX="+centerXlocation);
	}
	//////////////////////Y lOCATION UPDATE//////////////////////
	
	

	//////////////////////VIRTICAL PLATFORM SCROLLING//////////////////////
	if(centerYlocation+ySpeed >= platformContact)
	{	if(centerYlocation+ySpeed>= Emulator.getTopScrollingValue() && centerYlocation <= Emulator.getBottomScrollingValue()|| pitFall==true)
		{	centerYlocation = platformContact;
//System.out.println("sy.Ground VerticalUpdate YS="+ySpeed+" CY="+centerYlocation);	
		}
		if(centerYlocation+ySpeed < Emulator.getTopScrollingValue())
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation()+Emulator.getTopScrollingValue()-platformContact));	
			}
			centerYlocation=Emulator.getTopScrollingValue();	
//System.out.println("sy.Ground TopScroll YS="+ySpeed+" CY="+centerYlocation);
		}
		if(centerYlocation>Emulator.getBottomScrollingValue()&&pitFall==false)
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation()+(Emulator.getBottomScrollingValue()-platformContact)));
			}
			centerYlocation = Emulator.getBottomScrollingValue();
//System.out.println("sy.Ground BottomScroll YS="+ySpeed+" CY="+centerYlocation);	
		}
	}
	//////////////////////VIRTICAL AIR SCROLLING//////////////////////
	else
	{	if(centerYlocation+ySpeed>= Emulator.getTopScrollingValue())
		{	centerYlocation += ySpeed;
//System.out.println("sy.Air VerticalUpdate YS="+ySpeed+" CY="+centerYlocation+" WT="+wallTop);
		}
		if(centerYlocation+ySpeed < Emulator.getTopScrollingValue())
		{	for(int i = 0; i < Emulator.getPlatform().length; i++)
			{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation()+(-ySpeed+(Emulator.getTopScrollingValue()-centerYlocation))));
			}
			centerYlocation=Emulator.getTopScrollingValue();	
//System.out.println("sy.Air TopScroll YS="+ySpeed+" CY="+centerYlocation);
		}
		if(centerYlocation > Emulator.getBottomScrollingValue()) 
		{	if(	pitFall == false ||  pitFall == true && yScrollLimit > Emulator.getTopScrollingValue())
			{	for(int i = 0; i < Emulator.getPlatform().length; i++)
				{	Emulator.getPlatform()[i].setPlatformYlocation((Emulator.getPlatform()[i].getPlatformYlocation()+(-ySpeed+(Emulator.getBottomScrollingValue()-centerYlocation))));
				}
			centerYlocation = Emulator.getBottomScrollingValue();
//System.out.println("sy.Air BottomScroll YS="+ySpeed+" CY="+centerYlocation);	
			}
		}
	}
		
}
//////////////////////SETTERS AND GETTERS//////////////////////
	
	public double getCenterXlocation() 
	{	return centerXlocation;
	}
	public void setCenterXlocation(double centerXlocation) 
	{	this.centerXlocation = centerXlocation;
	}
	public double getCenterYlocation() 
	{	return centerYlocation;
	}
	public void setCenterYlocation(double centerYlocation) 
	{	this.centerYlocation = centerYlocation;
	}
	public void setYSpeed(double ySpeed) 
	{	this.ySpeed = ySpeed;
	}
	public double getXMovement() 
	{	return xMovement;
	}
	public void setXMovement(int xMovement) 
	{	this.xMovement = xMovement;	
	}
	public double getGradient() 
	{	return gradient;
	}
	public void setGradient(double gradient) 
	{	this.gradient = gradient;	
	}
	public void setPlayerNum(int playerNum) 
	{	this.playerNum = playerNum;
	}
	public double getClimbStrength() {
		return climbStrength;
	}
	public void setClimbStrength(double climbStrength) {
		this.climbStrength = climbStrength;
	}
	public double getxMovement() {
		return xMovement;
	}
	public Image getCurrentSprite() 
	{	return currentSprite;
	}
	public void setPlatformContact(double platformContact) 
	{	this.platformContact = platformContact;
	}
	public void setActiveSlope(double activeSlope) 
	{	this.activeSlope = activeSlope;	
	}
	public double getWall() 
	{	return wall;
	}
	public double getPlatformContact() 
	{	return platformContact;
	}
	public double getWallTop() 
	{	return wallTop;
	}
	public int getScript() 
	{	return script;
	}
	public double getWidth() {
		return width;
	}
	public double getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}
	public double getTorque() {
		return torque;
	}
	public void setTorque(double torque) {
		this.torque = torque;
	}
	public double getTopSpeed() {
		return topSpeed;
	}
	public void setTopSpeed(double topSpeed) {
		this.topSpeed = topSpeed;
	}
	public double getVerticalLeap() {
		return verticalLeap;
	}
	public void setVerticalLeap(double verticalLeap) {
		this.verticalLeap = verticalLeap;
	}
	public double getAirJump() {
		return airJump;
	}
	public void setAirJump(double airJump) {
		this.airJump = airJump;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public void setHight(double hight) {
		this.hight = hight;
	}
	public void setWallLeap(double wallLeap) {
		this.wallLeap = wallLeap;
	}
	public double getHight() {
		return hight;
	}
	public double getWallJumpCap() 
	{	return wallJumpCap;
	}
}