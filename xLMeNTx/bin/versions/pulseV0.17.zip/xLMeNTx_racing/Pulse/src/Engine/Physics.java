package Engine;
import java.awt.Image;
public class Physics 
{	public void physics(int playerNum, int xMovement, int centerXlocation, int width, int xSpeed, int centerYlocation, int hight, int ySpeed)
	{		}
	//////////////////////SETTERS AND GETTERS//////////////////////
	
}